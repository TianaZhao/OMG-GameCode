// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks
var com = require('data'); 
cc.Class({
    extends: cc.Component,

    properties: {
        gameStartButton: cc.Button,

        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },


    clickGameStart: function () {
        cc.director.loadScene("gameScene");
	},

    clickGameRule: function () {
        cc.director.loadScene("gameRule");
	},

    clickGameRestart: function() {
        com.restart = true;
        cc.director.loadScene("gameScene");
	},




    // LIFE-CYCLE CALLBACKS:

     onLoad () {

    },

    start () {

    },

    // update (dt) {},
});
