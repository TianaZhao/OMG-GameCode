cc.Class({
    extends: cc.Component,

    properties: {
        time: 0,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.sp = cc.v2(0, 0); 
        this.state = '';
        this.humanAni = this.node.getComponent(cc.Animation);
    },

    setState(state) {
        if (this.state != state) {
            this.state = state;
        }
        this.humanAni.play(this.state);
    },

    start () {

    },

    update (dt) {
        this.time++;
        let state = '';
        if (this.time > 10) {
            let action = Math.floor(Math.random() * 4);
            if (action == 0 && this.node.y <= 640 - 16 - 32) {
                // up
                state = 'human_up';
                this.sp.x = 0;
                this.sp.y = 32;
            } else if (action == 1 && this.node.y >= 16 + 32) {
                // down
                state = 'human_down';
                this.sp.x = 0;
                this.sp.y = -32;
            } else if (action == 2 && this.node.x >= 16 + 32) {
                // left
                state = 'human_left';
                this.sp.x = -32;
                this.sp.y = 0;
            } else if (action == 3 && this.node.x <= 640 - 16 - 32) {
                // right
                state = 'human_right';
                this.sp.x = 32;
                this.sp.y = 0;
            } else {
                this.sp.x = 0;
                this.sp.y = 0;
            }

            if (this.sp.x) {
                this.node.x += this.sp.x;
            } else if (this.sp.y) {
                this.node.y += this.sp.y;
            }

            this.time = 0;

            if (state) {
                this.setState(state);
            }
            //console.log('x:'+ this.node.x + ' y:'+ this.node.y);
        }
        
    },
});
