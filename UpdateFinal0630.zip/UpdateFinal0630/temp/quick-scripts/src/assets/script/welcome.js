"use strict";
cc._RF.push(module, '753bd+QSbBEDbagWzq0qsv+', 'welcome');
// script/welcome.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks
var com = require('data');

cc.Class({
  "extends": cc.Component,
  properties: {
    gameStartButton: cc.Button // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },

  },
  clickGameStart: function clickGameStart() {
    cc.director.loadScene("gameScene");
  },
  clickGameRule: function clickGameRule() {
    cc.director.loadScene("gameRule");
  },
  clickGameRestart: function clickGameRestart() {
    com.restart = true;
    cc.director.loadScene("gameScene");
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();