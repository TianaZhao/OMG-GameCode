"use strict";
cc._RF.push(module, '45da1YETqRAT6FyGk0iNFtO', 'background');
// script/background.js

"use strict";

var globalMapKey = [];
var globalGameData = [];
var globalYear = 0;

var com = require('data');

cc.Class({
  "extends": cc.Component,
  properties: {
    humanNode: cc.Node,
    humanTimer: 0,
    audioBgm: cc.AudioClip,
    audioClick: cc.AudioClip,
    mapNode: cc.Node,
    water: cc.Prefab,
    //water 0
    sand: cc.Prefab,
    //sand 1
    grass: cc.Prefab,
    //grass 2
    town: cc.Prefab,
    //town 3
    crop: cc.Prefab,
    //crop 4
    wheat: cc.Prefab,
    //wheat 5
    vocan: cc.Prefab,
    //vocan 6
    stone: cc.Prefab,
    //stone 7
    tree: cc.Prefab,
    // tree 8
    fruit: cc.Prefab,
    //fruit 9
    berry: cc.Prefab,
    //berry 10
    chicken: cc.Prefab,
    //chicken 11
    dog: cc.Prefab,
    //dog 12
    cow: cc.Prefab,
    //cow 13
    sheep: cc.Prefab,
    //sheep 14
    lion: cc.Prefab,
    // lion 15
    poison: cc.Prefab,
    //berry 16
    populationText: cc.Label,
    foodText: cc.Label,
    resourceText: cc.Label,
    techText: cc.Label,
    LevelText: cc.Label,
    powerText: cc.Label,
    mapKey: [],
    nodeKey: [],
    prefabKey: [],
    gameData: [],
    sizeX: 20,
    sizeY: 20,
    time: 0,
    // year num
    frame: 0,
    button1: cc.Button,
    button2: cc.Button,
    button3: cc.Button,
    button4: cc.Button,
    button5: cc.Button,
    button6: cc.Button,
    log: cc.Label,
    gameOverString: cc.Label,
    gameOver: cc.Node,
    gameOverOrNot: false,
    gameOverTime: 0,
    logframe: 0,
    progressBar: {
      "default": null,
      type: cc.ProgressBar
    }
  },
  onLoad: function onLoad() {
    cc.audioEngine.play(this.audioBgm, true, 1);
    this.prefabKey = [this.water, this.sand, this.grass, this.town, this.crop, this.wheat, this.vocan, this.stone, this.tree, this.fruit, this.berry, this.chicken, this.dog, this.cow, this.sheep, this.lion, this.poison]; //                     0          1          2           3          4          5           6           7           8          9           10          11            12        13         14          15        16

    this.gameData = [10, 0, 300, 0, 1, 1, [0, 0, 0, 0, 0], 100, 100, 0, 100, 0]; //gameData [population, house, food, resource, tech, multiplier, [chicken, dog, cow, sheep, lion], power, powerMax, currentExp, ExpNeed, GodLevel]
    //             0          1      2       3       4       5                     6                     7       8           9        10        11

    this.initArray(this.mapKey, this.sizeX, this.sizeY);
    this.initArray(this.nodeKey, this.sizeX, this.sizeY);
    this.worldGen(this.mapKey); //console.log('restartOrNot');
    //console.log(com.restart);

    this.readUserData();
    console.log('gameOver =' + this.gameOverOrNot); //console.log(this.mapKey);
    //console.log(this.gameData);

    this.loadMap(this.nodeKey, this.mapKey);
    this.gameOver.active = false;
    this.sp = cc.v2(0, 0);
    this.state = '';
    this.humanAni = this.humanNode.getComponent(cc.Animation);
  },
  // set state for human moving
  setState: function setState(state) {
    if (this.state != state) {
      this.state = state;
    }

    this.humanAni.play(this.state);
  },
  //initial an empty array
  initArray: function initArray(array, row, colume) {
    for (var i = 0; i < row; i++) {
      array[i] = [];

      for (var j = 0; j < colume; j++) {
        array[i][j] = null;
      }
    }
  },
  //generate world map
  worldGen: function worldGen(arrayMap) {
    //setting a sea background
    for (var i = 0; i < arrayMap.length; i++) {
      for (var j = 0; j < arrayMap[i].length; j++) {
        var item = 0;
        arrayMap[i][j] = item;
      }
    } //add sand as the island


    for (var _i = arrayMap.length / 2 - Math.floor(Math.random() * 5) - 1; _i < arrayMap.length / 2 + Math.floor(Math.random() * 5) + 1; _i++) {
      for (var _j = arrayMap[_i].length / 2 - Math.floor(Math.random() * 5) - 1; _j < arrayMap[_i].length / 2 + Math.floor(Math.random() * 5) + 1; _j++) {
        arrayMap[_i][_j] = 1;
      }
    } //add a single grassland


    for (var _i2 = arrayMap.length / 2 - Math.floor(Math.random() * 2) - 1; _i2 < arrayMap.length / 2 + Math.floor(Math.random() * 2) + 1; _i2++) {
      for (var _j2 = arrayMap[_i2].length / 2 - Math.floor(Math.random() * 2) - 1; _j2 < arrayMap[_i2].length / 2 + Math.floor(Math.random() * 2) + 1; _j2++) {
        arrayMap[_i2][_j2] = 2;
      }
    }

    arrayMap[arrayMap.length / 2][arrayMap[0].length / 2] = 2;
  },
  //load map from key
  loadMap: function loadMap(arrayNode, arrayMap) {
    for (var i = 0; i < arrayMap.length; i++) {
      for (var j = 0; j < arrayMap[i].length; j++) {
        arrayNode[i][j] = this.initNode(arrayMap[i][j], i, j, 32);
      }
    }
  },
  //add node as child
  initNode: function initNode(num, y, x, size) {
    var item = null;
    item = cc.instantiate(this.prefabKey[num]);
    var position = cc.v2(x * size + size / 2, y * size + size / 2);
    item.setPosition(position);
    item.name = y + '00' + x;
    this.mapNode.addChild(item);
    return item;
  },
  //number of item
  numOfItem: function numOfItem(array, num) {
    if (this.checkNodeExist(array, num)) {
      return this.findNode(array, num).length;
    }

    return 0;
  },
  //find if the node exist
  checkNodeExist: function checkNodeExist(array, number) {
    var ifFind = false;

    for (var i = 0; i < array.length; i++) {
      for (var j = 0; j < array[i].length; j++) {
        if (array[i][j] == number) {
          ifFind = true;
        }
      }
    }

    return ifFind;
  },
  //find the node with the key and return an array
  findNode: function findNode(array, number) {
    if (this.checkNodeExist(array, number)) {
      var arrayToReturn = [];
      var count = 0;

      for (var i = 0; i < array.length; i++) {
        for (var j = 0; j < array[i].length; j++) {
          if (array[i][j] == number) {
            arrayToReturn[count] = [i, j];
            count++;
          }
        }
      }

      return arrayToReturn;
    }
  },
  //check if the current location is in bound
  inBound: function inBound(y, x) {
    if (y < 0 || y >= this.sizeY || x < 0 || x >= this.sizeX) {
      return false;
    } else {
      return true;
    }
  },
  //replace with node by corredinate
  replaceNodeByCoordinate: function replaceNodeByCoordinate(arrayNode, arrayMap, y, x, newNum) {
    var nodeToDestory = this.mapNode.getChildByName(y + '00' + x);
    nodeToDestory.destroy();
    arrayNode[y][x] = this.initNode(newNum, y, x, 32);
    arrayMap[y][x] = newNum;
  },
  //replacew a single block of orgenNum type to newNum
  replaceNodeByKind: function replaceNodeByKind(arrayNode, arrayMap, origenNum, newNum) {
    if (this.checkNodeExist(arrayMap, origenNum)) {
      var listOfItem = this.findNode(arrayMap, origenNum);
      var index = Math.floor(Math.random() * listOfItem.length);
      this.replaceNodeByCoordinate(arrayNode, arrayMap, listOfItem[index][0], listOfItem[index][1], newNum);
      return [listOfItem[index][0], listOfItem[index][1]];
    }

    return 0;
  },
  //replace all node with 
  replaceAll: function replaceAll(arrayNode, arrayMap, origenNum, newNum) {
    if (this.checkNodeExist(arrayMap, origenNum)) {
      var replaceArray = this.findNode(arrayMap, origenNum);

      for (var i = 0; i < replaceArray.length; i++) {
        this.replaceNodeByCoordinate(arrayNode, arrayMap, replaceArray[i][0], replaceArray[i][1], newNum);
      }
    }
  },
  //check surrounding blocks
  surCheck: function surCheck(array, y, x, numToReplace) {
    for (var i = -1; i < 2; i++) {
      for (var j = -1; j < 2; j++) {
        if (this.inBound(y + i, x + j)) {
          if (array[y + i][x + j] == numToReplace) {
            return true;
          }
        }
      }
    }

    return false;
  },
  //replace x number of block with 'origenNum' type that surround (x,y) block with 'replaceNum' type
  surReplaceSingleOfType: function surReplaceSingleOfType(arrayNode, arrayMap, y, x, origenNum, replaceNum) {
    //gives a placement -1, 0, 1
    var moveX = Math.floor(Math.random() * 3) - 1;
    var moveY = Math.floor(Math.random() * 3) - 1;
    var newX = x + moveX;
    var newY = y + moveY;

    if (this.surCheck(this.mapKey, y, x, origenNum)) {
      //while the surrounding node is not the origenal node we want to replace
      while (arrayMap[newY][newX] != origenNum || !this.inBound(newY, newX)) {
        moveX = Math.floor(Math.random() * 3) - 1;
        moveY = Math.floor(Math.random() * 3) - 1;
        newX = x + moveX;
        newY = y + moveY;
      }

      this.replaceNodeByCoordinate(arrayNode, arrayMap, newY, newX, replaceNum);
    }
  },
  //replace x number of block that surround (x,y) block with 'replaceNum' type
  surReplaceSingle: function surReplaceSingle(arrayNode, arrayMap, y, x, replaceNum) {
    //gives a placement -1, 0, 1
    var moveX = Math.floor(Math.random() * 3) - 1;
    var moveY = Math.floor(Math.random() * 3) - 1;
    var newX = x + moveX;
    var newY = y + moveY;

    while (moveX == 0 && moveY == 0 || !this.inBound(newY, newX)) {
      moveX = Math.floor(Math.random() * 3) - 1;
      moveY = Math.floor(Math.random() * 3) - 1;
      newX = x + moveX;
      newY = y + moveY;
    }

    this.replaceNodeByCoordinate(arrayNode, arrayMap, newY, newX, replaceNum);
  },
  clickBackHomeButton: function clickBackHomeButton() {
    console.log('return to main page');
    this.saveUserData();
    cc.audioEngine.stopAll();
    cc.director.loadScene("welcome");
  },
  clickShareButton: function clickShareButton() {
    canvas.toTempFilePath({
      destWidth: 800,
      destHeight: 640,
      success: function success(res) {
        console.log("可以保存该截屏图片  ", res);
        wx.shareAppMessage({
          title: "一起来玩吧～",
          imageUrl: res.tempFilePath,
          success: function success(res) {},
          fail: function fail() {}
        });
      }
    });
  },
  //actions  ************************************************************************************************************************************
  //click button "1"
  clickButton1: function clickButton1() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < this.gameData[8]) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] = 0;
    this.action1();
  },
  //click button "2"
  clickButton2: function clickButton2() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 60) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 60;
    this.action2();
  },
  //click button "3"
  clickButton3: function clickButton3() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 40) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 40;
    this.action3();
  },
  //click button "4"
  clickButton4: function clickButton4() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 20 + this.gameData[11]) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 20 + this.gameData[11];
    this.action4();
  },
  //click button "5"
  clickButton5: function clickButton5() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 30) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 30;
    this.action5();
  },
  //click button "6"
  clickButton6: function clickButton6() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 50) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 50;
    this.action6();
  },
  //land
  action1: function action1() {
    //if (mana < 120) {
    //    return;
    //}
    //mana -= 120;
    this.genGround(); //增加陆地，消耗全部法力
  },
  //stone
  action2: function action2() {
    //if (mana < 60) {
    //    //notification
    //    return;
    //}
    //mana -= 60;
    // 好事啊
    var random = Math.random();

    if (random < Math.pow(0.7, this.gameData[4])) {
      var randomNum = Math.floor(Math.random() * 2);

      switch (randomNum) {
        case 0:
          this.genGround(); //增加陆地

          break;

        case 1:
          this.genStone(this.gameData); //刷新铁矿，发现加科技

          break;
      }
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      var numbersOfAction = 2;

      var _randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (_randomNum) {
        case 0:
          this.genVocano(); //生成火山

          break;

        case 1:
          this.vocanoEx(this.mapKey); //火山喷发，产生石头

          break;
      }
    } else {
      // 不要这个！！
      var _numbersOfAction = 2;

      var _randomNum2 = Math.floor(Math.random() * _numbersOfAction);

      switch (_randomNum2) {
        case 0:
          this.desertification(this.nodeKey, this.mapKey); //沙漠化

          break;

        case 1:
          this.earthquake(this.nodeKey, this.mapKey); //地震

          break;
      }
    }
  },
  //sky
  action3: function action3() {
    // 好事啊
    //if (mana < 40) {
    //    //notification
    //    return;
    //}
    //mana -= 40;
    var random = Math.random();

    if (random < Math.pow(0.1, this.gameData[4])) {
      var numbersOfAction = 2;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.storm(this.gameData); //雷 增加科技

          break;

        case 1:
          this.foodDouble(this.gameData); //丰收

          break;
      }
    } else if (random < Math.pow(0.8, this.gameData[4])) {
      // 就那么回事吧
      var _numbersOfAction2 = 2;

      var _randomNum3 = Math.floor(Math.random() * _numbersOfAction2);

      switch (_randomNum3) {
        case 0:
          this.rain(this.gameData); //降水

          break;

        case 1:
          this.wind(this.nodeKey, this.mapKey); //风， 吹走任何物品

          break;
      }
    } else {
      // 不要这个！！
      var _numbersOfAction3 = 1; //need change

      var _randomNum4 = Math.floor(Math.random() * _numbersOfAction3);

      switch (_randomNum4) {
        case 0:
          this.drought(this.gameData); //干旱，概率火灾，粮食减产

          break;

        case 1:
          this.flood(); //水灾，土地变成水

          break;

        case 2:
          //this.onFire(); //火灾
          break;
      }
    }
  },
  //plant
  action4: function action4() {
    //if (mana < 10) {
    //notification
    //    return;
    //}
    //mana -= 10;
    // 好事啊
    var random = Math.random();

    if (random < Math.pow(0.7, this.gameData[4])) {
      var numbersOfAction = 3;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.genBerry(); //果树 前期物资，加食物

          break;

        case 1:
          this.genTree(); //树

          break;

        case 2:
          this.genGrass(); //草

          break;
      }
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      this.genPoison(); //毒果子，吃了会死。
    } else {
      // 不要这个！！
      this.genCrop(); //耕地
    }
  },
  //animal
  action5: function action5() {
    //if (mana < 30) {
    //    //notification
    //    return;
    //}
    //mana -= 30;
    // 小型动物
    var random = Math.random();

    if (random < Math.pow(0.5, this.gameData[4])) {
      var numbersOfAction = 2;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.genDog(this.gameData); // 🐕，科技值大于1.2驯服，减少大型动物攻击概率

          break;

        case 1:
          this.genChicken(); // 🐓，科技之大于 1.1驯服，每年少量🍗

          break;
      }
    } else if (random < Math.pow(0.75, this.gameData[4])) {
      // 中型动物
      this.genSheep(); //🐏， 每年中量🍖，科技值大于2 可驯服
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      this.genCow(); //🐂， 会攻击人，每年大量🥩，科技值大于3可驯服，驯服后攻击
    } else {
      // 不要这个！！
      this.genLion(this.gameData); //🦁，会攻击人，无法驯服
    }
  },
  //population
  action6: function action6() {
    this.genPeople(this.gameData); //this.gameData[0] = 0;//test
  },
  //spawn island, spawn vocan, spawn stone, desertification  ****************************************************************************************************
  genPeople: function genPeople(arrayData) {
    if (arrayData[2] > 50) {
      arrayData[0] += 5;
      arrayData[2] -= 50;
      this.log.string = '第' + this.time + '年 ' + '人口+5\n' + this.log.string;
      this.gameData[9] += 5;
    } else {
      this.log.string = '食物不足，需要50食物\n' + this.log.string;
    }
  },
  //extend ground
  genGround: function genGround() {
    var position = this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);

    if (position != 0 && this.surCheck(this.mapKey, position[0], position[1], 0) == false) {
      position = this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);
    }

    for (var i = 0; i < 1 + 2 * Math.floor(Math.random() * 4); i++) {
      this.surReplaceSingleOfType(this.nodeKey, this.mapKey, position[0], position[1], 0, 1);
    }

    if (!this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 0, 1);
    }

    this.gameData[9] += 20;
    console.log('陆地扩张');
    this.log.string = '第' + this.time + '年 ' + ' 陆地扩张\n' + this.log.string;
  },
  genStone: function genStone(arrayData) {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 7);
      arrayData[4] += 0.01;
      console.log('找到矿物，科技+0.01');
      arrayData[9] += 10;
      arrayData[3] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 人们发现发现了一个新石矿，\n资源+10，科技+0.01\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 7);
      arrayData[4] += 0.01;
      console.log('找到矿物，科技+0.01');
      arrayData[9] += 10;
      arrayData[3] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 人们发现发现了一个新石矿，\n资源+10，科技+0.01\n' + this.log.string;
    } else {
      this.log.string = '空地不足，无法产生石矿\n' + this.log.string;
    }
  },
  //generate a vocano
  genVocano: function genVocano() {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 6);
      this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 6);
      this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
    } else {
      if (this.checkNodeExist(this.mapKey, 0) == false) {
        this.log.string = '空地不足，无法形成火山\n' + this.log.string;
      } else {
        this.replaceNodeByKind(this.nodeKey, this.mapKey, 0, 6);
        this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
      }
    }
  },
  // vocano explode
  vocanoEx: function vocanoEx(arrayMap) {
    if (this.checkNodeExist(this.mapKey, 6)) {
      var listOfItem = this.findNode(arrayMap, 6);
      var index = Math.floor(Math.random() * listOfItem.length);

      for (var i = 0; i < Math.floor(Math.random() * 4) + 1; i++) {
        this.surReplaceSingle(this.nodeKey, this.mapKey, listOfItem[index][0], listOfItem[index][1], 7);
      }

      this.log.string = '第' + this.time + '年 ' + ' 火山喷发\n' + this.log.string;
    } else {
      this.genVocano();

      if (this.checkNodeExist(this.mapKey, 6)) {
        this.log.string = '第' + this.time + '年 ' + ' 火山喷发\n' + this.log.string;
      }
    }
  },
  //earthquake
  earthquake: function earthquake(arrayNode, arrayMap) {
    for (var i = 0; i < Math.floor(Math.random() * 10) + 5; i++) {
      var y = Math.floor(Math.random() * arrayMap.length);
      var x = Math.floor(Math.random() * arrayMap[0].length);
      var oriHouse = this.numOfItem(arrayMap, 3);

      for (var _i3 = 0; _i3 < Math.floor(Math.random() * oriHouse / 3); _i3++) {
        if (this.numOfItem(arrayMap, 3) > 0) {
          this.surReplaceSingleOfType(arrayNode, arrayMap, y, x, 3, 7);
          this.gameData[0] -= Math.ceil(Math.random() * 3);

          if (this.gameData[0] <= 0) {
            this.gameData[0] = 0;
          }
        }
      }
    }

    console.log('地震啦');
    this.gameData[9] -= 10;
    this.log.string = '第' + this.time + '年 ' + ' 发生了地震，人口减少\n' + this.log.string;
  },
  //Desertification
  desertification: function desertification(arrayNode, arrayMap) {
    var randNum = Math.random();

    if (this.checkNodeExist(this.mapKey, 2)) {
      var grass = this.findNode(this.mapKey, 2);

      for (var i = 0; i < Math.floor(grass.length / 10); i++) {
        randNum = Math.random();

        if (randNum < 0.6) {
          this.replaceNodeByKind(arrayNode, arrayMap, 2, 1);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 5)) {
      var crop = this.findNode(this.mapKey, 5);

      for (var _i4 = 0; _i4 < Math.floor(crop.length / 10); _i4++) {
        randNum = Math.random();

        if (randNum < 0.4) {
          this.replaceNodeByKind(arrayNode, arrayNode, 4, 1);
        }
      }
    }

    console.log('沙漠化');
    this.gameData[9] -= 20;
    this.log.string = '第' + this.time + '年 ' + ' 土地沙漠化，农田收成受损\n' + this.log.string;
  },
  //rain, dry, harvest, storm  *****************************************************************************************************************************
  //harvest
  foodDouble: function foodDouble(gameData) {
    gameData[2] *= 1.5;
    console.log('食物丰收');
    gameData[9] += 20;
    this.log.string = '第' + this.time + '年 ' + ' 风调雨顺，食物大丰收\n' + this.log.string;
  },
  //storm
  storm: function storm(gameData) {
    var word = '';
    gameData[4] += 0.01;

    if (Math.random() > 0.5) {
      gameData[5] += 0.2;
      word = '雨水灌溉了庄稼';
      gameData[9] += 10;
    } else {
      gameData[5] -= 0.2;
      gameData[9] -= 10;
      word = '造成水灾';
    }

    console.log('雷阵雨');
    this.log.string = '第' + this.time + '年 ' + ' 雷阵雨 ' + word + '\n' + this.log.string;
  },
  //rain: food boost
  rain: function rain(gameData) {
    gameData[5] += Math.random() / 2;
    console.log('下雨啦');
    gameData[9] += 10;
    this.log.string = '第' + this.time + '年 ' + ' 下雨啦\n' + this.log.string;
  },
  //drought: food decay
  drought: function drought(gameData) {
    gameData[5] -= Math.random() / 2;
    console.log('干旱');
    gameData[9] -= 20;
    this.log.string = '第' + this.time + '年 ' + ' 雨水少，发生了干旱\n' + this.log.string;
  },
  //wind: reomve some node
  wind: function wind(arrayNode, arrayMap) {
    if (this.checkNodeExist(this.mapKey, 8)) {
      var tree = this.findNode(arrayMap, 8);

      for (var i = 0; i < Math.floor(tree.length / 10); i++) {
        if (Math.random() < 0.2) {
          this.replaceNodeByKind(arrayNode, arrayMap, 8, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 5)) {
      var wheat = this.findNode(arrayMap, 5);

      for (var _i5 = 0; _i5 < Math.floor(wheat.length / 10); _i5++) {
        if (Math.random() < 0.1) {
          this.replaceNodeByKind(arrayNode, arrayMap, 5, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 3)) {
      var house = this.findNode(arrayMap, 3);

      for (var _i6 = 0; _i6 < Math.floor(house.length / 10); _i6++) {
        if (Math.random() < 0.1) {
          this.replaceNodeByKind(arrayNode, arrayMap, 3, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 7)) {
      var stone = this.findNode(arrayMap, 7);

      for (var _i7 = 0; _i7 < Math.floor(stone.length / 10); _i7++) {
        if (Math.random() < 0.2) {
          this.replaceNodeByKind(arrayNode, arrayMap, 7, 2);
        }
      }
    }

    console.log('刮大风');
    this.log.string = '第' + this.time + '年 ' + ' 大风来袭\n' + this.log.string;
  },
  flood: function flood() {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 0);
      this.log.string = '第' + this.time + '年 ' + ' 爆发洪水，淹没了沙地\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 0);
      this.log.string = '第' + this.time + '年 ' + ' 爆发洪水，淹没了草地\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 3)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 3, 0);
      this.gameData[0] -= Math.ceil(Math.random() * 3);
      this.log.string = '第' + this.time + '年' + ' 爆发洪水，淹没了村庄\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 5)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 5, 0);
      this.log.string = '第' + this.time + '年' + ' 爆发洪水，淹没了田地\n' + this.log.string;
    }
  },
  ////fire event
  //onFire: function (arrayNode, arrayMap) {
  //    let listOfItemForest = this.findNode(arrayMap, 4);
  //    let listOfItemHouse = this.findNode(arrayMap, 6);
  //    let listOfItemFram = this.findNode(arrayMap, 7);
  //    let numbersOfPlace = 3;
  //    let randomNum = Math.floor(Math.random() * numbersOfPlace);
  //    switch (randomNum) {
  //        case 0: if (listOfItemForest != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemForest[index][0], listOfItemForest[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //        case 1: if (listOfItemHouse != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemHouse[index][0], listOfItemHouse[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //        case 2: if (listOfItemHouseFram != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemFram[index][0], listOfItemFram[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //    }
  //    this.log.string = 'Year ' + this.time + ' onFire\n' + this.log.string;
  //},
  ////off fire event
  //OffFire: function (arrayNode, arrayMap) {
  //    this.replaceAll(arrayNode, arrayMap, 9, 1);
  //    this.log.string = 'Year ' + this.time + ' off fire\n' + this.log.string;
  //},
  //berry, tree, fruit, poison  **************************************************************************************************************************
  //grow berrybush
  genBerry: function genBerry() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 10);
      console.log('生成果丛');
      this.log.string = '第' + this.time + '年 ' + '生成浆果丛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，种植浆果丛失败\n' + this.log.string;
    }
  },
  //grow poison
  genPoison: function genPoison() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 16);
      console.log('生成毒果丛');
      this.log.string = '第' + this.time + '年 ' + ' 生成毒果丛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，种植浆果丛失败\n' + this.log.string;
    }
  },
  //plant crop
  genCrop: function genCrop() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 4);
      console.log('生成耕地');
      this.gameData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 开拓耕地\n' + this.log.string;
    } else {
      this.log.string = '草地不足，开垦耕地失败\n' + this.log.string;
    }
  },
  //grass grow up to trees
  genTree: function genTree() {
    if (this.checkNodeExist(this.mapKey, 2) == false) {
      this.log.string = '草地不足，植树造林失败\n' + this.log.string;
      return;
    }

    this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 8);
    console.log('生成树');
    this.log.string = '第' + this.time + '年 ' + ' 植树造林\n' + this.log.string;
  },
  genGrass: function genGrass() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);
    console.log('生成草');
    this.log.string = '第' + this.time + '年 ' + ' 草，指一种植物\n' + this.log.string;
  },
  //chicken, dog, cow, sheep, lion      *************************************************************************************************************************
  genChicken: function genChicken() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 11);
      console.log('生成鸡');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只野鸡\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genDog: function genDog(arrayData) {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 12);
      arrayData[6][1] += 1;
      console.log('生成狼');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只野狼\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genCow: function genCow() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 13);
      console.log('生成牛');
      this.log.string = '第' + this.time + '年 ' + ' 发现一头野牛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genSheep: function genSheep() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 14);
      console.log('生成羊');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只羊\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genLion: function genLion(arrayData) {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 15);
      arrayData[6][4] += 1;
      console.log('生成狮子');
      this.log.string = '第' + this.time + '年 ' + ' 发现一头凶猛的狮子\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  //update function ***********************************************************************************************************************************************
  //power restore
  powerUpdate: function powerUpdate(gameData) {
    gameData[7] += 10 + gameData[8] * 0.05;

    if (gameData[9] >= gameData[10]) {
      //level up
      gameData[8] += 20;
      gameData[9] -= gameData[10];
      gameData[10] = gameData[10] * 1.2;
      gameData[11]++;
    } else if (gameData[9] < 0) {
      gameData[8] -= 20;
      gameData[10] = gameData[10] / 1.2;

      if (gameData[10] <= 100) {
        gameData[10] == 100;
      }

      gameData[9] = gameData[10] + gameData[9];
      gameData[11]--;

      if (gameData[11] < 0) {
        gameData[11] = 0;
      }
    }

    if (gameData[7] >= gameData[8]) {
      gameData[7] = gameData[8];
    }
  },
  //gather berrybush
  gatherBerry: function gatherBerry(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 10, 2);
    arrayData[2] += 3;
    console.log('gather berry');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + '收集浆果，食物+3\n' + this.log.string;
  },
  //gather poison
  gatherPoison: function gatherPoison(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 16, 2);
    arrayData[0] -= 1;
    console.log('gather poison');
    arrayData[9] -= 10;
    this.log.string = '第' + this.time + '年 ' + '一个不幸的人吃了剧毒的果子，人口-1\n' + this.log.string;
  },
  //the fruit trees around town harvest
  gatherFruit: function gatherFruit(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 9, 8);
    arrayData[2] += 5;
    console.log('fruit harvest');
    arrayData[9] += 10;
    this.log.string = '第' + this.time + '年 ' + '人们外出游玩，采摘果子，食物+5\n' + this.log.string;
  },
  gatherCrop: function gatherCrop(arrayData, arrayMap, num) {
    console.log('gather food');
    var gathercount = num;
    var numFruit = this.numOfItem(arrayMap, 9);
    var numBerry = this.numOfItem(arrayMap, 10);
    var numPoison = this.numOfItem(arrayMap, 16);

    if (numFruit > 0 || numBerry > 0 || numPoison > 0) {
      arrayData[9] += 5;
    }

    if (num > numFruit + numBerry + numPoison) {
      gathercount = numBerry + numPoison + numFruit;
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering food');

      if (numFruit > 0) {
        this.gatherFruit(arrayData);
      } else {
        if (numPoison <= 0) {
          this.gatherBerry(arrayData);
        } else if (numBerry <= 0) {
          this.gatherPoison(arrayData);
        } else {
          if (Math.random() > 0.5) {
            this.gatherBerry(arrayData);
          } else {
            this.gatherPoison(arrayData);
          }
        }
      }
    }
  },
  gatherTree: function gatherTree(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 2);
    arrayData[3] += 10;
    arrayData[9] += 10;
    console.log('gather tree, resource + 20');
    this.log.string = '第' + this.time + '年 ' + '采集到树木，资源+10\n' + this.log.string;
  },
  gatherFruitTree: function gatherFruitTree(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 2);
    arrayData[3] += 10;
    arrayData[2] += 4;
    arrayData[9] += 10;
    console.log('gather fruit tree, resource + 20');
    this.log.string = '第' + this.time + '年 ' + '采集到果树，资源+10，食物+4\n' + this.log.string;
  },
  gatherStone: function gatherStone(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 7, 1);
    arrayData[3] += 30;
    arrayData[9] += 10;
    console.log('gather stone, resource + 20');
    this.log.string = '第' + this.time + '年 ' + '发现了矿石，资源+30\n' + this.log.string;
  },
  gatherResource: function gatherResource(arrayData, arrayMap, num) {
    console.log('gather resource');
    var gathercount = num;
    var numTree = this.numOfItem(arrayMap, 8);
    var numFruitTree = this.numOfItem(arrayMap, 9);
    var numStone = this.numOfItem(arrayMap, 7);

    if (numTree > 0 || numFruitTree > 0 || numStone > 0) {}

    if (num > numTree + numStone + numFruitTree) {
      gathercount = numTree + numStone + numFruitTree;
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering resource');

      if (numStone > 0) {
        this.gatherStone(arrayData);
      } else {
        if (numTree <= 0) {
          this.gatherFruitTree(arrayData);
        } else {
          this.gatherTree(arrayData);
        }
      }
    }
  },
  killChicken: function killChicken(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 11, 2);
    arrayData[2] += 5;
    console.log('kill chicken');
    arrayData[9] += 1;
    this.log.string = '第' + this.time + '年 ' + '一只鸡被杀来吃了，食物+5\n' + this.log.string;
  },
  killDog: function killDog(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 12, 2);
    arrayData[5][1] -= 1;
    var dead = Math.floor(Math.random() * 2);
    arrayData[0] -= dead;
    arrayData[2] += 4;
    console.log('kill dog');

    if (dead == 1) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '杀死狼' + '，不过有' + dead + '死于狼爪下\n' + this.log.string;
    } else {
      arrayData[9] += 5;
      this.log.string = '第' + this.time + '年 ' + '杀死狼' + '，不过有' + dead + '死于狼爪下\n' + this.log.string;
    }
  },
  killCow: function killCow(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 13, 2);
    var dead = Math.floor(Math.random() * 3);
    arrayData[0] -= dead;
    arrayData[2] += 8;
    console.log('kill cow');

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
    }

    this.log.string = '第' + this.time + '年 ' + '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
  },
  killSheep: function killSheep(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 14, 2);
    arrayData[2] += 4;
    console.log('kill sheep');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + '一只羊被杀做烤全羊，食物+4\n' + this.log.string;
  },
  killLion: function killLion(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 15, 2);
    arrayData[5][4] -= 1;
    var dead = Math.floor(Math.random() * 4);
    arrayData[0] -= dead;
    arrayData[2] += 16;
    console.log('kill lion');

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '杀死狮子' + '，不过有' + dead + '人被狮子咬死了\n' + this.log.string;
    } else if (dead = 0) {
      arrayData[9] += 20;
      this.log.string = '第' + this.time + '年 ' + '捕获一头狮子\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '捕杀狮子的过程中，有' + dead + '人牺牲了\n' + this.log.string;
    }
  },
  gatherMeat: function gatherMeat(arrayData, arrayMap, num) {
    console.log('gather meat');
    var gathercount = num;
    var chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
    var sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
    var cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];
    var wolf = this.numOfItem(arrayMap, 12);
    var lion = this.numOfItem(arrayMap, 15);

    if (chicken > 0 || sheep > 0 || cow > 0 || wolf > 0 || lion > 0) {
      this.log.string = '第' + this.time + '年 ' + '从动物身上获取肉，食物增加\n' + this.log.string;
    }

    if (num > Math.floor(chicken + sheep / 2 + cow / 3 + wolf / 2 + lion / 4)) {
      gathercount = Math.floor(chicken + sheep / 2 + cow / 3 + wolf / 2 + lion / 4);
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering meat');

      if (chicken > 0) {
        this.killChicken(arrayData);

        if (Math.random() < 0.1 && arrayData[6][0] > 0) {
          arrayData[6][0] -= 1;
        }
      } else if (sheep > 0) {
        this.killSheep(arrayData);

        if (Math.random() < 0.09 && arrayData[6][3] > 0) {
          arrayData[6][3] -= 1;
        }
      } else if (cow > 0) {
        this.killCow(arrayData);

        if (Math.random() < 0.08 && arrayData[6][2] > 0) {
          arrayData[6][2] -= 1;
        }
      } else if (wolf > 0) {
        this.killDog(arrayData);
      } else {
        this.killLion(arrayData);
      }
    }
  },
  tameChicken: function tameChicken(arrayData) {
    arrayData[6][0] += 1;
    console.log('tam chicken');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + ' 成功驯服并永远拥有一群鸡\n' + this.log.string;
  },
  tameCow: function tameCow(arrayData) {
    arrayData[6][2] += 1;
    arrayData[0] -= Math.floor(Math.random() * 2);
    console.log('tam cow');
    var dead = Math.floor(Math.random() * 4);

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '成功驯服并永远拥有一头牛\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '成功驯服并永远拥有一头牛\n' + this.log.string;
    }
  },
  tameSheep: function tameSheep(arrayData) {
    arrayData[6][3] += 1;
    console.log('tam sheep');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + ' 成功驯服并永远拥有一只羊\n' + this.log.string;
  },
  gatherTam: function gatherTam(arrayData, arrayMap, num) {
    console.log('try taming');
    var ifTamed = false; //let chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
    //let sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
    //let cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];

    for (var i = 0; i < num; i++) {
      var chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
      var sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
      var cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];

      if (chicken > 0 && Math.random() < 0.5) {
        this.tameChicken(arrayData);
        ifTamed = true;
      } else if (sheep > 0 && Math.random() < 0.4 && this.gameData[4] >= 1.2) {
        this.tameSheep(arrayData);
        ifTamed = true;
      } else if (cow > 0 && Math.random() < 0.3 && this.gameData[4] >= 1.4) {
        this.tameCow(arrayData);
        ifTamed = true;
      }
    }
    /*if (chicken + sheep + cow > 0) {
        if (!ifTamed) {
            this.log.string = '驯服失败\n' + this.log.string;
        }
    } else {
        this.log.string = '无动物驯服\n' + this.log.string;
    }*/

  },
  // update AI ******************************************************************************************************
  buildHouse: function buildHouse(gameData) {
    if (gameData[3] >= 100 && gameData[1] < gameData[0] / 2) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 3);
      gameData[3] -= 100;
      gameData[1] += 1;
      this.log.string = '第' + this.time + '年 ' + '成功建造一栋房子\n' + this.log.string;
    } else {}
  },
  foodUpdate: function foodUpdate(arrayData, arrayMap) {
    var numOfPlot = this.numOfItem(arrayMap, 5);
    arrayData[2] += numOfPlot * 16 * arrayData[4] * arrayData[5] - arrayData[0] * 4;

    if (arrayData[2] < 0) {
      arrayData[2] = 0;
    }

    console.log('food: ' + Math.floor(arrayData[2]));
  },
  //crop grow
  growCrop: function growCrop() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 4, 5);
    console.log('crop grow');
    this.log.string = '第' + this.time + '年 ' + '庄稼成熟了\n' + this.log.string;
  },
  //trees around the town change to fruit trees
  growFruit: function growFruit() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 9);
    console.log('fruit');
    this.log.string = '第' + this.time + '年 ' + '树上结果子了\n' + this.log.string;
  },
  resourceDestory: function resourceDestory(arrayData, arrayMap) {
    var chicken = [this.numOfItem(arrayMap, 11) - arrayData[6][0], 11, 0.1];
    var sheep = [this.numOfItem(arrayMap, 14) - arrayData[6][3], 14, 0.05];
    var cow = [this.numOfItem(arrayMap, 13) - arrayData[6][2], 13, 0.05];
    var wolf = [this.numOfItem(arrayMap, 12), 12, 0.05];
    var lion = [this.numOfItem(arrayMap, 15), 15, 0.1];
    var berry = [this.numOfItem(arrayMap, 10), 10, 0.4];
    var poison = [this.numOfItem(arrayMap, 16), 16, 0.4];
    var tree = [this.numOfItem(arrayMap, 8), 8, 0.05];
    var fruit = [this.numOfItem(arrayMap, 9), 9, 0.05];
    var itemList = [chicken, sheep, cow, wolf, lion, berry, poison, tree, fruit];

    for (var i = 0; i < itemList.length; i++) {
      for (var j = 0; j < itemList[i][0]; j++) {
        if (Math.random() < itemList[i][2]) {
          this.replaceNodeByKind(this.nodeKey, this.mapKey, itemList[i][1], 2);
        }
      }
    }
  },
  landupdate: function landupdate(arrayData, arrayNode, arrayMap) {
    this.resourceDestory(arrayData, arrayMap);

    for (var i = 0; i < this.numOfItem(arrayMap, 4); i++) {
      this.growCrop();
    }

    for (var _i8 = 0; _i8 < this.numOfItem(arrayMap, 8); _i8++) {
      if (Math.random() < 0.3) {
        this.growFruit();
      }
    }

    var numOfPlot = this.numOfItem(arrayMap, 5);

    while (numOfPlot > arrayData[0]) {
      this.replaceNodeByKind(arrayNode, arrayMap, 5, 2);
      numOfPlot -= 1;
      console.log('not enough people farming');
    }
  },
  techUpdate: function techUpdate(arrayData) {
    arrayData[4] += 0.005;
    console.log('tech: ' + Math.round(arrayData[4])); //this.log.string = '科技值+0.001\n' + this.log.string;
  },
  populationUpdate: function populationUpdate(arrayData) {
    var wolf = this.numOfItem(this.mapKey, 12);
    var lion = this.numOfItem(this.mapKey, 15);

    for (var i = 0; i < wolf; i++) {
      if (arrayData[0] > arrayData[1] * 3 && Math.random() < 0.1) {
        arrayData[0] -= 1;
        this.log.string = '第' + this.time + '年 ' + '缺少房屋，一个不幸的流浪汉被野狼杀害\n' + this.log.string;
      }
    }

    for (var _i9 = 0; _i9 < lion; _i9++) {
      if (arrayData[0] > arrayData[1] * 3 && Math.random() < 0.3) {
        arrayData[0] -= 1;
        this.log.string = '第' + this.time + '年 ' + '缺少房屋，一个不幸的流浪汉被狮子杀害\n' + this.log.string;
      }
    }

    if (arrayData[2] == 0) {
      this.log.string = '第' + this.time + '年 ' + ' 饥荒，人口损失惨重\n' + this.log.string;

      if (arrayData[0] > 3) {
        arrayData[0] = Math.ceil(arrayData[0] * 3 / 4); //this.log.string = Math.ceil(arrayData[0] * 1 / 4); + this.log.string;
      } else {
        arrayData[0] = Math.floor(arrayData[0] * 3 / 4);
      }

      if (arrayData[0] == 1) {
        arrayData[0] = 0;
      }
    }
  },
  changeWeather: function changeWeather(arrayData) {
    arrayData[5] -= (arrayData[5] - 1) / 5;
    arrayData[5] -= 0.005;
  },
  yearCheck: function yearCheck(arrayData, arrayNode, arrayMap) {
    this.buildHouse(arrayData);
    this.gatherFood(arrayData, arrayMap);
  },
  gatherAI: function gatherAI(arrayData, arrayMap) {
    var numOfPlot = this.numOfItem(arrayMap, 5);
    var food = numOfPlot * 20 - arrayData[0] * 4 + arrayData[2];
    var remain = arrayData[0] - this.numOfItem(arrayMap, 5);

    if (food <= arrayData[0] * 8) {
      this.gatherCrop(arrayData, arrayMap, remain);
      food = numOfPlot * 20 - arrayData[0] * 4 + arrayData[2];

      if (food <= arrayData[0] * 4) {
        this.gatherMeat(arrayData, arrayMap, Math.floor(remain / 2));
      }
    } else if (food <= arrayData[0] * 16) {
      this.gatherCrop(arrayData, arrayMap, Math.floor(remain / 6));
      this.gatherResource(arrayData, arrayMap, Math.floor(remain / 2));
      this.gatherTam(arrayData, arrayMap, Math.floor(remain / 3));
    } else {
      this.gatherResource(arrayData, arrayMap, Math.floor(remain / 2));
      this.gatherTam(arrayData, arrayMap, Math.floor(remain / 2));
    }

    if (arrayData[0] > 50) {
      this.gatherMeat(arrayData, arrayMap, Math.floor(remain / 10));
    }
  },
  // check if the next tile human heading to is water or somewhere it should not be
  canHumanMove: function canHumanMove(actionNum) {
    var currX = Math.floor(this.humanNode.x / 32);
    var currY = Math.floor(this.humanNode.y / 32);

    if (actionNum == 0) {
      // up
      currY++;
    } else if (actionNum == 1) {
      //down
      currY--;
    } else if (actionNum == 2) {
      //left
      currX--;
    } else {
      //right
      currX++;
    }

    if (this.mapKey[currY][currX] == 0) {
      // add other keys if necessary
      return false;
    } else {
      return true;
    }
  },
  humanMove: function humanMove() {
    var state = '';
    var action = Math.floor(Math.random() * 4);

    if (this.canHumanMove(action)) {
      if (action == 0 && this.humanNode.y <= 640 - 16 - 32) {
        // up
        state = 'human_up';
        this.sp.x = 0;
        this.sp.y = 32;
      } else if (action == 1 && this.humanNode.y >= 16 + 32) {
        // down
        state = 'human_down';
        this.sp.x = 0;
        this.sp.y = -32;
      } else if (action == 2 && this.humanNode.x >= 16 + 32) {
        // left
        state = 'human_left';
        this.sp.x = -32;
        this.sp.y = 0;
      } else if (action == 3 && this.humanNode.x <= 640 - 16 - 32) {
        // right
        state = 'human_right';
        this.sp.x = 32;
        this.sp.y = 0;
      }
    } else {
      this.sp.x = 0;
      this.sp.y = 0;
    }

    if (this.sp.x) {
      this.humanNode.x += this.sp.x;
    } else if (this.sp.y) {
      this.humanNode.y += this.sp.y;
    }

    if (state) {
      this.setState(state);
    }
  },
  progressBarUpdate: function progressBarUpdate() {
    this.progressBar.progress = this.gameData[7] / this.gameData[8];
    /*if (progress < 1) {
        progress += 0.005;
        this.progressBar.progress = progress;
    
    } else {
        this.progressBar.progress = 1;       
    }*/
  },
  readUserData: function readUserData() {
    console.log('game=' + com.gameOver); //console.log('firstTime ' + cc.sys.localStorage.getItem('globalMapKey') == null);//may never be true

    var value = wx.getStorageSync('globalMapKey');
    console.log('restart ' + com.restart);

    if (value.length == 0 || com.restart || com.gameOver) {
      console.log('new game');
      com.gameOver = false;
      com.restart = false;
    } else {
      //globalMapKey = cc.sys.localStorage.getItem('globalMapKey');
      //globalGameData = cc.sys.localStorage.getItem('globalGameData');
      try {
        var value = wx.getStorageSync('globalMapKey');

        if (value) {
          // Do something with return value
          globalMapKey = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get map key storage error');
      }

      try {
        var value = wx.getStorageSync('globalGameData');

        if (value) {
          // Do something with return value
          globalGameData = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get game data storage error');
      }

      try {
        var value = wx.getStorageSync('globalYear');

        if (value) {
          // Do something with return value
          globalYear = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get year storage error');
      }

      console.log('globalMapKey');
      console.log(globalMapKey);
      console.log('globalGameData');
      console.log(globalGameData);
      console.log('globalYear');
      console.log(globalYear); // var keyArray = globalMapKey.split(",");
      // for (let i = 0; i < this.sizeY; i++) {
      //     for (let j = 0; j < this.sizeX; j++) {
      //         this.mapKey[i][j] = parseInt(keyArray[i * this.sizeX + j]);
      //     }
      // }

      this.mapKey = globalMapKey; // var splitArray = globalGameData.split(",");
      // for (let i = 0; i < this.gameData.length; i++) {
      //     if (i == 6 || i == 7 || i == 8 || i == 9 || i == 10) {
      //         for (j = 0; j < this.gameData[i].length; j++) {
      //             this.gameData[i][j] = parseFloat(splitArray[i + j]);
      //         }
      //     } else {
      //         this.gameData[i] = parseFloat(splitArray[i]);
      //     }
      // }

      this.gameData = globalGameData;
      this.time = globalYear;
    }
  },
  gameOverUpdate: function gameOverUpdate() {
    if (this.gameData[0] <= 0 && this.gameOverOrNot == false) {
      console.log('dead');
      this.gameOver.active = true;
      this.gameOverOrNot = true;
      this.saveUserData();
      this.gameOverTime = this.time;
      this.gameOverString.string = '游戏结束\n您的子民灭绝了\n' + '您的文明持续了\n' + this.gameOverTime + '年';
    }
  },
  saveUserData: function saveUserData() {
    com.gameOver = this.gameOverOrNot;
    globalMapKey = this.mapKey; //cc.sys.localStorage.setItem('globalMapKey', globalMapKey);

    try {
      wx.setStorageSync('globalMapKey', globalMapKey);
    } catch (e) {
      console.log('set map key storage error');
    }

    console.log('saveUserData globalMapKey:');
    console.log(globalMapKey);
    globalGameData = this.gameData; //cc.sys.localStorage.setItem('globalGameData', globalGameData);

    try {
      wx.setStorageSync('globalGameData', globalGameData);
    } catch (e) {
      console.log('set game data storage error');
    }

    console.log('saveUserData globalGameData');
    console.log(globalGameData);
    globalYear = this.time;

    try {
      wx.setStorageSync('globalYear', globalYear);
    } catch (e) {
      console.log('set year storage error');
    }
  },
  update: function update(dt) {
    if (this.log.string.length >= 1000) {
      this.log.string = '';
    }

    if (this.gameOverOrNot) {
      return;
    }

    this.frame++;
    this.logframe++;

    if (this.frame % 60 == 0) {
      this.powerUpdate(this.gameData);
    }

    if (this.frame == 270) {
      this.gatherAI(this.gameData, this.mapKey);
    } else if (this.frame == 300) {
      if (this.checkNodeExist(this.mapKey, 2)) {
        this.buildHouse(this.gameData);
      }
    } else if (this.frame == 330) {
      this.populationUpdate(this.gameData);
      this.foodUpdate(this.gameData, this.mapKey);
      this.techUpdate(this.gameData);
    } else if (this.frame >= 360) {
      this.landupdate(this.gameData, this.nodeKey, this.mapKey);
      this.changeWeather(this.gameData);
      this.frame = 0;
      this.time++;
    }

    this.humanTimer++;

    if (this.humanTimer > 60) {
      this.humanMove();
      this.humanTimer = 0;
    }

    if (this.logframe % 2700 == 0) {
      this.log.string = '';
      this.logframe = 0;
    }

    this.LevelText.string = '等级: ' + this.gameData[11];
    this.populationText.string = '人口: ' + this.gameData[0];
    this.foodText.string = '食物: ' + Math.round(this.gameData[2]); //this.techText.string = '科技: ' + this.gameData[4].toFixed(3);

    this.techText.string = '科技: ' + Math.round(this.gameData[4] * 1000) / 1000; //this.weatherText.string = '天气: ' + this.gameData[5].toFixed(1);

    this.resourceText.string = '资源: ' + this.gameData[3];
    this.powerText.string = this.gameData[7] + '/' + this.gameData[8];
    this.progressBarUpdate();
    this.gameOverUpdate();
  }
});

cc._RF.pop();