"use strict";
cc._RF.push(module, '608afH0jvpCaoPKHymSg6Fb', 'audioEngine');
// script/audioEngine.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    audio: {
      "default": null,
      type: cc.AudioClip
    }
  },
  onLoad: function onLoad() {
    this.current = cc.audioEngine.play(this.audio, false, 1);
  },
  onDestroy: function onDestroy() {
    cc.audioEngine.stop(this.current);
  }
});

cc._RF.pop();