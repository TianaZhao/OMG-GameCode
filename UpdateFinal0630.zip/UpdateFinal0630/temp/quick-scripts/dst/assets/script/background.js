
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/background.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '45da1YETqRAT6FyGk0iNFtO', 'background');
// script/background.js

"use strict";

var globalMapKey = [];
var globalGameData = [];
var globalYear = 0;

var com = require('data');

cc.Class({
  "extends": cc.Component,
  properties: {
    humanNode: cc.Node,
    humanTimer: 0,
    audioBgm: cc.AudioClip,
    audioClick: cc.AudioClip,
    mapNode: cc.Node,
    water: cc.Prefab,
    //water 0
    sand: cc.Prefab,
    //sand 1
    grass: cc.Prefab,
    //grass 2
    town: cc.Prefab,
    //town 3
    crop: cc.Prefab,
    //crop 4
    wheat: cc.Prefab,
    //wheat 5
    vocan: cc.Prefab,
    //vocan 6
    stone: cc.Prefab,
    //stone 7
    tree: cc.Prefab,
    // tree 8
    fruit: cc.Prefab,
    //fruit 9
    berry: cc.Prefab,
    //berry 10
    chicken: cc.Prefab,
    //chicken 11
    dog: cc.Prefab,
    //dog 12
    cow: cc.Prefab,
    //cow 13
    sheep: cc.Prefab,
    //sheep 14
    lion: cc.Prefab,
    // lion 15
    poison: cc.Prefab,
    //berry 16
    populationText: cc.Label,
    foodText: cc.Label,
    resourceText: cc.Label,
    techText: cc.Label,
    LevelText: cc.Label,
    powerText: cc.Label,
    mapKey: [],
    nodeKey: [],
    prefabKey: [],
    gameData: [],
    sizeX: 20,
    sizeY: 20,
    time: 0,
    // year num
    frame: 0,
    button1: cc.Button,
    button2: cc.Button,
    button3: cc.Button,
    button4: cc.Button,
    button5: cc.Button,
    button6: cc.Button,
    log: cc.Label,
    gameOverString: cc.Label,
    gameOver: cc.Node,
    gameOverOrNot: false,
    gameOverTime: 0,
    logframe: 0,
    progressBar: {
      "default": null,
      type: cc.ProgressBar
    }
  },
  onLoad: function onLoad() {
    cc.audioEngine.play(this.audioBgm, true, 1);
    this.prefabKey = [this.water, this.sand, this.grass, this.town, this.crop, this.wheat, this.vocan, this.stone, this.tree, this.fruit, this.berry, this.chicken, this.dog, this.cow, this.sheep, this.lion, this.poison]; //                     0          1          2           3          4          5           6           7           8          9           10          11            12        13         14          15        16

    this.gameData = [10, 0, 300, 0, 1, 1, [0, 0, 0, 0, 0], 100, 100, 0, 100, 0]; //gameData [population, house, food, resource, tech, multiplier, [chicken, dog, cow, sheep, lion], power, powerMax, currentExp, ExpNeed, GodLevel]
    //             0          1      2       3       4       5                     6                     7       8           9        10        11

    this.initArray(this.mapKey, this.sizeX, this.sizeY);
    this.initArray(this.nodeKey, this.sizeX, this.sizeY);
    this.worldGen(this.mapKey); //console.log('restartOrNot');
    //console.log(com.restart);

    this.readUserData();
    console.log('gameOver =' + this.gameOverOrNot); //console.log(this.mapKey);
    //console.log(this.gameData);

    this.loadMap(this.nodeKey, this.mapKey);
    this.gameOver.active = false;
    this.sp = cc.v2(0, 0);
    this.state = '';
    this.humanAni = this.humanNode.getComponent(cc.Animation);
  },
  // set state for human moving
  setState: function setState(state) {
    if (this.state != state) {
      this.state = state;
    }

    this.humanAni.play(this.state);
  },
  //initial an empty array
  initArray: function initArray(array, row, colume) {
    for (var i = 0; i < row; i++) {
      array[i] = [];

      for (var j = 0; j < colume; j++) {
        array[i][j] = null;
      }
    }
  },
  //generate world map
  worldGen: function worldGen(arrayMap) {
    //setting a sea background
    for (var i = 0; i < arrayMap.length; i++) {
      for (var j = 0; j < arrayMap[i].length; j++) {
        var item = 0;
        arrayMap[i][j] = item;
      }
    } //add sand as the island


    for (var _i = arrayMap.length / 2 - Math.floor(Math.random() * 5) - 1; _i < arrayMap.length / 2 + Math.floor(Math.random() * 5) + 1; _i++) {
      for (var _j = arrayMap[_i].length / 2 - Math.floor(Math.random() * 5) - 1; _j < arrayMap[_i].length / 2 + Math.floor(Math.random() * 5) + 1; _j++) {
        arrayMap[_i][_j] = 1;
      }
    } //add a single grassland


    for (var _i2 = arrayMap.length / 2 - Math.floor(Math.random() * 2) - 1; _i2 < arrayMap.length / 2 + Math.floor(Math.random() * 2) + 1; _i2++) {
      for (var _j2 = arrayMap[_i2].length / 2 - Math.floor(Math.random() * 2) - 1; _j2 < arrayMap[_i2].length / 2 + Math.floor(Math.random() * 2) + 1; _j2++) {
        arrayMap[_i2][_j2] = 2;
      }
    }

    arrayMap[arrayMap.length / 2][arrayMap[0].length / 2] = 2;
  },
  //load map from key
  loadMap: function loadMap(arrayNode, arrayMap) {
    for (var i = 0; i < arrayMap.length; i++) {
      for (var j = 0; j < arrayMap[i].length; j++) {
        arrayNode[i][j] = this.initNode(arrayMap[i][j], i, j, 32);
      }
    }
  },
  //add node as child
  initNode: function initNode(num, y, x, size) {
    var item = null;
    item = cc.instantiate(this.prefabKey[num]);
    var position = cc.v2(x * size + size / 2, y * size + size / 2);
    item.setPosition(position);
    item.name = y + '00' + x;
    this.mapNode.addChild(item);
    return item;
  },
  //number of item
  numOfItem: function numOfItem(array, num) {
    if (this.checkNodeExist(array, num)) {
      return this.findNode(array, num).length;
    }

    return 0;
  },
  //find if the node exist
  checkNodeExist: function checkNodeExist(array, number) {
    var ifFind = false;

    for (var i = 0; i < array.length; i++) {
      for (var j = 0; j < array[i].length; j++) {
        if (array[i][j] == number) {
          ifFind = true;
        }
      }
    }

    return ifFind;
  },
  //find the node with the key and return an array
  findNode: function findNode(array, number) {
    if (this.checkNodeExist(array, number)) {
      var arrayToReturn = [];
      var count = 0;

      for (var i = 0; i < array.length; i++) {
        for (var j = 0; j < array[i].length; j++) {
          if (array[i][j] == number) {
            arrayToReturn[count] = [i, j];
            count++;
          }
        }
      }

      return arrayToReturn;
    }
  },
  //check if the current location is in bound
  inBound: function inBound(y, x) {
    if (y < 0 || y >= this.sizeY || x < 0 || x >= this.sizeX) {
      return false;
    } else {
      return true;
    }
  },
  //replace with node by corredinate
  replaceNodeByCoordinate: function replaceNodeByCoordinate(arrayNode, arrayMap, y, x, newNum) {
    var nodeToDestory = this.mapNode.getChildByName(y + '00' + x);
    nodeToDestory.destroy();
    arrayNode[y][x] = this.initNode(newNum, y, x, 32);
    arrayMap[y][x] = newNum;
  },
  //replacew a single block of orgenNum type to newNum
  replaceNodeByKind: function replaceNodeByKind(arrayNode, arrayMap, origenNum, newNum) {
    if (this.checkNodeExist(arrayMap, origenNum)) {
      var listOfItem = this.findNode(arrayMap, origenNum);
      var index = Math.floor(Math.random() * listOfItem.length);
      this.replaceNodeByCoordinate(arrayNode, arrayMap, listOfItem[index][0], listOfItem[index][1], newNum);
      return [listOfItem[index][0], listOfItem[index][1]];
    }

    return 0;
  },
  //replace all node with 
  replaceAll: function replaceAll(arrayNode, arrayMap, origenNum, newNum) {
    if (this.checkNodeExist(arrayMap, origenNum)) {
      var replaceArray = this.findNode(arrayMap, origenNum);

      for (var i = 0; i < replaceArray.length; i++) {
        this.replaceNodeByCoordinate(arrayNode, arrayMap, replaceArray[i][0], replaceArray[i][1], newNum);
      }
    }
  },
  //check surrounding blocks
  surCheck: function surCheck(array, y, x, numToReplace) {
    for (var i = -1; i < 2; i++) {
      for (var j = -1; j < 2; j++) {
        if (this.inBound(y + i, x + j)) {
          if (array[y + i][x + j] == numToReplace) {
            return true;
          }
        }
      }
    }

    return false;
  },
  //replace x number of block with 'origenNum' type that surround (x,y) block with 'replaceNum' type
  surReplaceSingleOfType: function surReplaceSingleOfType(arrayNode, arrayMap, y, x, origenNum, replaceNum) {
    //gives a placement -1, 0, 1
    var moveX = Math.floor(Math.random() * 3) - 1;
    var moveY = Math.floor(Math.random() * 3) - 1;
    var newX = x + moveX;
    var newY = y + moveY;

    if (this.surCheck(this.mapKey, y, x, origenNum)) {
      //while the surrounding node is not the origenal node we want to replace
      while (arrayMap[newY][newX] != origenNum || !this.inBound(newY, newX)) {
        moveX = Math.floor(Math.random() * 3) - 1;
        moveY = Math.floor(Math.random() * 3) - 1;
        newX = x + moveX;
        newY = y + moveY;
      }

      this.replaceNodeByCoordinate(arrayNode, arrayMap, newY, newX, replaceNum);
    }
  },
  //replace x number of block that surround (x,y) block with 'replaceNum' type
  surReplaceSingle: function surReplaceSingle(arrayNode, arrayMap, y, x, replaceNum) {
    //gives a placement -1, 0, 1
    var moveX = Math.floor(Math.random() * 3) - 1;
    var moveY = Math.floor(Math.random() * 3) - 1;
    var newX = x + moveX;
    var newY = y + moveY;

    while (moveX == 0 && moveY == 0 || !this.inBound(newY, newX)) {
      moveX = Math.floor(Math.random() * 3) - 1;
      moveY = Math.floor(Math.random() * 3) - 1;
      newX = x + moveX;
      newY = y + moveY;
    }

    this.replaceNodeByCoordinate(arrayNode, arrayMap, newY, newX, replaceNum);
  },
  clickBackHomeButton: function clickBackHomeButton() {
    console.log('return to main page');
    this.saveUserData();
    cc.audioEngine.stopAll();
    cc.director.loadScene("welcome");
  },
  clickShareButton: function clickShareButton() {
    canvas.toTempFilePath({
      destWidth: 800,
      destHeight: 640,
      success: function success(res) {
        console.log("可以保存该截屏图片  ", res);
        wx.shareAppMessage({
          title: "一起来玩吧～",
          imageUrl: res.tempFilePath,
          success: function success(res) {},
          fail: function fail() {}
        });
      }
    });
  },
  //actions  ************************************************************************************************************************************
  //click button "1"
  clickButton1: function clickButton1() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < this.gameData[8]) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] = 0;
    this.action1();
  },
  //click button "2"
  clickButton2: function clickButton2() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 60) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 60;
    this.action2();
  },
  //click button "3"
  clickButton3: function clickButton3() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 40) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 40;
    this.action3();
  },
  //click button "4"
  clickButton4: function clickButton4() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 20 + this.gameData[11]) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 20 + this.gameData[11];
    this.action4();
  },
  //click button "5"
  clickButton5: function clickButton5() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 30) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 30;
    this.action5();
  },
  //click button "6"
  clickButton6: function clickButton6() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 50) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 50;
    this.action6();
  },
  //land
  action1: function action1() {
    //if (mana < 120) {
    //    return;
    //}
    //mana -= 120;
    this.genGround(); //增加陆地，消耗全部法力
  },
  //stone
  action2: function action2() {
    //if (mana < 60) {
    //    //notification
    //    return;
    //}
    //mana -= 60;
    // 好事啊
    var random = Math.random();

    if (random < Math.pow(0.7, this.gameData[4])) {
      var randomNum = Math.floor(Math.random() * 2);

      switch (randomNum) {
        case 0:
          this.genGround(); //增加陆地

          break;

        case 1:
          this.genStone(this.gameData); //刷新铁矿，发现加科技

          break;
      }
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      var numbersOfAction = 2;

      var _randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (_randomNum) {
        case 0:
          this.genVocano(); //生成火山

          break;

        case 1:
          this.vocanoEx(this.mapKey); //火山喷发，产生石头

          break;
      }
    } else {
      // 不要这个！！
      var _numbersOfAction = 2;

      var _randomNum2 = Math.floor(Math.random() * _numbersOfAction);

      switch (_randomNum2) {
        case 0:
          this.desertification(this.nodeKey, this.mapKey); //沙漠化

          break;

        case 1:
          this.earthquake(this.nodeKey, this.mapKey); //地震

          break;
      }
    }
  },
  //sky
  action3: function action3() {
    // 好事啊
    //if (mana < 40) {
    //    //notification
    //    return;
    //}
    //mana -= 40;
    var random = Math.random();

    if (random < Math.pow(0.1, this.gameData[4])) {
      var numbersOfAction = 2;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.storm(this.gameData); //雷 增加科技

          break;

        case 1:
          this.foodDouble(this.gameData); //丰收

          break;
      }
    } else if (random < Math.pow(0.8, this.gameData[4])) {
      // 就那么回事吧
      var _numbersOfAction2 = 2;

      var _randomNum3 = Math.floor(Math.random() * _numbersOfAction2);

      switch (_randomNum3) {
        case 0:
          this.rain(this.gameData); //降水

          break;

        case 1:
          this.wind(this.nodeKey, this.mapKey); //风， 吹走任何物品

          break;
      }
    } else {
      // 不要这个！！
      var _numbersOfAction3 = 1; //need change

      var _randomNum4 = Math.floor(Math.random() * _numbersOfAction3);

      switch (_randomNum4) {
        case 0:
          this.drought(this.gameData); //干旱，概率火灾，粮食减产

          break;

        case 1:
          this.flood(); //水灾，土地变成水

          break;

        case 2:
          //this.onFire(); //火灾
          break;
      }
    }
  },
  //plant
  action4: function action4() {
    //if (mana < 10) {
    //notification
    //    return;
    //}
    //mana -= 10;
    // 好事啊
    var random = Math.random();

    if (random < Math.pow(0.7, this.gameData[4])) {
      var numbersOfAction = 3;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.genBerry(); //果树 前期物资，加食物

          break;

        case 1:
          this.genTree(); //树

          break;

        case 2:
          this.genGrass(); //草

          break;
      }
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      this.genPoison(); //毒果子，吃了会死。
    } else {
      // 不要这个！！
      this.genCrop(); //耕地
    }
  },
  //animal
  action5: function action5() {
    //if (mana < 30) {
    //    //notification
    //    return;
    //}
    //mana -= 30;
    // 小型动物
    var random = Math.random();

    if (random < Math.pow(0.5, this.gameData[4])) {
      var numbersOfAction = 2;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.genDog(this.gameData); // 🐕，科技值大于1.2驯服，减少大型动物攻击概率

          break;

        case 1:
          this.genChicken(); // 🐓，科技之大于 1.1驯服，每年少量🍗

          break;
      }
    } else if (random < Math.pow(0.75, this.gameData[4])) {
      // 中型动物
      this.genSheep(); //🐏， 每年中量🍖，科技值大于2 可驯服
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      this.genCow(); //🐂， 会攻击人，每年大量🥩，科技值大于3可驯服，驯服后攻击
    } else {
      // 不要这个！！
      this.genLion(this.gameData); //🦁，会攻击人，无法驯服
    }
  },
  //population
  action6: function action6() {
    this.genPeople(this.gameData); //this.gameData[0] = 0;//test
  },
  //spawn island, spawn vocan, spawn stone, desertification  ****************************************************************************************************
  genPeople: function genPeople(arrayData) {
    if (arrayData[2] > 50) {
      arrayData[0] += 5;
      arrayData[2] -= 50;
      this.log.string = '第' + this.time + '年 ' + '人口+5\n' + this.log.string;
      this.gameData[9] += 5;
    } else {
      this.log.string = '食物不足，需要50食物\n' + this.log.string;
    }
  },
  //extend ground
  genGround: function genGround() {
    var position = this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);

    if (position != 0 && this.surCheck(this.mapKey, position[0], position[1], 0) == false) {
      position = this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);
    }

    for (var i = 0; i < 1 + 2 * Math.floor(Math.random() * 4); i++) {
      this.surReplaceSingleOfType(this.nodeKey, this.mapKey, position[0], position[1], 0, 1);
    }

    if (!this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 0, 1);
    }

    this.gameData[9] += 20;
    console.log('陆地扩张');
    this.log.string = '第' + this.time + '年 ' + ' 陆地扩张\n' + this.log.string;
  },
  genStone: function genStone(arrayData) {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 7);
      arrayData[4] += 0.01;
      console.log('找到矿物，科技+0.01');
      arrayData[9] += 10;
      arrayData[3] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 人们发现发现了一个新石矿，\n资源+10，科技+0.01\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 7);
      arrayData[4] += 0.01;
      console.log('找到矿物，科技+0.01');
      arrayData[9] += 10;
      arrayData[3] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 人们发现发现了一个新石矿，\n资源+10，科技+0.01\n' + this.log.string;
    } else {
      this.log.string = '空地不足，无法产生石矿\n' + this.log.string;
    }
  },
  //generate a vocano
  genVocano: function genVocano() {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 6);
      this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 6);
      this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
    } else {
      if (this.checkNodeExist(this.mapKey, 0) == false) {
        this.log.string = '空地不足，无法形成火山\n' + this.log.string;
      } else {
        this.replaceNodeByKind(this.nodeKey, this.mapKey, 0, 6);
        this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
      }
    }
  },
  // vocano explode
  vocanoEx: function vocanoEx(arrayMap) {
    if (this.checkNodeExist(this.mapKey, 6)) {
      var listOfItem = this.findNode(arrayMap, 6);
      var index = Math.floor(Math.random() * listOfItem.length);

      for (var i = 0; i < Math.floor(Math.random() * 4) + 1; i++) {
        this.surReplaceSingle(this.nodeKey, this.mapKey, listOfItem[index][0], listOfItem[index][1], 7);
      }

      this.log.string = '第' + this.time + '年 ' + ' 火山喷发\n' + this.log.string;
    } else {
      this.genVocano();

      if (this.checkNodeExist(this.mapKey, 6)) {
        this.log.string = '第' + this.time + '年 ' + ' 火山喷发\n' + this.log.string;
      }
    }
  },
  //earthquake
  earthquake: function earthquake(arrayNode, arrayMap) {
    for (var i = 0; i < Math.floor(Math.random() * 10) + 5; i++) {
      var y = Math.floor(Math.random() * arrayMap.length);
      var x = Math.floor(Math.random() * arrayMap[0].length);
      var oriHouse = this.numOfItem(arrayMap, 3);

      for (var _i3 = 0; _i3 < Math.floor(Math.random() * oriHouse / 3); _i3++) {
        if (this.numOfItem(arrayMap, 3) > 0) {
          this.surReplaceSingleOfType(arrayNode, arrayMap, y, x, 3, 7);
          this.gameData[0] -= Math.ceil(Math.random() * 3);

          if (this.gameData[0] <= 0) {
            this.gameData[0] = 0;
          }
        }
      }
    }

    console.log('地震啦');
    this.gameData[9] -= 10;
    this.log.string = '第' + this.time + '年 ' + ' 发生了地震，人口减少\n' + this.log.string;
  },
  //Desertification
  desertification: function desertification(arrayNode, arrayMap) {
    var randNum = Math.random();

    if (this.checkNodeExist(this.mapKey, 2)) {
      var grass = this.findNode(this.mapKey, 2);

      for (var i = 0; i < Math.floor(grass.length / 10); i++) {
        randNum = Math.random();

        if (randNum < 0.6) {
          this.replaceNodeByKind(arrayNode, arrayMap, 2, 1);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 5)) {
      var crop = this.findNode(this.mapKey, 5);

      for (var _i4 = 0; _i4 < Math.floor(crop.length / 10); _i4++) {
        randNum = Math.random();

        if (randNum < 0.4) {
          this.replaceNodeByKind(arrayNode, arrayNode, 4, 1);
        }
      }
    }

    console.log('沙漠化');
    this.gameData[9] -= 20;
    this.log.string = '第' + this.time + '年 ' + ' 土地沙漠化，农田收成受损\n' + this.log.string;
  },
  //rain, dry, harvest, storm  *****************************************************************************************************************************
  //harvest
  foodDouble: function foodDouble(gameData) {
    gameData[2] *= 1.5;
    console.log('食物丰收');
    gameData[9] += 20;
    this.log.string = '第' + this.time + '年 ' + ' 风调雨顺，食物大丰收\n' + this.log.string;
  },
  //storm
  storm: function storm(gameData) {
    var word = '';
    gameData[4] += 0.01;

    if (Math.random() > 0.5) {
      gameData[5] += 0.2;
      word = '雨水灌溉了庄稼';
      gameData[9] += 10;
    } else {
      gameData[5] -= 0.2;
      gameData[9] -= 10;
      word = '造成水灾';
    }

    console.log('雷阵雨');
    this.log.string = '第' + this.time + '年 ' + ' 雷阵雨 ' + word + '\n' + this.log.string;
  },
  //rain: food boost
  rain: function rain(gameData) {
    gameData[5] += Math.random() / 2;
    console.log('下雨啦');
    gameData[9] += 10;
    this.log.string = '第' + this.time + '年 ' + ' 下雨啦\n' + this.log.string;
  },
  //drought: food decay
  drought: function drought(gameData) {
    gameData[5] -= Math.random() / 2;
    console.log('干旱');
    gameData[9] -= 20;
    this.log.string = '第' + this.time + '年 ' + ' 雨水少，发生了干旱\n' + this.log.string;
  },
  //wind: reomve some node
  wind: function wind(arrayNode, arrayMap) {
    if (this.checkNodeExist(this.mapKey, 8)) {
      var tree = this.findNode(arrayMap, 8);

      for (var i = 0; i < Math.floor(tree.length / 10); i++) {
        if (Math.random() < 0.2) {
          this.replaceNodeByKind(arrayNode, arrayMap, 8, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 5)) {
      var wheat = this.findNode(arrayMap, 5);

      for (var _i5 = 0; _i5 < Math.floor(wheat.length / 10); _i5++) {
        if (Math.random() < 0.1) {
          this.replaceNodeByKind(arrayNode, arrayMap, 5, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 3)) {
      var house = this.findNode(arrayMap, 3);

      for (var _i6 = 0; _i6 < Math.floor(house.length / 10); _i6++) {
        if (Math.random() < 0.1) {
          this.replaceNodeByKind(arrayNode, arrayMap, 3, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 7)) {
      var stone = this.findNode(arrayMap, 7);

      for (var _i7 = 0; _i7 < Math.floor(stone.length / 10); _i7++) {
        if (Math.random() < 0.2) {
          this.replaceNodeByKind(arrayNode, arrayMap, 7, 2);
        }
      }
    }

    console.log('刮大风');
    this.log.string = '第' + this.time + '年 ' + ' 大风来袭\n' + this.log.string;
  },
  flood: function flood() {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 0);
      this.log.string = '第' + this.time + '年 ' + ' 爆发洪水，淹没了沙地\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 0);
      this.log.string = '第' + this.time + '年 ' + ' 爆发洪水，淹没了草地\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 3)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 3, 0);
      this.gameData[0] -= Math.ceil(Math.random() * 3);
      this.log.string = '第' + this.time + '年' + ' 爆发洪水，淹没了村庄\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 5)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 5, 0);
      this.log.string = '第' + this.time + '年' + ' 爆发洪水，淹没了田地\n' + this.log.string;
    }
  },
  ////fire event
  //onFire: function (arrayNode, arrayMap) {
  //    let listOfItemForest = this.findNode(arrayMap, 4);
  //    let listOfItemHouse = this.findNode(arrayMap, 6);
  //    let listOfItemFram = this.findNode(arrayMap, 7);
  //    let numbersOfPlace = 3;
  //    let randomNum = Math.floor(Math.random() * numbersOfPlace);
  //    switch (randomNum) {
  //        case 0: if (listOfItemForest != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemForest[index][0], listOfItemForest[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //        case 1: if (listOfItemHouse != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemHouse[index][0], listOfItemHouse[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //        case 2: if (listOfItemHouseFram != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemFram[index][0], listOfItemFram[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //    }
  //    this.log.string = 'Year ' + this.time + ' onFire\n' + this.log.string;
  //},
  ////off fire event
  //OffFire: function (arrayNode, arrayMap) {
  //    this.replaceAll(arrayNode, arrayMap, 9, 1);
  //    this.log.string = 'Year ' + this.time + ' off fire\n' + this.log.string;
  //},
  //berry, tree, fruit, poison  **************************************************************************************************************************
  //grow berrybush
  genBerry: function genBerry() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 10);
      console.log('生成果丛');
      this.log.string = '第' + this.time + '年 ' + '生成浆果丛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，种植浆果丛失败\n' + this.log.string;
    }
  },
  //grow poison
  genPoison: function genPoison() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 16);
      console.log('生成毒果丛');
      this.log.string = '第' + this.time + '年 ' + ' 生成毒果丛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，种植浆果丛失败\n' + this.log.string;
    }
  },
  //plant crop
  genCrop: function genCrop() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 4);
      console.log('生成耕地');
      this.gameData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 开拓耕地\n' + this.log.string;
    } else {
      this.log.string = '草地不足，开垦耕地失败\n' + this.log.string;
    }
  },
  //grass grow up to trees
  genTree: function genTree() {
    if (this.checkNodeExist(this.mapKey, 2) == false) {
      this.log.string = '草地不足，植树造林失败\n' + this.log.string;
      return;
    }

    this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 8);
    console.log('生成树');
    this.log.string = '第' + this.time + '年 ' + ' 植树造林\n' + this.log.string;
  },
  genGrass: function genGrass() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);
    console.log('生成草');
    this.log.string = '第' + this.time + '年 ' + ' 草，指一种植物\n' + this.log.string;
  },
  //chicken, dog, cow, sheep, lion      *************************************************************************************************************************
  genChicken: function genChicken() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 11);
      console.log('生成鸡');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只野鸡\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genDog: function genDog(arrayData) {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 12);
      arrayData[6][1] += 1;
      console.log('生成狼');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只野狼\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genCow: function genCow() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 13);
      console.log('生成牛');
      this.log.string = '第' + this.time + '年 ' + ' 发现一头野牛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genSheep: function genSheep() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 14);
      console.log('生成羊');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只羊\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genLion: function genLion(arrayData) {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 15);
      arrayData[6][4] += 1;
      console.log('生成狮子');
      this.log.string = '第' + this.time + '年 ' + ' 发现一头凶猛的狮子\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  //update function ***********************************************************************************************************************************************
  //power restore
  powerUpdate: function powerUpdate(gameData) {
    gameData[7] += 10 + gameData[8] * 0.05;

    if (gameData[9] >= gameData[10]) {
      //level up
      gameData[8] += 20;
      gameData[9] -= gameData[10];
      gameData[10] = gameData[10] * 1.2;
      gameData[11]++;
    } else if (gameData[9] < 0) {
      gameData[8] -= 20;
      gameData[10] = gameData[10] / 1.2;

      if (gameData[10] <= 100) {
        gameData[10] == 100;
      }

      gameData[9] = gameData[10] + gameData[9];
      gameData[11]--;

      if (gameData[11] < 0) {
        gameData[11] = 0;
      }
    }

    if (gameData[7] >= gameData[8]) {
      gameData[7] = gameData[8];
    }
  },
  //gather berrybush
  gatherBerry: function gatherBerry(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 10, 2);
    arrayData[2] += 3;
    console.log('gather berry');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + '收集浆果，食物+3\n' + this.log.string;
  },
  //gather poison
  gatherPoison: function gatherPoison(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 16, 2);
    arrayData[0] -= 1;
    console.log('gather poison');
    arrayData[9] -= 10;
    this.log.string = '第' + this.time + '年 ' + '一个不幸的人吃了剧毒的果子，人口-1\n' + this.log.string;
  },
  //the fruit trees around town harvest
  gatherFruit: function gatherFruit(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 9, 8);
    arrayData[2] += 5;
    console.log('fruit harvest');
    arrayData[9] += 10;
    this.log.string = '第' + this.time + '年 ' + '人们外出游玩，采摘果子，食物+5\n' + this.log.string;
  },
  gatherCrop: function gatherCrop(arrayData, arrayMap, num) {
    console.log('gather food');
    var gathercount = num;
    var numFruit = this.numOfItem(arrayMap, 9);
    var numBerry = this.numOfItem(arrayMap, 10);
    var numPoison = this.numOfItem(arrayMap, 16);

    if (numFruit > 0 || numBerry > 0 || numPoison > 0) {
      arrayData[9] += 5;
    }

    if (num > numFruit + numBerry + numPoison) {
      gathercount = numBerry + numPoison + numFruit;
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering food');

      if (numFruit > 0) {
        this.gatherFruit(arrayData);
      } else {
        if (numPoison <= 0) {
          this.gatherBerry(arrayData);
        } else if (numBerry <= 0) {
          this.gatherPoison(arrayData);
        } else {
          if (Math.random() > 0.5) {
            this.gatherBerry(arrayData);
          } else {
            this.gatherPoison(arrayData);
          }
        }
      }
    }
  },
  gatherTree: function gatherTree(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 2);
    arrayData[3] += 10;
    arrayData[9] += 10;
    console.log('gather tree, resource + 20');
    this.log.string = '第' + this.time + '年 ' + '采集到树木，资源+10\n' + this.log.string;
  },
  gatherFruitTree: function gatherFruitTree(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 2);
    arrayData[3] += 10;
    arrayData[2] += 4;
    arrayData[9] += 10;
    console.log('gather fruit tree, resource + 20');
    this.log.string = '第' + this.time + '年 ' + '采集到果树，资源+10，食物+4\n' + this.log.string;
  },
  gatherStone: function gatherStone(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 7, 1);
    arrayData[3] += 30;
    arrayData[9] += 10;
    console.log('gather stone, resource + 20');
    this.log.string = '第' + this.time + '年 ' + '发现了矿石，资源+30\n' + this.log.string;
  },
  gatherResource: function gatherResource(arrayData, arrayMap, num) {
    console.log('gather resource');
    var gathercount = num;
    var numTree = this.numOfItem(arrayMap, 8);
    var numFruitTree = this.numOfItem(arrayMap, 9);
    var numStone = this.numOfItem(arrayMap, 7);

    if (numTree > 0 || numFruitTree > 0 || numStone > 0) {}

    if (num > numTree + numStone + numFruitTree) {
      gathercount = numTree + numStone + numFruitTree;
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering resource');

      if (numStone > 0) {
        this.gatherStone(arrayData);
      } else {
        if (numTree <= 0) {
          this.gatherFruitTree(arrayData);
        } else {
          this.gatherTree(arrayData);
        }
      }
    }
  },
  killChicken: function killChicken(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 11, 2);
    arrayData[2] += 5;
    console.log('kill chicken');
    arrayData[9] += 1;
    this.log.string = '第' + this.time + '年 ' + '一只鸡被杀来吃了，食物+5\n' + this.log.string;
  },
  killDog: function killDog(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 12, 2);
    arrayData[5][1] -= 1;
    var dead = Math.floor(Math.random() * 2);
    arrayData[0] -= dead;
    arrayData[2] += 4;
    console.log('kill dog');

    if (dead == 1) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '杀死狼' + '，不过有' + dead + '死于狼爪下\n' + this.log.string;
    } else {
      arrayData[9] += 5;
      this.log.string = '第' + this.time + '年 ' + '杀死狼' + '，不过有' + dead + '死于狼爪下\n' + this.log.string;
    }
  },
  killCow: function killCow(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 13, 2);
    var dead = Math.floor(Math.random() * 3);
    arrayData[0] -= dead;
    arrayData[2] += 8;
    console.log('kill cow');

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
    }

    this.log.string = '第' + this.time + '年 ' + '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
  },
  killSheep: function killSheep(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 14, 2);
    arrayData[2] += 4;
    console.log('kill sheep');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + '一只羊被杀做烤全羊，食物+4\n' + this.log.string;
  },
  killLion: function killLion(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 15, 2);
    arrayData[5][4] -= 1;
    var dead = Math.floor(Math.random() * 4);
    arrayData[0] -= dead;
    arrayData[2] += 16;
    console.log('kill lion');

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '杀死狮子' + '，不过有' + dead + '人被狮子咬死了\n' + this.log.string;
    } else if (dead = 0) {
      arrayData[9] += 20;
      this.log.string = '第' + this.time + '年 ' + '捕获一头狮子\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '捕杀狮子的过程中，有' + dead + '人牺牲了\n' + this.log.string;
    }
  },
  gatherMeat: function gatherMeat(arrayData, arrayMap, num) {
    console.log('gather meat');
    var gathercount = num;
    var chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
    var sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
    var cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];
    var wolf = this.numOfItem(arrayMap, 12);
    var lion = this.numOfItem(arrayMap, 15);

    if (chicken > 0 || sheep > 0 || cow > 0 || wolf > 0 || lion > 0) {
      this.log.string = '第' + this.time + '年 ' + '从动物身上获取肉，食物增加\n' + this.log.string;
    }

    if (num > Math.floor(chicken + sheep / 2 + cow / 3 + wolf / 2 + lion / 4)) {
      gathercount = Math.floor(chicken + sheep / 2 + cow / 3 + wolf / 2 + lion / 4);
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering meat');

      if (chicken > 0) {
        this.killChicken(arrayData);

        if (Math.random() < 0.1 && arrayData[6][0] > 0) {
          arrayData[6][0] -= 1;
        }
      } else if (sheep > 0) {
        this.killSheep(arrayData);

        if (Math.random() < 0.09 && arrayData[6][3] > 0) {
          arrayData[6][3] -= 1;
        }
      } else if (cow > 0) {
        this.killCow(arrayData);

        if (Math.random() < 0.08 && arrayData[6][2] > 0) {
          arrayData[6][2] -= 1;
        }
      } else if (wolf > 0) {
        this.killDog(arrayData);
      } else {
        this.killLion(arrayData);
      }
    }
  },
  tameChicken: function tameChicken(arrayData) {
    arrayData[6][0] += 1;
    console.log('tam chicken');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + ' 成功驯服并永远拥有一群鸡\n' + this.log.string;
  },
  tameCow: function tameCow(arrayData) {
    arrayData[6][2] += 1;
    arrayData[0] -= Math.floor(Math.random() * 2);
    console.log('tam cow');
    var dead = Math.floor(Math.random() * 4);

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '成功驯服并永远拥有一头牛\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '成功驯服并永远拥有一头牛\n' + this.log.string;
    }
  },
  tameSheep: function tameSheep(arrayData) {
    arrayData[6][3] += 1;
    console.log('tam sheep');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + ' 成功驯服并永远拥有一只羊\n' + this.log.string;
  },
  gatherTam: function gatherTam(arrayData, arrayMap, num) {
    console.log('try taming');
    var ifTamed = false; //let chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
    //let sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
    //let cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];

    for (var i = 0; i < num; i++) {
      var chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
      var sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
      var cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];

      if (chicken > 0 && Math.random() < 0.5) {
        this.tameChicken(arrayData);
        ifTamed = true;
      } else if (sheep > 0 && Math.random() < 0.4 && this.gameData[4] >= 1.2) {
        this.tameSheep(arrayData);
        ifTamed = true;
      } else if (cow > 0 && Math.random() < 0.3 && this.gameData[4] >= 1.4) {
        this.tameCow(arrayData);
        ifTamed = true;
      }
    }
    /*if (chicken + sheep + cow > 0) {
        if (!ifTamed) {
            this.log.string = '驯服失败\n' + this.log.string;
        }
    } else {
        this.log.string = '无动物驯服\n' + this.log.string;
    }*/

  },
  // update AI ******************************************************************************************************
  buildHouse: function buildHouse(gameData) {
    if (gameData[3] >= 100 && gameData[1] < gameData[0] / 2) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 3);
      gameData[3] -= 100;
      gameData[1] += 1;
      this.log.string = '第' + this.time + '年 ' + '成功建造一栋房子\n' + this.log.string;
    } else {}
  },
  foodUpdate: function foodUpdate(arrayData, arrayMap) {
    var numOfPlot = this.numOfItem(arrayMap, 5);
    arrayData[2] += numOfPlot * 16 * arrayData[4] * arrayData[5] - arrayData[0] * 4;

    if (arrayData[2] < 0) {
      arrayData[2] = 0;
    }

    console.log('food: ' + Math.floor(arrayData[2]));
  },
  //crop grow
  growCrop: function growCrop() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 4, 5);
    console.log('crop grow');
    this.log.string = '第' + this.time + '年 ' + '庄稼成熟了\n' + this.log.string;
  },
  //trees around the town change to fruit trees
  growFruit: function growFruit() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 9);
    console.log('fruit');
    this.log.string = '第' + this.time + '年 ' + '树上结果子了\n' + this.log.string;
  },
  resourceDestory: function resourceDestory(arrayData, arrayMap) {
    var chicken = [this.numOfItem(arrayMap, 11) - arrayData[6][0], 11, 0.1];
    var sheep = [this.numOfItem(arrayMap, 14) - arrayData[6][3], 14, 0.05];
    var cow = [this.numOfItem(arrayMap, 13) - arrayData[6][2], 13, 0.05];
    var wolf = [this.numOfItem(arrayMap, 12), 12, 0.05];
    var lion = [this.numOfItem(arrayMap, 15), 15, 0.1];
    var berry = [this.numOfItem(arrayMap, 10), 10, 0.4];
    var poison = [this.numOfItem(arrayMap, 16), 16, 0.4];
    var tree = [this.numOfItem(arrayMap, 8), 8, 0.05];
    var fruit = [this.numOfItem(arrayMap, 9), 9, 0.05];
    var itemList = [chicken, sheep, cow, wolf, lion, berry, poison, tree, fruit];

    for (var i = 0; i < itemList.length; i++) {
      for (var j = 0; j < itemList[i][0]; j++) {
        if (Math.random() < itemList[i][2]) {
          this.replaceNodeByKind(this.nodeKey, this.mapKey, itemList[i][1], 2);
        }
      }
    }
  },
  landupdate: function landupdate(arrayData, arrayNode, arrayMap) {
    this.resourceDestory(arrayData, arrayMap);

    for (var i = 0; i < this.numOfItem(arrayMap, 4); i++) {
      this.growCrop();
    }

    for (var _i8 = 0; _i8 < this.numOfItem(arrayMap, 8); _i8++) {
      if (Math.random() < 0.3) {
        this.growFruit();
      }
    }

    var numOfPlot = this.numOfItem(arrayMap, 5);

    while (numOfPlot > arrayData[0]) {
      this.replaceNodeByKind(arrayNode, arrayMap, 5, 2);
      numOfPlot -= 1;
      console.log('not enough people farming');
    }
  },
  techUpdate: function techUpdate(arrayData) {
    arrayData[4] += 0.005;
    console.log('tech: ' + Math.round(arrayData[4])); //this.log.string = '科技值+0.001\n' + this.log.string;
  },
  populationUpdate: function populationUpdate(arrayData) {
    var wolf = this.numOfItem(this.mapKey, 12);
    var lion = this.numOfItem(this.mapKey, 15);

    for (var i = 0; i < wolf; i++) {
      if (arrayData[0] > arrayData[1] * 3 && Math.random() < 0.1) {
        arrayData[0] -= 1;
        this.log.string = '第' + this.time + '年 ' + '缺少房屋，一个不幸的流浪汉被野狼杀害\n' + this.log.string;
      }
    }

    for (var _i9 = 0; _i9 < lion; _i9++) {
      if (arrayData[0] > arrayData[1] * 3 && Math.random() < 0.3) {
        arrayData[0] -= 1;
        this.log.string = '第' + this.time + '年 ' + '缺少房屋，一个不幸的流浪汉被狮子杀害\n' + this.log.string;
      }
    }

    if (arrayData[2] == 0) {
      this.log.string = '第' + this.time + '年 ' + ' 饥荒，人口损失惨重\n' + this.log.string;

      if (arrayData[0] > 3) {
        arrayData[0] = Math.ceil(arrayData[0] * 3 / 4); //this.log.string = Math.ceil(arrayData[0] * 1 / 4); + this.log.string;
      } else {
        arrayData[0] = Math.floor(arrayData[0] * 3 / 4);
      }

      if (arrayData[0] == 1) {
        arrayData[0] = 0;
      }
    }
  },
  changeWeather: function changeWeather(arrayData) {
    arrayData[5] -= (arrayData[5] - 1) / 5;
    arrayData[5] -= 0.005;
  },
  yearCheck: function yearCheck(arrayData, arrayNode, arrayMap) {
    this.buildHouse(arrayData);
    this.gatherFood(arrayData, arrayMap);
  },
  gatherAI: function gatherAI(arrayData, arrayMap) {
    var numOfPlot = this.numOfItem(arrayMap, 5);
    var food = numOfPlot * 20 - arrayData[0] * 4 + arrayData[2];
    var remain = arrayData[0] - this.numOfItem(arrayMap, 5);

    if (food <= arrayData[0] * 8) {
      this.gatherCrop(arrayData, arrayMap, remain);
      food = numOfPlot * 20 - arrayData[0] * 4 + arrayData[2];

      if (food <= arrayData[0] * 4) {
        this.gatherMeat(arrayData, arrayMap, Math.floor(remain / 2));
      }
    } else if (food <= arrayData[0] * 16) {
      this.gatherCrop(arrayData, arrayMap, Math.floor(remain / 6));
      this.gatherResource(arrayData, arrayMap, Math.floor(remain / 2));
      this.gatherTam(arrayData, arrayMap, Math.floor(remain / 3));
    } else {
      this.gatherResource(arrayData, arrayMap, Math.floor(remain / 2));
      this.gatherTam(arrayData, arrayMap, Math.floor(remain / 2));
    }

    if (arrayData[0] > 50) {
      this.gatherMeat(arrayData, arrayMap, Math.floor(remain / 10));
    }
  },
  // check if the next tile human heading to is water or somewhere it should not be
  canHumanMove: function canHumanMove(actionNum) {
    var currX = Math.floor(this.humanNode.x / 32);
    var currY = Math.floor(this.humanNode.y / 32);

    if (actionNum == 0) {
      // up
      currY++;
    } else if (actionNum == 1) {
      //down
      currY--;
    } else if (actionNum == 2) {
      //left
      currX--;
    } else {
      //right
      currX++;
    }

    if (this.mapKey[currY][currX] == 0) {
      // add other keys if necessary
      return false;
    } else {
      return true;
    }
  },
  humanMove: function humanMove() {
    var state = '';
    var action = Math.floor(Math.random() * 4);

    if (this.canHumanMove(action)) {
      if (action == 0 && this.humanNode.y <= 640 - 16 - 32) {
        // up
        state = 'human_up';
        this.sp.x = 0;
        this.sp.y = 32;
      } else if (action == 1 && this.humanNode.y >= 16 + 32) {
        // down
        state = 'human_down';
        this.sp.x = 0;
        this.sp.y = -32;
      } else if (action == 2 && this.humanNode.x >= 16 + 32) {
        // left
        state = 'human_left';
        this.sp.x = -32;
        this.sp.y = 0;
      } else if (action == 3 && this.humanNode.x <= 640 - 16 - 32) {
        // right
        state = 'human_right';
        this.sp.x = 32;
        this.sp.y = 0;
      }
    } else {
      this.sp.x = 0;
      this.sp.y = 0;
    }

    if (this.sp.x) {
      this.humanNode.x += this.sp.x;
    } else if (this.sp.y) {
      this.humanNode.y += this.sp.y;
    }

    if (state) {
      this.setState(state);
    }
  },
  progressBarUpdate: function progressBarUpdate() {
    this.progressBar.progress = this.gameData[7] / this.gameData[8];
    /*if (progress < 1) {
        progress += 0.005;
        this.progressBar.progress = progress;
    
    } else {
        this.progressBar.progress = 1;       
    }*/
  },
  readUserData: function readUserData() {
    console.log('game=' + com.gameOver); //console.log('firstTime ' + cc.sys.localStorage.getItem('globalMapKey') == null);//may never be true

    var value = wx.getStorageSync('globalMapKey');
    console.log('restart ' + com.restart);

    if (value.length == 0 || com.restart || com.gameOver) {
      console.log('new game');
      com.gameOver = false;
      com.restart = false;
    } else {
      //globalMapKey = cc.sys.localStorage.getItem('globalMapKey');
      //globalGameData = cc.sys.localStorage.getItem('globalGameData');
      try {
        var value = wx.getStorageSync('globalMapKey');

        if (value) {
          // Do something with return value
          globalMapKey = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get map key storage error');
      }

      try {
        var value = wx.getStorageSync('globalGameData');

        if (value) {
          // Do something with return value
          globalGameData = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get game data storage error');
      }

      try {
        var value = wx.getStorageSync('globalYear');

        if (value) {
          // Do something with return value
          globalYear = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get year storage error');
      }

      console.log('globalMapKey');
      console.log(globalMapKey);
      console.log('globalGameData');
      console.log(globalGameData);
      console.log('globalYear');
      console.log(globalYear); // var keyArray = globalMapKey.split(",");
      // for (let i = 0; i < this.sizeY; i++) {
      //     for (let j = 0; j < this.sizeX; j++) {
      //         this.mapKey[i][j] = parseInt(keyArray[i * this.sizeX + j]);
      //     }
      // }

      this.mapKey = globalMapKey; // var splitArray = globalGameData.split(",");
      // for (let i = 0; i < this.gameData.length; i++) {
      //     if (i == 6 || i == 7 || i == 8 || i == 9 || i == 10) {
      //         for (j = 0; j < this.gameData[i].length; j++) {
      //             this.gameData[i][j] = parseFloat(splitArray[i + j]);
      //         }
      //     } else {
      //         this.gameData[i] = parseFloat(splitArray[i]);
      //     }
      // }

      this.gameData = globalGameData;
      this.time = globalYear;
    }
  },
  gameOverUpdate: function gameOverUpdate() {
    if (this.gameData[0] <= 0 && this.gameOverOrNot == false) {
      console.log('dead');
      this.gameOver.active = true;
      this.gameOverOrNot = true;
      this.saveUserData();
      this.gameOverTime = this.time;
      this.gameOverString.string = '游戏结束\n您的子民灭绝了\n' + '您的文明持续了\n' + this.gameOverTime + '年';
    }
  },
  saveUserData: function saveUserData() {
    com.gameOver = this.gameOverOrNot;
    globalMapKey = this.mapKey; //cc.sys.localStorage.setItem('globalMapKey', globalMapKey);

    try {
      wx.setStorageSync('globalMapKey', globalMapKey);
    } catch (e) {
      console.log('set map key storage error');
    }

    console.log('saveUserData globalMapKey:');
    console.log(globalMapKey);
    globalGameData = this.gameData; //cc.sys.localStorage.setItem('globalGameData', globalGameData);

    try {
      wx.setStorageSync('globalGameData', globalGameData);
    } catch (e) {
      console.log('set game data storage error');
    }

    console.log('saveUserData globalGameData');
    console.log(globalGameData);
    globalYear = this.time;

    try {
      wx.setStorageSync('globalYear', globalYear);
    } catch (e) {
      console.log('set year storage error');
    }
  },
  update: function update(dt) {
    if (this.log.string.length >= 1000) {
      this.log.string = '';
    }

    if (this.gameOverOrNot) {
      return;
    }

    this.frame++;
    this.logframe++;

    if (this.frame % 60 == 0) {
      this.powerUpdate(this.gameData);
    }

    if (this.frame == 270) {
      this.gatherAI(this.gameData, this.mapKey);
    } else if (this.frame == 300) {
      if (this.checkNodeExist(this.mapKey, 2)) {
        this.buildHouse(this.gameData);
      }
    } else if (this.frame == 330) {
      this.populationUpdate(this.gameData);
      this.foodUpdate(this.gameData, this.mapKey);
      this.techUpdate(this.gameData);
    } else if (this.frame >= 360) {
      this.landupdate(this.gameData, this.nodeKey, this.mapKey);
      this.changeWeather(this.gameData);
      this.frame = 0;
      this.time++;
    }

    this.humanTimer++;

    if (this.humanTimer > 60) {
      this.humanMove();
      this.humanTimer = 0;
    }

    if (this.logframe % 2700 == 0) {
      this.log.string = '';
      this.logframe = 0;
    }

    this.LevelText.string = '等级: ' + this.gameData[11];
    this.populationText.string = '人口: ' + this.gameData[0];
    this.foodText.string = '食物: ' + Math.round(this.gameData[2]); //this.techText.string = '科技: ' + this.gameData[4].toFixed(3);

    this.techText.string = '科技: ' + Math.round(this.gameData[4] * 1000) / 1000; //this.weatherText.string = '天气: ' + this.gameData[5].toFixed(1);

    this.resourceText.string = '资源: ' + this.gameData[3];
    this.powerText.string = this.gameData[7] + '/' + this.gameData[8];
    this.progressBarUpdate();
    this.gameOverUpdate();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHQvYmFja2dyb3VuZC5qcyJdLCJuYW1lcyI6WyJnbG9iYWxNYXBLZXkiLCJnbG9iYWxHYW1lRGF0YSIsImdsb2JhbFllYXIiLCJjb20iLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJodW1hbk5vZGUiLCJOb2RlIiwiaHVtYW5UaW1lciIsImF1ZGlvQmdtIiwiQXVkaW9DbGlwIiwiYXVkaW9DbGljayIsIm1hcE5vZGUiLCJ3YXRlciIsIlByZWZhYiIsInNhbmQiLCJncmFzcyIsInRvd24iLCJjcm9wIiwid2hlYXQiLCJ2b2NhbiIsInN0b25lIiwidHJlZSIsImZydWl0IiwiYmVycnkiLCJjaGlja2VuIiwiZG9nIiwiY293Iiwic2hlZXAiLCJsaW9uIiwicG9pc29uIiwicG9wdWxhdGlvblRleHQiLCJMYWJlbCIsImZvb2RUZXh0IiwicmVzb3VyY2VUZXh0IiwidGVjaFRleHQiLCJMZXZlbFRleHQiLCJwb3dlclRleHQiLCJtYXBLZXkiLCJub2RlS2V5IiwicHJlZmFiS2V5IiwiZ2FtZURhdGEiLCJzaXplWCIsInNpemVZIiwidGltZSIsImZyYW1lIiwiYnV0dG9uMSIsIkJ1dHRvbiIsImJ1dHRvbjIiLCJidXR0b24zIiwiYnV0dG9uNCIsImJ1dHRvbjUiLCJidXR0b242IiwibG9nIiwiZ2FtZU92ZXJTdHJpbmciLCJnYW1lT3ZlciIsImdhbWVPdmVyT3JOb3QiLCJnYW1lT3ZlclRpbWUiLCJsb2dmcmFtZSIsInByb2dyZXNzQmFyIiwidHlwZSIsIlByb2dyZXNzQmFyIiwib25Mb2FkIiwiYXVkaW9FbmdpbmUiLCJwbGF5IiwiaW5pdEFycmF5Iiwid29ybGRHZW4iLCJyZWFkVXNlckRhdGEiLCJjb25zb2xlIiwibG9hZE1hcCIsImFjdGl2ZSIsInNwIiwidjIiLCJzdGF0ZSIsImh1bWFuQW5pIiwiZ2V0Q29tcG9uZW50IiwiQW5pbWF0aW9uIiwic2V0U3RhdGUiLCJhcnJheSIsInJvdyIsImNvbHVtZSIsImkiLCJqIiwiYXJyYXlNYXAiLCJsZW5ndGgiLCJpdGVtIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwiYXJyYXlOb2RlIiwiaW5pdE5vZGUiLCJudW0iLCJ5IiwieCIsInNpemUiLCJpbnN0YW50aWF0ZSIsInBvc2l0aW9uIiwic2V0UG9zaXRpb24iLCJuYW1lIiwiYWRkQ2hpbGQiLCJudW1PZkl0ZW0iLCJjaGVja05vZGVFeGlzdCIsImZpbmROb2RlIiwibnVtYmVyIiwiaWZGaW5kIiwiYXJyYXlUb1JldHVybiIsImNvdW50IiwiaW5Cb3VuZCIsInJlcGxhY2VOb2RlQnlDb29yZGluYXRlIiwibmV3TnVtIiwibm9kZVRvRGVzdG9yeSIsImdldENoaWxkQnlOYW1lIiwiZGVzdHJveSIsInJlcGxhY2VOb2RlQnlLaW5kIiwib3JpZ2VuTnVtIiwibGlzdE9mSXRlbSIsImluZGV4IiwicmVwbGFjZUFsbCIsInJlcGxhY2VBcnJheSIsInN1ckNoZWNrIiwibnVtVG9SZXBsYWNlIiwic3VyUmVwbGFjZVNpbmdsZU9mVHlwZSIsInJlcGxhY2VOdW0iLCJtb3ZlWCIsIm1vdmVZIiwibmV3WCIsIm5ld1kiLCJzdXJSZXBsYWNlU2luZ2xlIiwiY2xpY2tCYWNrSG9tZUJ1dHRvbiIsInNhdmVVc2VyRGF0YSIsInN0b3BBbGwiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsImNsaWNrU2hhcmVCdXR0b24iLCJjYW52YXMiLCJ0b1RlbXBGaWxlUGF0aCIsImRlc3RXaWR0aCIsImRlc3RIZWlnaHQiLCJzdWNjZXNzIiwicmVzIiwid3giLCJzaGFyZUFwcE1lc3NhZ2UiLCJ0aXRsZSIsImltYWdlVXJsIiwidGVtcEZpbGVQYXRoIiwiZmFpbCIsImNsaWNrQnV0dG9uMSIsInN0cmluZyIsImFjdGlvbjEiLCJjbGlja0J1dHRvbjIiLCJhY3Rpb24yIiwiY2xpY2tCdXR0b24zIiwiYWN0aW9uMyIsImNsaWNrQnV0dG9uNCIsImFjdGlvbjQiLCJjbGlja0J1dHRvbjUiLCJhY3Rpb241IiwiY2xpY2tCdXR0b242IiwiYWN0aW9uNiIsImdlbkdyb3VuZCIsInBvdyIsInJhbmRvbU51bSIsImdlblN0b25lIiwibnVtYmVyc09mQWN0aW9uIiwiZ2VuVm9jYW5vIiwidm9jYW5vRXgiLCJkZXNlcnRpZmljYXRpb24iLCJlYXJ0aHF1YWtlIiwic3Rvcm0iLCJmb29kRG91YmxlIiwicmFpbiIsIndpbmQiLCJkcm91Z2h0IiwiZmxvb2QiLCJnZW5CZXJyeSIsImdlblRyZWUiLCJnZW5HcmFzcyIsImdlblBvaXNvbiIsImdlbkNyb3AiLCJnZW5Eb2ciLCJnZW5DaGlja2VuIiwiZ2VuU2hlZXAiLCJnZW5Db3ciLCJnZW5MaW9uIiwiZ2VuUGVvcGxlIiwiYXJyYXlEYXRhIiwib3JpSG91c2UiLCJjZWlsIiwicmFuZE51bSIsIndvcmQiLCJob3VzZSIsInBvd2VyVXBkYXRlIiwiZ2F0aGVyQmVycnkiLCJnYXRoZXJQb2lzb24iLCJnYXRoZXJGcnVpdCIsImdhdGhlckNyb3AiLCJnYXRoZXJjb3VudCIsIm51bUZydWl0IiwibnVtQmVycnkiLCJudW1Qb2lzb24iLCJnYXRoZXJUcmVlIiwiZ2F0aGVyRnJ1aXRUcmVlIiwiZ2F0aGVyU3RvbmUiLCJnYXRoZXJSZXNvdXJjZSIsIm51bVRyZWUiLCJudW1GcnVpdFRyZWUiLCJudW1TdG9uZSIsImtpbGxDaGlja2VuIiwia2lsbERvZyIsImRlYWQiLCJraWxsQ293Iiwia2lsbFNoZWVwIiwia2lsbExpb24iLCJnYXRoZXJNZWF0Iiwid29sZiIsInRhbWVDaGlja2VuIiwidGFtZUNvdyIsInRhbWVTaGVlcCIsImdhdGhlclRhbSIsImlmVGFtZWQiLCJidWlsZEhvdXNlIiwiZm9vZFVwZGF0ZSIsIm51bU9mUGxvdCIsImdyb3dDcm9wIiwiZ3Jvd0ZydWl0IiwicmVzb3VyY2VEZXN0b3J5IiwiaXRlbUxpc3QiLCJsYW5kdXBkYXRlIiwidGVjaFVwZGF0ZSIsInJvdW5kIiwicG9wdWxhdGlvblVwZGF0ZSIsImNoYW5nZVdlYXRoZXIiLCJ5ZWFyQ2hlY2siLCJnYXRoZXJGb29kIiwiZ2F0aGVyQUkiLCJmb29kIiwicmVtYWluIiwiY2FuSHVtYW5Nb3ZlIiwiYWN0aW9uTnVtIiwiY3VyclgiLCJjdXJyWSIsImh1bWFuTW92ZSIsImFjdGlvbiIsInByb2dyZXNzQmFyVXBkYXRlIiwicHJvZ3Jlc3MiLCJ2YWx1ZSIsImdldFN0b3JhZ2VTeW5jIiwicmVzdGFydCIsImUiLCJnYW1lT3ZlclVwZGF0ZSIsInNldFN0b3JhZ2VTeW5jIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUMsSUFBSUEsWUFBWSxHQUFHLEVBQW5CO0FBQ0QsSUFBSUMsY0FBYyxHQUFHLEVBQXJCO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLENBQWpCOztBQUVBLElBQUlDLEdBQUcsR0FBR0MsT0FBTyxDQUFDLE1BQUQsQ0FBakI7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxTQUFTLEVBQUVKLEVBQUUsQ0FBQ0ssSUFETjtBQUVSQyxJQUFBQSxVQUFVLEVBQUUsQ0FGSjtBQUdSQyxJQUFBQSxRQUFRLEVBQUVQLEVBQUUsQ0FBQ1EsU0FITDtBQUlSQyxJQUFBQSxVQUFVLEVBQUVULEVBQUUsQ0FBQ1EsU0FKUDtBQUtSRSxJQUFBQSxPQUFPLEVBQUVWLEVBQUUsQ0FBQ0ssSUFMSjtBQU1STSxJQUFBQSxLQUFLLEVBQUVYLEVBQUUsQ0FBQ1ksTUFORjtBQU1VO0FBQ2xCQyxJQUFBQSxJQUFJLEVBQUViLEVBQUUsQ0FBQ1ksTUFQRDtBQU9TO0FBQ2pCRSxJQUFBQSxLQUFLLEVBQUVkLEVBQUUsQ0FBQ1ksTUFSRjtBQVFVO0FBQ2xCRyxJQUFBQSxJQUFJLEVBQUVmLEVBQUUsQ0FBQ1ksTUFURDtBQVNTO0FBQ2pCSSxJQUFBQSxJQUFJLEVBQUVoQixFQUFFLENBQUNZLE1BVkQ7QUFVUztBQUNqQkssSUFBQUEsS0FBSyxFQUFFakIsRUFBRSxDQUFDWSxNQVhGO0FBV1U7QUFDbEJNLElBQUFBLEtBQUssRUFBRWxCLEVBQUUsQ0FBQ1ksTUFaRjtBQVlVO0FBQ2xCTyxJQUFBQSxLQUFLLEVBQUVuQixFQUFFLENBQUNZLE1BYkY7QUFhVTtBQUNsQlEsSUFBQUEsSUFBSSxFQUFFcEIsRUFBRSxDQUFDWSxNQWREO0FBY1M7QUFDakJTLElBQUFBLEtBQUssRUFBRXJCLEVBQUUsQ0FBQ1ksTUFmRjtBQWVVO0FBQ2xCVSxJQUFBQSxLQUFLLEVBQUV0QixFQUFFLENBQUNZLE1BaEJGO0FBZ0JVO0FBQ2xCVyxJQUFBQSxPQUFPLEVBQUV2QixFQUFFLENBQUNZLE1BakJKO0FBaUJZO0FBQ3BCWSxJQUFBQSxHQUFHLEVBQUV4QixFQUFFLENBQUNZLE1BbEJBO0FBa0JRO0FBQ2hCYSxJQUFBQSxHQUFHLEVBQUV6QixFQUFFLENBQUNZLE1BbkJBO0FBbUJRO0FBQ2hCYyxJQUFBQSxLQUFLLEVBQUUxQixFQUFFLENBQUNZLE1BcEJGO0FBb0JVO0FBQ2xCZSxJQUFBQSxJQUFJLEVBQUUzQixFQUFFLENBQUNZLE1BckJEO0FBcUJTO0FBQ2pCZ0IsSUFBQUEsTUFBTSxFQUFFNUIsRUFBRSxDQUFDWSxNQXRCSDtBQXNCVztBQUNuQmlCLElBQUFBLGNBQWMsRUFBRTdCLEVBQUUsQ0FBQzhCLEtBdkJYO0FBd0JSQyxJQUFBQSxRQUFRLEVBQUUvQixFQUFFLENBQUM4QixLQXhCTDtBQXlCUkUsSUFBQUEsWUFBWSxFQUFFaEMsRUFBRSxDQUFDOEIsS0F6QlQ7QUEwQlJHLElBQUFBLFFBQVEsRUFBRWpDLEVBQUUsQ0FBQzhCLEtBMUJMO0FBMkJSSSxJQUFBQSxTQUFTLEVBQUVsQyxFQUFFLENBQUM4QixLQTNCTjtBQTRCUkssSUFBQUEsU0FBUyxFQUFFbkMsRUFBRSxDQUFDOEIsS0E1Qk47QUE2QlJNLElBQUFBLE1BQU0sRUFBRSxFQTdCQTtBQThCUkMsSUFBQUEsT0FBTyxFQUFFLEVBOUJEO0FBK0JSQyxJQUFBQSxTQUFTLEVBQUUsRUEvQkg7QUFnQ1JDLElBQUFBLFFBQVEsRUFBRSxFQWhDRjtBQWlDUkMsSUFBQUEsS0FBSyxFQUFFLEVBakNDO0FBa0NSQyxJQUFBQSxLQUFLLEVBQUUsRUFsQ0M7QUFtQ1JDLElBQUFBLElBQUksRUFBRSxDQW5DRTtBQW1DQztBQUNUQyxJQUFBQSxLQUFLLEVBQUUsQ0FwQ0M7QUFxQ1JDLElBQUFBLE9BQU8sRUFBRTVDLEVBQUUsQ0FBQzZDLE1BckNKO0FBc0NSQyxJQUFBQSxPQUFPLEVBQUU5QyxFQUFFLENBQUM2QyxNQXRDSjtBQXVDUkUsSUFBQUEsT0FBTyxFQUFFL0MsRUFBRSxDQUFDNkMsTUF2Q0o7QUF3Q1JHLElBQUFBLE9BQU8sRUFBRWhELEVBQUUsQ0FBQzZDLE1BeENKO0FBeUNSSSxJQUFBQSxPQUFPLEVBQUVqRCxFQUFFLENBQUM2QyxNQXpDSjtBQTBDUkssSUFBQUEsT0FBTyxFQUFFbEQsRUFBRSxDQUFDNkMsTUExQ0o7QUEyQ1JNLElBQUFBLEdBQUcsRUFBRW5ELEVBQUUsQ0FBQzhCLEtBM0NBO0FBNENSc0IsSUFBQUEsY0FBYyxFQUFFcEQsRUFBRSxDQUFDOEIsS0E1Q1g7QUE2Q1J1QixJQUFBQSxRQUFRLEVBQUNyRCxFQUFFLENBQUNLLElBN0NKO0FBOENSaUQsSUFBQUEsYUFBYSxFQUFFLEtBOUNQO0FBK0NSQyxJQUFBQSxZQUFZLEVBQUUsQ0EvQ047QUFnRFJDLElBQUFBLFFBQVEsRUFBRSxDQWhERjtBQWlEUkMsSUFBQUEsV0FBVyxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUQyxNQUFBQSxJQUFJLEVBQUUxRCxFQUFFLENBQUMyRDtBQUZBO0FBakRMLEdBSFA7QUEwRExDLEVBQUFBLE1BMURLLG9CQTBESTtBQUNMNUQsSUFBQUEsRUFBRSxDQUFDNkQsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUt2RCxRQUF6QixFQUFtQyxJQUFuQyxFQUF5QyxDQUF6QztBQUNBLFNBQUsrQixTQUFMLEdBQWlCLENBQUMsS0FBSzNCLEtBQU4sRUFBYSxLQUFLRSxJQUFsQixFQUF3QixLQUFLQyxLQUE3QixFQUFvQyxLQUFLQyxJQUF6QyxFQUErQyxLQUFLQyxJQUFwRCxFQUEwRCxLQUFLQyxLQUEvRCxFQUFzRSxLQUFLQyxLQUEzRSxFQUFrRixLQUFLQyxLQUF2RixFQUE4RixLQUFLQyxJQUFuRyxFQUF5RyxLQUFLQyxLQUE5RyxFQUFxSCxLQUFLQyxLQUExSCxFQUFpSSxLQUFLQyxPQUF0SSxFQUErSSxLQUFLQyxHQUFwSixFQUF5SixLQUFLQyxHQUE5SixFQUFtSyxLQUFLQyxLQUF4SyxFQUErSyxLQUFLQyxJQUFwTCxFQUEwTCxLQUFLQyxNQUEvTCxDQUFqQixDQUZLLENBR0w7O0FBQ0EsU0FBS1csUUFBTCxHQUFnQixDQUFDLEVBQUQsRUFBSyxDQUFMLEVBQVEsR0FBUixFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLEVBQWEsQ0FBYixDQUF0QixFQUF1QyxHQUF2QyxFQUE0QyxHQUE1QyxFQUFpRCxDQUFqRCxFQUFvRCxHQUFwRCxFQUF5RCxDQUF6RCxDQUFoQixDQUpLLENBS0w7QUFDQTs7QUFDQSxTQUFLd0IsU0FBTCxDQUFlLEtBQUszQixNQUFwQixFQUE0QixLQUFLSSxLQUFqQyxFQUF3QyxLQUFLQyxLQUE3QztBQUNBLFNBQUtzQixTQUFMLENBQWUsS0FBSzFCLE9BQXBCLEVBQTZCLEtBQUtHLEtBQWxDLEVBQXlDLEtBQUtDLEtBQTlDO0FBQ0EsU0FBS3VCLFFBQUwsQ0FBYyxLQUFLNUIsTUFBbkIsRUFUSyxDQVVMO0FBQ0E7O0FBQ0EsU0FBSzZCLFlBQUw7QUFDQUMsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksZUFBZSxLQUFLRyxhQUFoQyxFQWJLLENBY0w7QUFDQTs7QUFDQSxTQUFLYSxPQUFMLENBQWEsS0FBSzlCLE9BQWxCLEVBQTJCLEtBQUtELE1BQWhDO0FBQ0EsU0FBS2lCLFFBQUwsQ0FBY2UsTUFBZCxHQUF1QixLQUF2QjtBQUNBLFNBQUtDLEVBQUwsR0FBVXJFLEVBQUUsQ0FBQ3NFLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFWO0FBQ0EsU0FBS0MsS0FBTCxHQUFhLEVBQWI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCLEtBQUtwRSxTQUFMLENBQWVxRSxZQUFmLENBQTRCekUsRUFBRSxDQUFDMEUsU0FBL0IsQ0FBaEI7QUFDSCxHQS9FSTtBQWlGTDtBQUNBQyxFQUFBQSxRQWxGSyxvQkFrRklKLEtBbEZKLEVBa0ZXO0FBQ1osUUFBSSxLQUFLQSxLQUFMLElBQWNBLEtBQWxCLEVBQXlCO0FBQ3JCLFdBQUtBLEtBQUwsR0FBYUEsS0FBYjtBQUNIOztBQUNELFNBQUtDLFFBQUwsQ0FBY1YsSUFBZCxDQUFtQixLQUFLUyxLQUF4QjtBQUNILEdBdkZJO0FBeUZMO0FBQ0FSLEVBQUFBLFNBQVMsRUFBRSxtQkFBVWEsS0FBVixFQUFpQkMsR0FBakIsRUFBc0JDLE1BQXRCLEVBQThCO0FBQ3JDLFNBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0YsR0FBcEIsRUFBeUJFLENBQUMsRUFBMUIsRUFBOEI7QUFDMUJILE1BQUFBLEtBQUssQ0FBQ0csQ0FBRCxDQUFMLEdBQVcsRUFBWDs7QUFDQSxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdGLE1BQXBCLEVBQTRCRSxDQUFDLEVBQTdCLEVBQWlDO0FBQzdCSixRQUFBQSxLQUFLLENBQUNHLENBQUQsQ0FBTCxDQUFTQyxDQUFULElBQWMsSUFBZDtBQUNIO0FBQ0o7QUFDSixHQWpHSTtBQW1HTDtBQUNBaEIsRUFBQUEsUUFBUSxFQUFFLGtCQUFVaUIsUUFBVixFQUFvQjtBQUMxQjtBQUNBLFNBQUssSUFBSUYsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0UsUUFBUSxDQUFDQyxNQUE3QixFQUFxQ0gsQ0FBQyxFQUF0QyxFQUEwQztBQUN0QyxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdDLFFBQVEsQ0FBQ0YsQ0FBRCxDQUFSLENBQVlHLE1BQWhDLEVBQXdDRixDQUFDLEVBQXpDLEVBQTZDO0FBQ3pDLFlBQUlHLElBQUksR0FBRyxDQUFYO0FBQ0FGLFFBQUFBLFFBQVEsQ0FBQ0YsQ0FBRCxDQUFSLENBQVlDLENBQVosSUFBaUJHLElBQWpCO0FBQ0g7QUFDSixLQVB5QixDQVExQjs7O0FBQ0EsU0FBSyxJQUFJSixFQUFDLEdBQUdFLFFBQVEsQ0FBQ0MsTUFBVCxHQUFrQixDQUFsQixHQUF1QkUsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUF2QixHQUF3RCxDQUFyRSxFQUF3RVAsRUFBQyxHQUFHRSxRQUFRLENBQUNDLE1BQVQsR0FBa0IsQ0FBbEIsR0FBdUJFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBdkIsR0FBd0QsQ0FBcEksRUFBdUlQLEVBQUMsRUFBeEksRUFBNEk7QUFDeEksV0FBSyxJQUFJQyxFQUFDLEdBQUdDLFFBQVEsQ0FBQ0YsRUFBRCxDQUFSLENBQVlHLE1BQVosR0FBcUIsQ0FBckIsR0FBMEJFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBMUIsR0FBMkQsQ0FBeEUsRUFBMkVOLEVBQUMsR0FBR0MsUUFBUSxDQUFDRixFQUFELENBQVIsQ0FBWUcsTUFBWixHQUFxQixDQUFyQixHQUEwQkUsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUExQixHQUEyRCxDQUExSSxFQUE2SU4sRUFBQyxFQUE5SSxFQUFrSjtBQUM5SUMsUUFBQUEsUUFBUSxDQUFDRixFQUFELENBQVIsQ0FBWUMsRUFBWixJQUFpQixDQUFqQjtBQUNIO0FBQ0osS0FieUIsQ0FjMUI7OztBQUNBLFNBQUssSUFBSUQsR0FBQyxHQUFHRSxRQUFRLENBQUNDLE1BQVQsR0FBa0IsQ0FBbEIsR0FBdUJFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBdkIsR0FBd0QsQ0FBckUsRUFBd0VQLEdBQUMsR0FBR0UsUUFBUSxDQUFDQyxNQUFULEdBQWtCLENBQWxCLEdBQXVCRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQXZCLEdBQXdELENBQXBJLEVBQXVJUCxHQUFDLEVBQXhJLEVBQTRJO0FBQ3hJLFdBQUssSUFBSUMsR0FBQyxHQUFHQyxRQUFRLENBQUNGLEdBQUQsQ0FBUixDQUFZRyxNQUFaLEdBQXFCLENBQXJCLEdBQTBCRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQTFCLEdBQTJELENBQXhFLEVBQTJFTixHQUFDLEdBQUdDLFFBQVEsQ0FBQ0YsR0FBRCxDQUFSLENBQVlHLE1BQVosR0FBcUIsQ0FBckIsR0FBMEJFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBMUIsR0FBMkQsQ0FBMUksRUFBNklOLEdBQUMsRUFBOUksRUFBa0o7QUFDOUlDLFFBQUFBLFFBQVEsQ0FBQ0YsR0FBRCxDQUFSLENBQVlDLEdBQVosSUFBaUIsQ0FBakI7QUFDSDtBQUNKOztBQUNEQyxJQUFBQSxRQUFRLENBQUNBLFFBQVEsQ0FBQ0MsTUFBVCxHQUFrQixDQUFuQixDQUFSLENBQThCRCxRQUFRLENBQUMsQ0FBRCxDQUFSLENBQVlDLE1BQVosR0FBcUIsQ0FBbkQsSUFBd0QsQ0FBeEQ7QUFDSCxHQXpISTtBQTJITDtBQUNBZixFQUFBQSxPQUFPLEVBQUUsaUJBQVVvQixTQUFWLEVBQXFCTixRQUFyQixFQUErQjtBQUNwQyxTQUFLLElBQUlGLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdFLFFBQVEsQ0FBQ0MsTUFBN0IsRUFBcUNILENBQUMsRUFBdEMsRUFBMEM7QUFDdEMsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHQyxRQUFRLENBQUNGLENBQUQsQ0FBUixDQUFZRyxNQUFoQyxFQUF3Q0YsQ0FBQyxFQUF6QyxFQUE2QztBQUN6Q08sUUFBQUEsU0FBUyxDQUFDUixDQUFELENBQVQsQ0FBYUMsQ0FBYixJQUFrQixLQUFLUSxRQUFMLENBQWNQLFFBQVEsQ0FBQ0YsQ0FBRCxDQUFSLENBQVlDLENBQVosQ0FBZCxFQUE4QkQsQ0FBOUIsRUFBaUNDLENBQWpDLEVBQW9DLEVBQXBDLENBQWxCO0FBQ0g7QUFDSjtBQUNKLEdBbElJO0FBb0lMO0FBQ0FRLEVBQUFBLFFBQVEsRUFBRSxrQkFBVUMsR0FBVixFQUFlQyxDQUFmLEVBQWtCQyxDQUFsQixFQUFxQkMsSUFBckIsRUFBMkI7QUFDakMsUUFBSVQsSUFBSSxHQUFHLElBQVg7QUFDQUEsSUFBQUEsSUFBSSxHQUFHbkYsRUFBRSxDQUFDNkYsV0FBSCxDQUFlLEtBQUt2RCxTQUFMLENBQWVtRCxHQUFmLENBQWYsQ0FBUDtBQUNBLFFBQUlLLFFBQVEsR0FBRzlGLEVBQUUsQ0FBQ3NFLEVBQUgsQ0FBTXFCLENBQUMsR0FBR0MsSUFBSixHQUFXQSxJQUFJLEdBQUcsQ0FBeEIsRUFBMkJGLENBQUMsR0FBR0UsSUFBSixHQUFXQSxJQUFJLEdBQUcsQ0FBN0MsQ0FBZjtBQUNBVCxJQUFBQSxJQUFJLENBQUNZLFdBQUwsQ0FBaUJELFFBQWpCO0FBQ0FYLElBQUFBLElBQUksQ0FBQ2EsSUFBTCxHQUFZTixDQUFDLEdBQUcsSUFBSixHQUFXQyxDQUF2QjtBQUNBLFNBQUtqRixPQUFMLENBQWF1RixRQUFiLENBQXNCZCxJQUF0QjtBQUNBLFdBQU9BLElBQVA7QUFDSCxHQTdJSTtBQStJTDtBQUNBZSxFQUFBQSxTQUFTLEVBQUUsbUJBQVV0QixLQUFWLEVBQWlCYSxHQUFqQixFQUFzQjtBQUM3QixRQUFJLEtBQUtVLGNBQUwsQ0FBb0J2QixLQUFwQixFQUEyQmEsR0FBM0IsQ0FBSixFQUFxQztBQUNqQyxhQUFPLEtBQUtXLFFBQUwsQ0FBY3hCLEtBQWQsRUFBcUJhLEdBQXJCLEVBQTBCUCxNQUFqQztBQUNIOztBQUNELFdBQU8sQ0FBUDtBQUNILEdBckpJO0FBdUpMO0FBQ0FpQixFQUFBQSxjQUFjLEVBQUUsd0JBQVV2QixLQUFWLEVBQWlCeUIsTUFBakIsRUFBeUI7QUFDckMsUUFBSUMsTUFBTSxHQUFHLEtBQWI7O0FBQ0EsU0FBSyxJQUFJdkIsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsS0FBSyxDQUFDTSxNQUExQixFQUFrQ0gsQ0FBQyxFQUFuQyxFQUF1QztBQUNuQyxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLEtBQUssQ0FBQ0csQ0FBRCxDQUFMLENBQVNHLE1BQTdCLEVBQXFDRixDQUFDLEVBQXRDLEVBQTBDO0FBQ3RDLFlBQUlKLEtBQUssQ0FBQ0csQ0FBRCxDQUFMLENBQVNDLENBQVQsS0FBZXFCLE1BQW5CLEVBQTJCO0FBQ3ZCQyxVQUFBQSxNQUFNLEdBQUcsSUFBVDtBQUNIO0FBQ0o7QUFDSjs7QUFDRCxXQUFPQSxNQUFQO0FBQ0gsR0FsS0k7QUFvS0w7QUFDQUYsRUFBQUEsUUFBUSxFQUFFLGtCQUFVeEIsS0FBVixFQUFpQnlCLE1BQWpCLEVBQXlCO0FBQy9CLFFBQUksS0FBS0YsY0FBTCxDQUFvQnZCLEtBQXBCLEVBQTJCeUIsTUFBM0IsQ0FBSixFQUF3QztBQUNwQyxVQUFJRSxhQUFhLEdBQUcsRUFBcEI7QUFDQSxVQUFJQyxLQUFLLEdBQUcsQ0FBWjs7QUFDQSxXQUFLLElBQUl6QixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSCxLQUFLLENBQUNNLE1BQTFCLEVBQWtDSCxDQUFDLEVBQW5DLEVBQXVDO0FBQ25DLGFBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0osS0FBSyxDQUFDRyxDQUFELENBQUwsQ0FBU0csTUFBN0IsRUFBcUNGLENBQUMsRUFBdEMsRUFBMEM7QUFDdEMsY0FBSUosS0FBSyxDQUFDRyxDQUFELENBQUwsQ0FBU0MsQ0FBVCxLQUFlcUIsTUFBbkIsRUFBMkI7QUFDdkJFLFlBQUFBLGFBQWEsQ0FBQ0MsS0FBRCxDQUFiLEdBQXVCLENBQUN6QixDQUFELEVBQUlDLENBQUosQ0FBdkI7QUFDQXdCLFlBQUFBLEtBQUs7QUFDUjtBQUNKO0FBQ0o7O0FBQ0QsYUFBT0QsYUFBUDtBQUNIO0FBQ0osR0FuTEk7QUFxTEw7QUFDQUUsRUFBQUEsT0FBTyxFQUFFLGlCQUFVZixDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDckIsUUFBSUQsQ0FBQyxHQUFHLENBQUosSUFBU0EsQ0FBQyxJQUFJLEtBQUtqRCxLQUFuQixJQUE0QmtELENBQUMsR0FBRyxDQUFoQyxJQUFxQ0EsQ0FBQyxJQUFJLEtBQUtuRCxLQUFuRCxFQUEwRDtBQUN0RCxhQUFPLEtBQVA7QUFDSCxLQUZELE1BRU87QUFDSCxhQUFPLElBQVA7QUFDSDtBQUNKLEdBNUxJO0FBOExMO0FBQ0FrRSxFQUFBQSx1QkFBdUIsRUFBRSxpQ0FBVW5CLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCUyxDQUEvQixFQUFrQ0MsQ0FBbEMsRUFBcUNnQixNQUFyQyxFQUE2QztBQUNsRSxRQUFJQyxhQUFhLEdBQUcsS0FBS2xHLE9BQUwsQ0FBYW1HLGNBQWIsQ0FBNEJuQixDQUFDLEdBQUcsSUFBSixHQUFXQyxDQUF2QyxDQUFwQjtBQUNBaUIsSUFBQUEsYUFBYSxDQUFDRSxPQUFkO0FBQ0F2QixJQUFBQSxTQUFTLENBQUNHLENBQUQsQ0FBVCxDQUFhQyxDQUFiLElBQWtCLEtBQUtILFFBQUwsQ0FBY21CLE1BQWQsRUFBc0JqQixDQUF0QixFQUF5QkMsQ0FBekIsRUFBNEIsRUFBNUIsQ0FBbEI7QUFDQVYsSUFBQUEsUUFBUSxDQUFDUyxDQUFELENBQVIsQ0FBWUMsQ0FBWixJQUFpQmdCLE1BQWpCO0FBQ0gsR0FwTUk7QUFzTUw7QUFDQUksRUFBQUEsaUJBQWlCLEVBQUUsMkJBQVV4QixTQUFWLEVBQXFCTixRQUFyQixFQUErQitCLFNBQS9CLEVBQTBDTCxNQUExQyxFQUFrRDtBQUNqRSxRQUFJLEtBQUtSLGNBQUwsQ0FBb0JsQixRQUFwQixFQUE4QitCLFNBQTlCLENBQUosRUFBOEM7QUFDMUMsVUFBSUMsVUFBVSxHQUFHLEtBQUtiLFFBQUwsQ0FBY25CLFFBQWQsRUFBd0IrQixTQUF4QixDQUFqQjtBQUNBLFVBQUlFLEtBQUssR0FBSTlCLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyQixVQUFVLENBQUMvQixNQUF0QyxDQUFiO0FBQ0EsV0FBS3dCLHVCQUFMLENBQTZCbkIsU0FBN0IsRUFBd0NOLFFBQXhDLEVBQWtEZ0MsVUFBVSxDQUFDQyxLQUFELENBQVYsQ0FBa0IsQ0FBbEIsQ0FBbEQsRUFBd0VELFVBQVUsQ0FBQ0MsS0FBRCxDQUFWLENBQWtCLENBQWxCLENBQXhFLEVBQThGUCxNQUE5RjtBQUNBLGFBQU8sQ0FBQ00sVUFBVSxDQUFDQyxLQUFELENBQVYsQ0FBa0IsQ0FBbEIsQ0FBRCxFQUF1QkQsVUFBVSxDQUFDQyxLQUFELENBQVYsQ0FBa0IsQ0FBbEIsQ0FBdkIsQ0FBUDtBQUNIOztBQUNELFdBQU8sQ0FBUDtBQUNILEdBL01JO0FBaU5MO0FBQ0FDLEVBQUFBLFVBQVUsRUFBRSxvQkFBVTVCLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCK0IsU0FBL0IsRUFBMENMLE1BQTFDLEVBQWtEO0FBQzFELFFBQUksS0FBS1IsY0FBTCxDQUFvQmxCLFFBQXBCLEVBQThCK0IsU0FBOUIsQ0FBSixFQUE4QztBQUMxQyxVQUFJSSxZQUFZLEdBQUcsS0FBS2hCLFFBQUwsQ0FBY25CLFFBQWQsRUFBd0IrQixTQUF4QixDQUFuQjs7QUFDQSxXQUFLLElBQUlqQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHcUMsWUFBWSxDQUFDbEMsTUFBakMsRUFBeUNILENBQUMsRUFBMUMsRUFBOEM7QUFDMUMsYUFBSzJCLHVCQUFMLENBQTZCbkIsU0FBN0IsRUFBd0NOLFFBQXhDLEVBQWtEbUMsWUFBWSxDQUFDckMsQ0FBRCxDQUFaLENBQWdCLENBQWhCLENBQWxELEVBQXNFcUMsWUFBWSxDQUFDckMsQ0FBRCxDQUFaLENBQWdCLENBQWhCLENBQXRFLEVBQTBGNEIsTUFBMUY7QUFDSDtBQUNKO0FBQ0osR0F6Tkk7QUEyTkw7QUFDQVUsRUFBQUEsUUFBUSxFQUFFLGtCQUFVekMsS0FBVixFQUFpQmMsQ0FBakIsRUFBb0JDLENBQXBCLEVBQXVCMkIsWUFBdkIsRUFBcUM7QUFDM0MsU0FBSyxJQUFJdkMsQ0FBQyxHQUFHLENBQUMsQ0FBZCxFQUFpQkEsQ0FBQyxHQUFHLENBQXJCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQTZCO0FBQ3pCLFdBQUssSUFBSUMsQ0FBQyxHQUFHLENBQUMsQ0FBZCxFQUFpQkEsQ0FBQyxHQUFHLENBQXJCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQTZCO0FBQ3pCLFlBQUksS0FBS3lCLE9BQUwsQ0FBYWYsQ0FBQyxHQUFHWCxDQUFqQixFQUFvQlksQ0FBQyxHQUFHWCxDQUF4QixDQUFKLEVBQWdDO0FBQzVCLGNBQUlKLEtBQUssQ0FBQ2MsQ0FBQyxHQUFHWCxDQUFMLENBQUwsQ0FBYVksQ0FBQyxHQUFHWCxDQUFqQixLQUF1QnNDLFlBQTNCLEVBQXlDO0FBQ3JDLG1CQUFPLElBQVA7QUFDSDtBQUNKO0FBQ0o7QUFDSjs7QUFDRCxXQUFPLEtBQVA7QUFDSCxHQXZPSTtBQXlPTDtBQUNBQyxFQUFBQSxzQkFBc0IsRUFBRSxnQ0FBVWhDLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCUyxDQUEvQixFQUFrQ0MsQ0FBbEMsRUFBcUNxQixTQUFyQyxFQUFnRFEsVUFBaEQsRUFBNEQ7QUFDaEY7QUFDQSxRQUFJQyxLQUFLLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQTVDO0FBQ0EsUUFBSW9DLEtBQUssR0FBR3RDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsSUFBZ0MsQ0FBNUM7QUFDQSxRQUFJcUMsSUFBSSxHQUFHaEMsQ0FBQyxHQUFHOEIsS0FBZjtBQUNBLFFBQUlHLElBQUksR0FBR2xDLENBQUMsR0FBR2dDLEtBQWY7O0FBQ0EsUUFBSSxLQUFLTCxRQUFMLENBQWMsS0FBS2pGLE1BQW5CLEVBQTJCc0QsQ0FBM0IsRUFBOEJDLENBQTlCLEVBQWlDcUIsU0FBakMsQ0FBSixFQUFpRDtBQUM3QztBQUNBLGFBQU8vQixRQUFRLENBQUMyQyxJQUFELENBQVIsQ0FBZUQsSUFBZixLQUF3QlgsU0FBeEIsSUFBcUMsQ0FBQyxLQUFLUCxPQUFMLENBQWFtQixJQUFiLEVBQW1CRCxJQUFuQixDQUE3QyxFQUF1RTtBQUNuRUYsUUFBQUEsS0FBSyxHQUFHckMsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUF4QztBQUNBb0MsUUFBQUEsS0FBSyxHQUFHdEMsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUF4QztBQUNBcUMsUUFBQUEsSUFBSSxHQUFHaEMsQ0FBQyxHQUFHOEIsS0FBWDtBQUNBRyxRQUFBQSxJQUFJLEdBQUdsQyxDQUFDLEdBQUdnQyxLQUFYO0FBQ0g7O0FBQ0QsV0FBS2hCLHVCQUFMLENBQTZCbkIsU0FBN0IsRUFBd0NOLFFBQXhDLEVBQWtEMkMsSUFBbEQsRUFBd0RELElBQXhELEVBQThESCxVQUE5RDtBQUNIO0FBQ0osR0ExUEk7QUE0UEw7QUFDQUssRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVV0QyxTQUFWLEVBQXFCTixRQUFyQixFQUErQlMsQ0FBL0IsRUFBa0NDLENBQWxDLEVBQXFDNkIsVUFBckMsRUFBaUQ7QUFDL0Q7QUFDQSxRQUFJQyxLQUFLLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQTVDO0FBQ0EsUUFBSW9DLEtBQUssR0FBR3RDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsSUFBZ0MsQ0FBNUM7QUFDQSxRQUFJcUMsSUFBSSxHQUFHaEMsQ0FBQyxHQUFHOEIsS0FBZjtBQUNBLFFBQUlHLElBQUksR0FBR2xDLENBQUMsR0FBR2dDLEtBQWY7O0FBQ0EsV0FBUUQsS0FBSyxJQUFJLENBQVQsSUFBY0MsS0FBSyxJQUFJLENBQXhCLElBQThCLENBQUMsS0FBS2pCLE9BQUwsQ0FBYW1CLElBQWIsRUFBbUJELElBQW5CLENBQXRDLEVBQWdFO0FBQzVERixNQUFBQSxLQUFLLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQXhDO0FBQ0FvQyxNQUFBQSxLQUFLLEdBQUd0QyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQXhDO0FBQ0FxQyxNQUFBQSxJQUFJLEdBQUdoQyxDQUFDLEdBQUc4QixLQUFYO0FBQ0FHLE1BQUFBLElBQUksR0FBR2xDLENBQUMsR0FBR2dDLEtBQVg7QUFDSDs7QUFDRCxTQUFLaEIsdUJBQUwsQ0FBNkJuQixTQUE3QixFQUF3Q04sUUFBeEMsRUFBa0QyQyxJQUFsRCxFQUF3REQsSUFBeEQsRUFBOERILFVBQTlEO0FBQ0gsR0ExUUk7QUE0UUxNLEVBQUFBLG1CQUFtQixFQUFFLCtCQUFZO0FBQzdCNUQsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVkscUJBQVo7QUFDQSxTQUFLNEUsWUFBTDtBQUNBL0gsSUFBQUEsRUFBRSxDQUFDNkQsV0FBSCxDQUFlbUUsT0FBZjtBQUNBaEksSUFBQUEsRUFBRSxDQUFDaUksUUFBSCxDQUFZQyxTQUFaLENBQXNCLFNBQXRCO0FBRUgsR0FsUkk7QUFvUkxDLEVBQUFBLGdCQUFnQixFQUFFLDRCQUFZO0FBQzFCQyxJQUFBQSxNQUFNLENBQUNDLGNBQVAsQ0FBc0I7QUFDbEJDLE1BQUFBLFNBQVMsRUFBRSxHQURPO0FBRWxCQyxNQUFBQSxVQUFVLEVBQUUsR0FGTTtBQUdsQkMsTUFBQUEsT0FIa0IsbUJBR1RDLEdBSFMsRUFHSjtBQUNWdkUsUUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksYUFBWixFQUEwQnNGLEdBQTFCO0FBQ0FDLFFBQUFBLEVBQUUsQ0FBQ0MsZUFBSCxDQUFtQjtBQUNmQyxVQUFBQSxLQUFLLEVBQUUsUUFEUTtBQUVmQyxVQUFBQSxRQUFRLEVBQUVKLEdBQUcsQ0FBQ0ssWUFGQztBQUdmTixVQUFBQSxPQUhlLG1CQUdQQyxHQUhPLEVBR0gsQ0FBRSxDQUhDO0FBSWZNLFVBQUFBLElBSmUsa0JBSVQsQ0FBRTtBQUpPLFNBQW5CO0FBTUg7QUFYaUIsS0FBdEI7QUFhSCxHQWxTSTtBQXFTTDtBQUVBO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QmhKLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsS0FBS0EsUUFBTCxDQUFjLENBQWQsQ0FBdkIsRUFBeUM7QUFDckMsV0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixpQkFBaUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTVDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLMUcsUUFBTCxDQUFjLENBQWQsSUFBbUIsQ0FBbkI7QUFDQSxTQUFLMkcsT0FBTDtBQUVILEdBalRJO0FBbVRMO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0Qm5KLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsRUFBdkIsRUFBMkI7QUFDdkIsV0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixpQkFBaUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTVDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLMUcsUUFBTCxDQUFjLENBQWQsS0FBa0IsRUFBbEI7QUFDQSxTQUFLNkcsT0FBTDtBQUVILEdBN1RJO0FBK1RMO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QnJKLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsRUFBdkIsRUFBMkI7QUFDdkIsV0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixpQkFBaUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTVDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLMUcsUUFBTCxDQUFjLENBQWQsS0FBa0IsRUFBbEI7QUFDQSxTQUFLK0csT0FBTDtBQUVILEdBelVJO0FBMlVMO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QnZKLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsS0FBSyxLQUFLQSxRQUFMLENBQWMsRUFBZCxDQUE1QixFQUErQztBQUMzQyxXQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGlCQUFpQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBNUM7QUFDQTtBQUNIOztBQUNELFNBQUsxRyxRQUFMLENBQWMsQ0FBZCxLQUFrQixLQUFLLEtBQUtBLFFBQUwsQ0FBYyxFQUFkLENBQXZCO0FBQ0EsU0FBS2lILE9BQUw7QUFFSCxHQXJWSTtBQXVWTDtBQUNBQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVk7QUFDdEJ6SixJQUFBQSxFQUFFLENBQUM2RCxXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS3JELFVBQXpCLEVBQXFDLEtBQXJDLEVBQTRDLENBQTVDOztBQUNBLFFBQUksS0FBSzhCLFFBQUwsQ0FBYyxDQUFkLElBQW1CLEVBQXZCLEVBQTJCO0FBQ3ZCLFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsaUJBQWlCLEtBQUs5RixHQUFMLENBQVM4RixNQUE1QztBQUNBO0FBQ0g7O0FBQ0QsU0FBSzFHLFFBQUwsQ0FBYyxDQUFkLEtBQWtCLEVBQWxCO0FBQ0EsU0FBS21ILE9BQUw7QUFFSCxHQWpXSTtBQW1XTDtBQUNBQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVk7QUFDdEIzSixJQUFBQSxFQUFFLENBQUM2RCxXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS3JELFVBQXpCLEVBQXFDLEtBQXJDLEVBQTRDLENBQTVDOztBQUNBLFFBQUksS0FBSzhCLFFBQUwsQ0FBYyxDQUFkLElBQW1CLEVBQXZCLEVBQTJCO0FBQ3ZCLFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsaUJBQWlCLEtBQUs5RixHQUFMLENBQVM4RixNQUE1QztBQUNBO0FBQ0g7O0FBQ0QsU0FBSzFHLFFBQUwsQ0FBYyxDQUFkLEtBQW1CLEVBQW5CO0FBQ0EsU0FBS3FILE9BQUw7QUFFSCxHQTdXSTtBQStXTDtBQUNBVixFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFLVyxTQUFMLEdBTGlCLENBS0M7QUFFckIsR0F2WEk7QUF5WEw7QUFDQVQsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQUk5RCxNQUFNLEdBQUdGLElBQUksQ0FBQ0UsTUFBTCxFQUFiOztBQUNBLFFBQUlBLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQzFDLFVBQUl3SCxTQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQWhCOztBQUNBLGNBQVF5RSxTQUFSO0FBQ0ksYUFBSyxDQUFMO0FBQVEsZUFBS0YsU0FBTCxHQUFSLENBQTBCOztBQUN0Qjs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLRyxRQUFMLENBQWMsS0FBS3pILFFBQW5CLEVBQVIsQ0FBc0M7O0FBQ2xDO0FBSlI7QUFNSCxLQVJELE1BUU8sSUFBSStDLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQUU7QUFDbkQsVUFBSTBILGVBQWUsR0FBRyxDQUF0Qjs7QUFDQSxVQUFJRixVQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkUsZUFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsVUFBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUtHLFNBQUwsR0FBUixDQUEwQjs7QUFDdEI7O0FBQ0osYUFBSyxDQUFMO0FBQVEsZUFBS0MsUUFBTCxDQUFjLEtBQUsvSCxNQUFuQixFQUFSLENBQW9DOztBQUNoQztBQUpSO0FBTUgsS0FUTSxNQVNBO0FBQUU7QUFDTCxVQUFJNkgsZ0JBQWUsR0FBRyxDQUF0Qjs7QUFDQSxVQUFJRixXQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkUsZ0JBQTNCLENBQWhCOztBQUNBLGNBQVFGLFdBQVI7QUFDSSxhQUFLLENBQUw7QUFBUSxlQUFLSyxlQUFMLENBQXFCLEtBQUsvSCxPQUExQixFQUFtQyxLQUFLRCxNQUF4QyxFQUFSLENBQXlEOztBQUNyRDs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLaUksVUFBTCxDQUFnQixLQUFLaEksT0FBckIsRUFBOEIsS0FBS0QsTUFBbkMsRUFBUixDQUFvRDs7QUFDaEQ7QUFKUjtBQU1IO0FBQ0osR0E3Wkk7QUErWkw7QUFDQWtILEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFJaEUsTUFBTSxHQUFHRixJQUFJLENBQUNFLE1BQUwsRUFBYjs7QUFDQSxRQUFJQSxNQUFNLEdBQUdGLElBQUksQ0FBQzBFLEdBQUwsQ0FBUyxHQUFULEVBQWMsS0FBS3ZILFFBQUwsQ0FBYyxDQUFkLENBQWQsQ0FBYixFQUE4QztBQUMxQyxVQUFJMEgsZUFBZSxHQUFHLENBQXRCO0FBQ0EsVUFBSUYsU0FBUyxHQUFHM0UsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQjJFLGVBQTNCLENBQWhCOztBQUNBLGNBQVFGLFNBQVI7QUFDSSxhQUFLLENBQUw7QUFBUSxlQUFLTyxLQUFMLENBQVcsS0FBSy9ILFFBQWhCLEVBQVIsQ0FBbUM7O0FBQy9COztBQUNKLGFBQUssQ0FBTDtBQUFRLGVBQUtnSSxVQUFMLENBQWdCLEtBQUtoSSxRQUFyQixFQUFSLENBQXdDOztBQUNwQztBQUpSO0FBTUgsS0FURCxNQVNPLElBQUkrQyxNQUFNLEdBQUdGLElBQUksQ0FBQzBFLEdBQUwsQ0FBUyxHQUFULEVBQWMsS0FBS3ZILFFBQUwsQ0FBYyxDQUFkLENBQWQsQ0FBYixFQUE4QztBQUFFO0FBQ25ELFVBQUkwSCxpQkFBZSxHQUFHLENBQXRCOztBQUNBLFVBQUlGLFdBQVMsR0FBRzNFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyRSxpQkFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsV0FBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUtTLElBQUwsQ0FBVSxLQUFLakksUUFBZixFQUFSLENBQWtDOztBQUM5Qjs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLa0ksSUFBTCxDQUFVLEtBQUtwSSxPQUFmLEVBQXdCLEtBQUtELE1BQTdCLEVBQVIsQ0FBOEM7O0FBQzFDO0FBSlI7QUFNSCxLQVRNLE1BU0E7QUFBRTtBQUNMLFVBQUk2SCxpQkFBZSxHQUFHLENBQXRCLENBREcsQ0FDc0I7O0FBQ3pCLFVBQUlGLFdBQVMsR0FBRzNFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyRSxpQkFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsV0FBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUtXLE9BQUwsQ0FBYSxLQUFLbkksUUFBbEIsRUFBUixDQUFxQzs7QUFDakM7O0FBQ0osYUFBSyxDQUFMO0FBQVEsZUFBS29JLEtBQUwsR0FBUixDQUFxQjs7QUFDakI7O0FBQ0osYUFBSyxDQUFMO0FBQVE7QUFDSjtBQU5SO0FBUUg7QUFDSixHQXRjSTtBQXdjTDtBQUNBbkIsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQUlsRSxNQUFNLEdBQUdGLElBQUksQ0FBQ0UsTUFBTCxFQUFiOztBQUNBLFFBQUlBLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQzFDLFVBQUkwSCxlQUFlLEdBQUcsQ0FBdEI7QUFDQSxVQUFJRixTQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkUsZUFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsU0FBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUthLFFBQUwsR0FBUixDQUF5Qjs7QUFDckI7O0FBQ0osYUFBSyxDQUFMO0FBQVEsZUFBS0MsT0FBTCxHQUFSLENBQXdCOztBQUNwQjs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLQyxRQUFMLEdBQVIsQ0FBeUI7O0FBQ3JCO0FBTlI7QUFRSCxLQVhELE1BV08sSUFBSXhGLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQUU7QUFDbkQsV0FBS3dJLFNBQUwsR0FEaUQsQ0FDOUI7QUFDdEIsS0FGTSxNQUVBO0FBQUU7QUFDTCxXQUFLQyxPQUFMLEdBREcsQ0FDYTtBQUNuQjtBQUNKLEdBamVJO0FBbWVMO0FBQ0F0QixFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBSXBFLE1BQU0sR0FBR0YsSUFBSSxDQUFDRSxNQUFMLEVBQWI7O0FBQ0EsUUFBSUEsTUFBTSxHQUFHRixJQUFJLENBQUMwRSxHQUFMLENBQVMsR0FBVCxFQUFjLEtBQUt2SCxRQUFMLENBQWMsQ0FBZCxDQUFkLENBQWIsRUFBOEM7QUFDMUMsVUFBSTBILGVBQWUsR0FBRyxDQUF0QjtBQUNBLFVBQUlGLFNBQVMsR0FBRzNFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyRSxlQUEzQixDQUFoQjs7QUFDQSxjQUFRRixTQUFSO0FBQ0ksYUFBSyxDQUFMO0FBQVEsZUFBS2tCLE1BQUwsQ0FBWSxLQUFLMUksUUFBakIsRUFBUixDQUFvQzs7QUFDaEM7O0FBQ0osYUFBSyxDQUFMO0FBQVEsZUFBSzJJLFVBQUwsR0FBUixDQUEyQjs7QUFDdkI7QUFKUjtBQU1ILEtBVEQsTUFTTyxJQUFJNUYsTUFBTSxHQUFHRixJQUFJLENBQUMwRSxHQUFMLENBQVMsSUFBVCxFQUFlLEtBQUt2SCxRQUFMLENBQWMsQ0FBZCxDQUFmLENBQWIsRUFBK0M7QUFBRTtBQUNwRCxXQUFLNEksUUFBTCxHQURrRCxDQUNqQztBQUNwQixLQUZNLE1BRUEsSUFBSTdGLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQUU7QUFDbkQsV0FBSzZJLE1BQUwsR0FEaUQsQ0FDbEM7QUFDbEIsS0FGTSxNQUVBO0FBQUU7QUFDTCxXQUFLQyxPQUFMLENBQWEsS0FBSzlJLFFBQWxCLEVBREcsQ0FDMEI7QUFDaEM7QUFDSixHQTVmSTtBQThmTDtBQUNBcUgsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLFNBQUswQixTQUFMLENBQWUsS0FBSy9JLFFBQXBCLEVBRGlCLENBRWpCO0FBQ0gsR0FsZ0JJO0FBb2dCTDtBQUVBK0ksRUFBQUEsU0FBUyxFQUFFLG1CQUFVQyxTQUFWLEVBQXFCO0FBQzVCLFFBQUlBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxFQUFuQixFQUF1QjtBQUNuQkEsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFoQjtBQUNBQSxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0EsV0FBS3BJLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixRQUF6QixHQUFvQyxLQUFLUyxHQUFMLENBQVM4RixNQUEvRDtBQUNBLFdBQUsxRyxRQUFMLENBQWMsQ0FBZCxLQUFvQixDQUFwQjtBQUNILEtBTEQsTUFLTztBQUNILFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isa0JBQWtCLEtBQUs5RixHQUFMLENBQVM4RixNQUE3QztBQUNIO0FBRUosR0FoaEJJO0FBa2hCTDtBQUNBWSxFQUFBQSxTQUFTLEVBQUUscUJBQVk7QUFDbkIsUUFBSS9ELFFBQVEsR0FBRyxLQUFLaUIsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJELENBQWY7O0FBQ0EsUUFBSTBELFFBQVEsSUFBSSxDQUFaLElBQWlCLEtBQUt1QixRQUFMLENBQWMsS0FBS2pGLE1BQW5CLEVBQTJCMEQsUUFBUSxDQUFDLENBQUQsQ0FBbkMsRUFBd0NBLFFBQVEsQ0FBQyxDQUFELENBQWhELEVBQXFELENBQXJELEtBQTJELEtBQWhGLEVBQXVGO0FBQ25GQSxNQUFBQSxRQUFRLEdBQUcsS0FBS2lCLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRCxDQUFYO0FBQ0g7O0FBQ0QsU0FBSyxJQUFJMkMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxJQUFJLElBQUlLLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBNUIsRUFBMkRQLENBQUMsRUFBNUQsRUFBZ0U7QUFDNUQsV0FBS3dDLHNCQUFMLENBQTRCLEtBQUtsRixPQUFqQyxFQUEwQyxLQUFLRCxNQUEvQyxFQUF1RDBELFFBQVEsQ0FBQyxDQUFELENBQS9ELEVBQW9FQSxRQUFRLENBQUMsQ0FBRCxDQUE1RSxFQUFpRixDQUFqRixFQUFvRixDQUFwRjtBQUNIOztBQUNELFFBQUksQ0FBQyxLQUFLSyxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFMLEVBQTBDO0FBQ3RDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDSDs7QUFDRCxTQUFLRyxRQUFMLENBQWMsQ0FBZCxLQUFvQixFQUFwQjtBQUNBMkIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksTUFBWjtBQUNBLFNBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF3QixTQUF4QixHQUFvQyxLQUFLUyxHQUFMLENBQVM4RixNQUEvRDtBQUNILEdBamlCSTtBQW1pQkxlLEVBQUFBLFFBQVEsRUFBRSxrQkFBVXVCLFNBQVYsRUFBcUI7QUFFM0IsUUFBSSxLQUFLcEYsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0FtSixNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLElBQWhCO0FBQ0FySCxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxjQUFaO0FBQ0FvSSxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0FBLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxXQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGlDQUF6QixHQUE2RCxLQUFLUyxHQUFMLENBQVM4RixNQUF4RjtBQUNILEtBUEQsTUFPTyxJQUFJLEtBQUs5QyxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQzVDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQW1KLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsSUFBaEI7QUFDQXJILE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGNBQVo7QUFDQW9JLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQUEsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBLFdBQUtwSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsaUNBQXpCLEdBQTZELEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXhGO0FBQ0gsS0FQTSxNQU9BO0FBQ0gsV0FBSzlGLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isa0JBQWtCLEtBQUs5RixHQUFMLENBQVM4RixNQUE3QztBQUVIO0FBQ0osR0F2akJJO0FBeWpCTDtBQUNBaUIsRUFBQUEsU0FBUyxFQUFFLHFCQUFZO0FBQ25CLFFBQUksS0FBSy9ELGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRDtBQUNBLFdBQUtlLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixjQUF6QixHQUEwQyxLQUFLUyxHQUFMLENBQVM4RixNQUFyRTtBQUNILEtBSEQsTUFHTyxJQUFJLEtBQUs5QyxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQzVDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQSxXQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsY0FBekIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7QUFDSCxLQUhNLE1BR0E7QUFDSCxVQUFJLEtBQUs5QyxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxLQUF1QyxLQUEzQyxFQUFrRDtBQUM5QyxhQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGtCQUFrQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBN0M7QUFDSCxPQUZELE1BRU87QUFDSCxhQUFLbEMsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0EsYUFBS2UsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGNBQXpCLEdBQTBDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXJFO0FBQ0g7QUFDSjtBQUNKLEdBemtCSTtBQTJrQkw7QUFDQWtCLEVBQUFBLFFBQVEsRUFBRSxrQkFBVWxGLFFBQVYsRUFBb0I7QUFDMUIsUUFBSSxLQUFLa0IsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxVQUFJNkUsVUFBVSxHQUFHLEtBQUtiLFFBQUwsQ0FBY25CLFFBQWQsRUFBd0IsQ0FBeEIsQ0FBakI7QUFDQSxVQUFJaUMsS0FBSyxHQUFJOUIsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQjJCLFVBQVUsQ0FBQy9CLE1BQXRDLENBQWI7O0FBQ0EsV0FBSyxJQUFJSCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQXBELEVBQXVEUCxDQUFDLEVBQXhELEVBQTREO0FBQ3hELGFBQUs4QyxnQkFBTCxDQUFzQixLQUFLeEYsT0FBM0IsRUFBb0MsS0FBS0QsTUFBekMsRUFBaUQ2RSxVQUFVLENBQUNDLEtBQUQsQ0FBVixDQUFrQixDQUFsQixDQUFqRCxFQUF1RUQsVUFBVSxDQUFDQyxLQUFELENBQVYsQ0FBa0IsQ0FBbEIsQ0FBdkUsRUFBNkYsQ0FBN0Y7QUFDSDs7QUFDRCxXQUFLL0QsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLFNBQXpCLEdBQXFDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWhFO0FBQ0gsS0FQRCxNQU9PO0FBQ0gsV0FBS2lCLFNBQUw7O0FBQ0EsVUFBSSxLQUFLL0QsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxhQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsU0FBekIsR0FBcUMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBaEU7QUFDSDtBQUNKO0FBQ0osR0ExbEJJO0FBNGxCTDtBQUNBb0IsRUFBQUEsVUFBVSxFQUFFLG9CQUFVOUUsU0FBVixFQUFxQk4sUUFBckIsRUFBK0I7QUFDdkMsU0FBSyxJQUFJRixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEVBQTNCLElBQWlDLENBQXJELEVBQXdEUCxDQUFDLEVBQXpELEVBQTZEO0FBQ3pELFVBQUlXLENBQUMsR0FBR04sSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQkwsUUFBUSxDQUFDQyxNQUFwQyxDQUFSO0FBQ0EsVUFBSVMsQ0FBQyxHQUFHUCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCTCxRQUFRLENBQUMsQ0FBRCxDQUFSLENBQVlDLE1BQXZDLENBQVI7QUFDQSxVQUFJc0csUUFBUSxHQUFHLEtBQUt0RixTQUFMLENBQWVqQixRQUFmLEVBQXdCLENBQXhCLENBQWY7O0FBQ0EsV0FBSyxJQUFJRixHQUFDLEdBQUcsQ0FBYixFQUFnQkEsR0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCa0csUUFBaEIsR0FBMkIsQ0FBdEMsQ0FBcEIsRUFBOER6RyxHQUFDLEVBQS9ELEVBQW1FO0FBQy9ELFlBQUksS0FBS21CLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsSUFBOEIsQ0FBbEMsRUFBcUM7QUFDakMsZUFBS3NDLHNCQUFMLENBQTRCaEMsU0FBNUIsRUFBdUNOLFFBQXZDLEVBQWlEUyxDQUFqRCxFQUFvREMsQ0FBcEQsRUFBdUQsQ0FBdkQsRUFBMEQsQ0FBMUQ7QUFDQSxlQUFLcEQsUUFBTCxDQUFjLENBQWQsS0FBbUI2QyxJQUFJLENBQUNxRyxJQUFMLENBQVVyRyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBMUIsQ0FBbkI7O0FBQ0EsY0FBSSxLQUFLL0MsUUFBTCxDQUFjLENBQWQsS0FBb0IsQ0FBeEIsRUFBMkI7QUFDdkIsaUJBQUtBLFFBQUwsQ0FBYyxDQUFkLElBQW1CLENBQW5CO0FBQ0g7QUFDSjtBQUVKO0FBQ0o7O0FBQ0QyQixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsU0FBS1osUUFBTCxDQUFjLENBQWQsS0FBb0IsRUFBcEI7QUFDQSxTQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsZUFBekIsR0FBMkMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBdEU7QUFDSCxHQWhuQkk7QUFrbkJMO0FBQ0FtQixFQUFBQSxlQUFlLEVBQUUseUJBQVU3RSxTQUFWLEVBQXFCTixRQUFyQixFQUErQjtBQUM1QyxRQUFJeUcsT0FBTyxHQUFHdEcsSUFBSSxDQUFDRSxNQUFMLEVBQWQ7O0FBQ0EsUUFBSSxLQUFLYSxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFVBQUl0QixLQUFLLEdBQUcsS0FBS3NGLFFBQUwsQ0FBYyxLQUFLaEUsTUFBbkIsRUFBMkIsQ0FBM0IsQ0FBWjs7QUFDQSxXQUFLLElBQUkyQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV3ZFLEtBQUssQ0FBQ29FLE1BQU4sR0FBZSxFQUExQixDQUFwQixFQUFtREgsQ0FBQyxFQUFwRCxFQUF3RDtBQUNwRDJHLFFBQUFBLE9BQU8sR0FBR3RHLElBQUksQ0FBQ0UsTUFBTCxFQUFWOztBQUNBLFlBQUlvRyxPQUFPLEdBQUcsR0FBZCxFQUFtQjtBQUNmLGVBQUszRSxpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNIO0FBQ0o7QUFDSjs7QUFDRCxRQUFJLEtBQUtrQixjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFVBQUlwQixJQUFJLEdBQUcsS0FBS29GLFFBQUwsQ0FBYyxLQUFLaEUsTUFBbkIsRUFBMkIsQ0FBM0IsQ0FBWDs7QUFDQSxXQUFLLElBQUkyQyxHQUFDLEdBQUcsQ0FBYixFQUFnQkEsR0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV3JFLElBQUksQ0FBQ2tFLE1BQUwsR0FBYyxFQUF6QixDQUFwQixFQUFrREgsR0FBQyxFQUFuRCxFQUF1RDtBQUNuRDJHLFFBQUFBLE9BQU8sR0FBR3RHLElBQUksQ0FBQ0UsTUFBTCxFQUFWOztBQUNBLFlBQUlvRyxPQUFPLEdBQUcsR0FBZCxFQUFtQjtBQUNmLGVBQUszRSxpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDQSxTQUFsQyxFQUE2QyxDQUE3QyxFQUFnRCxDQUFoRDtBQUNIO0FBQ0o7QUFDSjs7QUFDRHJCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQSxTQUFLWixRQUFMLENBQWMsQ0FBZCxLQUFvQixFQUFwQjtBQUNBLFNBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixpQkFBekIsR0FBNkMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBeEU7QUFDSCxHQTFvQkk7QUE0b0JMO0FBRUE7QUFDQXNCLEVBQUFBLFVBQVUsRUFBRSxvQkFBVWhJLFFBQVYsRUFBb0I7QUFDNUJBLElBQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxHQUFmO0FBQ0EyQixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxNQUFaO0FBQ0FaLElBQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxFQUFmO0FBQ0EsU0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGVBQXpCLEdBQTJDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXRFO0FBQ0gsR0FwcEJJO0FBc3BCTDtBQUNBcUIsRUFBQUEsS0FBSyxFQUFFLGVBQVUvSCxRQUFWLEVBQW9CO0FBQ3ZCLFFBQUlvSixJQUFJLEdBQUcsRUFBWDtBQUNBcEosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLElBQWY7O0FBQ0EsUUFBSTZDLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUFwQixFQUF5QjtBQUNyQi9DLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxHQUFmO0FBQ0FvSixNQUFBQSxJQUFJLEdBQUcsU0FBUDtBQUNBcEosTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDSCxLQUpELE1BSU87QUFDSEEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWY7QUFDQUEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQW9KLE1BQUFBLElBQUksR0FBRyxNQUFQO0FBQ0g7O0FBQ0R6SCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLE9BQXpCLEdBQW1DaUosSUFBbkMsR0FBMEMsSUFBMUMsR0FBaUQsS0FBS3hJLEdBQUwsQ0FBUzhGLE1BQTVFO0FBQ0gsR0FycUJJO0FBdXFCTDtBQUNBdUIsRUFBQUEsSUFBSSxFQUFFLGNBQVVqSSxRQUFWLEVBQW9CO0FBQ3RCQSxJQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWU2QyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBL0I7QUFDQXBCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQVosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQSxTQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsUUFBekIsR0FBb0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSCxHQTdxQkk7QUErcUJMO0FBQ0F5QixFQUFBQSxPQUFPLEVBQUUsaUJBQVVuSSxRQUFWLEVBQW9CO0FBQ3pCQSxJQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWU2QyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBL0I7QUFDQXBCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLElBQVo7QUFDQVosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQSxTQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsY0FBekIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7QUFDSCxHQXJyQkk7QUF1ckJMO0FBQ0F3QixFQUFBQSxJQUFJLEVBQUUsY0FBVWxGLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCO0FBQ2pDLFFBQUksS0FBS2tCLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsVUFBSWhCLElBQUksR0FBRyxLQUFLZ0YsUUFBTCxDQUFjbkIsUUFBZCxFQUF3QixDQUF4QixDQUFYOztBQUNBLFdBQUssSUFBSUYsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0ssSUFBSSxDQUFDQyxLQUFMLENBQVdqRSxJQUFJLENBQUM4RCxNQUFMLEdBQWMsRUFBekIsQ0FBcEIsRUFBa0RILENBQUMsRUFBbkQsRUFBdUQ7QUFDbkQsWUFBSUssSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGVBQUt5QixpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNIO0FBQ0o7QUFDSjs7QUFDRCxRQUFJLEtBQUtrQixjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFVBQUluQixLQUFLLEdBQUcsS0FBS21GLFFBQUwsQ0FBY25CLFFBQWQsRUFBd0IsQ0FBeEIsQ0FBWjs7QUFDQSxXQUFLLElBQUlGLEdBQUMsR0FBRyxDQUFiLEVBQWdCQSxHQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXcEUsS0FBSyxDQUFDaUUsTUFBTixHQUFlLEVBQTFCLENBQXBCLEVBQW1ESCxHQUFDLEVBQXBELEVBQXdEO0FBQ3BELFlBQUlLLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUFwQixFQUF5QjtBQUNyQixlQUFLeUIsaUJBQUwsQ0FBdUJ4QixTQUF2QixFQUFrQ04sUUFBbEMsRUFBNEMsQ0FBNUMsRUFBK0MsQ0FBL0M7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsUUFBSSxLQUFLa0IsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxVQUFJd0osS0FBSyxHQUFHLEtBQUt4RixRQUFMLENBQWNuQixRQUFkLEVBQXdCLENBQXhCLENBQVo7O0FBQ0EsV0FBSyxJQUFJRixHQUFDLEdBQUcsQ0FBYixFQUFnQkEsR0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV3VHLEtBQUssQ0FBQzFHLE1BQU4sR0FBZSxFQUExQixDQUFwQixFQUFtREgsR0FBQyxFQUFwRCxFQUF3RDtBQUNwRCxZQUFJSyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBcEIsRUFBeUI7QUFDckIsZUFBS3lCLGlCQUFMLENBQXVCeEIsU0FBdkIsRUFBa0NOLFFBQWxDLEVBQTRDLENBQTVDLEVBQStDLENBQS9DO0FBQ0g7QUFDSjtBQUNKOztBQUNELFFBQUksS0FBS2tCLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsVUFBSWpCLEtBQUssR0FBRyxLQUFLaUYsUUFBTCxDQUFjbkIsUUFBZCxFQUF3QixDQUF4QixDQUFaOztBQUNBLFdBQUssSUFBSUYsR0FBQyxHQUFHLENBQWIsRUFBZ0JBLEdBQUMsR0FBR0ssSUFBSSxDQUFDQyxLQUFMLENBQVdsRSxLQUFLLENBQUMrRCxNQUFOLEdBQWUsRUFBMUIsQ0FBcEIsRUFBbURILEdBQUMsRUFBcEQsRUFBd0Q7QUFDcEQsWUFBSUssSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGVBQUt5QixpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNIO0FBQ0o7QUFDSjs7QUFDRGYsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksS0FBWjtBQUNBLFNBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixTQUF6QixHQUFxQyxLQUFLUyxHQUFMLENBQVM4RixNQUFoRTtBQUNILEdBM3RCSTtBQTZ0QkwwQixFQUFBQSxLQUFLLEVBQUUsaUJBQVk7QUFDZixRQUFJLEtBQUt4RSxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQSxXQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsZUFBekIsR0FBMkMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBdEU7QUFDSCxLQUhELE1BR08sSUFBSSxLQUFLOUMsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUM1QyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0EsV0FBS2UsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGVBQXpCLEdBQTJDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXRFO0FBQ0gsS0FITSxNQUdBLElBQUksS0FBSzlDLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDNUMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRDtBQUNBLFdBQUtHLFFBQUwsQ0FBYyxDQUFkLEtBQW9CNkMsSUFBSSxDQUFDcUcsSUFBTCxDQUFVckcsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTFCLENBQXBCO0FBQ0EsV0FBS25DLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixHQUFsQixHQUF3QixlQUF4QixHQUEwQyxLQUFLUyxHQUFMLENBQVM4RixNQUFyRTtBQUNILEtBSk0sTUFJQSxJQUFJLEtBQUs5QyxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQzVDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQSxXQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsR0FBbEIsR0FBd0IsZUFBeEIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7QUFDSDtBQUNKLEdBNXVCSTtBQTZ1Qkw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0EyQixFQUFBQSxRQUFRLEVBQUUsb0JBQVk7QUFDbEIsUUFBSSxLQUFLekUsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELEVBQXJEO0FBQ0E4QixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxNQUFaO0FBQ0EsV0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLFNBQXpCLEdBQXFDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWhFO0FBQ0gsS0FKRCxNQUlPO0FBQ0gsV0FBSzlGLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsbUJBQW1CLEtBQUs5RixHQUFMLENBQVM4RixNQUE5QztBQUNIO0FBQ0osR0E1eEJJO0FBOHhCTDtBQUNBOEIsRUFBQUEsU0FBUyxFQUFFLHFCQUFZO0FBQ25CLFFBQUksS0FBSzVFLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxFQUFyRDtBQUNBOEIsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksT0FBWjtBQUNBLFdBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixVQUF6QixHQUFzQyxLQUFLUyxHQUFMLENBQVM4RixNQUFqRTtBQUNILEtBSkQsTUFJTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLG1CQUFtQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBOUM7QUFDSDtBQUNKLEdBdnlCSTtBQXl5Qkw7QUFDQStCLEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixRQUFJLEtBQUs3RSxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQThCLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLE1BQVo7QUFDQSxXQUFLWixRQUFMLENBQWMsQ0FBZCxLQUFvQixFQUFwQjtBQUNBLFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixTQUF6QixHQUFxQyxLQUFLUyxHQUFMLENBQVM4RixNQUFoRTtBQUNILEtBTEQsTUFLTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLGtCQUFrQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBN0M7QUFDSDtBQUNKLEdBbnpCSTtBQXF6Qkw7QUFDQTRCLEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixRQUFJLEtBQUsxRSxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxLQUF1QyxLQUEzQyxFQUFrRDtBQUM5QyxXQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGtCQUFrQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBN0M7QUFDQTtBQUNIOztBQUNELFNBQUtsQyxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQThCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBMEIsU0FBMUIsR0FBc0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBakU7QUFDSCxHQTl6Qkk7QUFnMEJMNkIsRUFBQUEsUUFBUSxFQUFFLG9CQUFZO0FBQ2xCLFNBQUsvRCxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQThCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBMEIsWUFBMUIsR0FBeUMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBcEU7QUFDSCxHQXAwQkk7QUFzMEJMO0FBRUFpQyxFQUFBQSxVQUFVLEVBQUUsc0JBQVk7QUFDcEIsUUFBSSxLQUFLL0UsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELEVBQXJEO0FBQ0E4QixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsV0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQTBCLFdBQTFCLEdBQXdDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQW5FO0FBQ0gsS0FKRCxNQUlPO0FBQ0gsV0FBSzlGLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isb0JBQW9CLEtBQUs5RixHQUFMLENBQVM4RixNQUEvQztBQUNIO0FBQ0osR0FoMUJJO0FBazFCTGdDLEVBQUFBLE1BQU0sRUFBRSxnQkFBVU0sU0FBVixFQUFxQjtBQUN6QixRQUFJLEtBQUtwRixjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsRUFBckQ7QUFDQW1KLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLEtBQW1CLENBQW5CO0FBQ0FySCxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsV0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLFdBQXpCLEdBQXVDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWxFO0FBQ0gsS0FMRCxNQUtPO0FBQ0gsV0FBSzlGLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isb0JBQW9CLEtBQUs5RixHQUFMLENBQVM4RixNQUEvQztBQUNIO0FBQ0osR0EzMUJJO0FBNjFCTG1DLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNoQixRQUFJLEtBQUtqRixjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsRUFBckQ7QUFDQThCLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQSxXQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsV0FBekIsR0FBdUMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBbEU7QUFDSCxLQUpELE1BSU87QUFDSCxXQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixvQkFBb0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQS9DO0FBQ0g7QUFDSixHQXIyQkk7QUF1MkJMa0MsRUFBQUEsUUFBUSxFQUFFLG9CQUFZO0FBQ2xCLFFBQUksS0FBS2hGLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxFQUFyRDtBQUNBOEIsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksS0FBWjtBQUNBLFdBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixVQUF6QixHQUFzQyxLQUFLUyxHQUFMLENBQVM4RixNQUFqRTtBQUNILEtBSkQsTUFJTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLG9CQUFvQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBL0M7QUFDSDtBQUNKLEdBLzJCSTtBQWkzQkxvQyxFQUFBQSxPQUFPLEVBQUUsaUJBQVVFLFNBQVYsRUFBcUI7QUFDMUIsUUFBSSxLQUFLcEYsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELEVBQXJEO0FBQ0FtSixNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixLQUFtQixDQUFuQjtBQUNBckgsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksTUFBWjtBQUNBLFdBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixjQUF6QixHQUEwQyxLQUFLUyxHQUFMLENBQVM4RixNQUFyRTtBQUNILEtBTEQsTUFLTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLG9CQUFvQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBL0M7QUFDSDtBQUNKLEdBMTNCSTtBQTQzQkw7QUFDQTtBQUNBNEMsRUFBQUEsV0FBVyxFQUFFLHFCQUFVdEosUUFBVixFQUFvQjtBQUM3QkEsSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFjLEtBQUtBLFFBQVEsQ0FBQyxDQUFELENBQVIsR0FBYyxJQUFqQzs7QUFDQSxRQUFJQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWVBLFFBQVEsQ0FBQyxFQUFELENBQTNCLEVBQWlDO0FBQzdCO0FBQ0FBLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxFQUFmO0FBQ0FBLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZUEsUUFBUSxDQUFDLEVBQUQsQ0FBdkI7QUFDQUEsTUFBQUEsUUFBUSxDQUFDLEVBQUQsQ0FBUixHQUFlQSxRQUFRLENBQUMsRUFBRCxDQUFSLEdBQWUsR0FBOUI7QUFDQUEsTUFBQUEsUUFBUSxDQUFDLEVBQUQsQ0FBUjtBQUNILEtBTkQsTUFNTyxJQUFJQSxRQUFRLENBQUMsQ0FBRCxDQUFSLEdBQWMsQ0FBbEIsRUFBcUI7QUFDeEJBLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxFQUFmO0FBQ0FBLE1BQUFBLFFBQVEsQ0FBQyxFQUFELENBQVIsR0FBZUEsUUFBUSxDQUFDLEVBQUQsQ0FBUixHQUFlLEdBQTlCOztBQUNBLFVBQUlBLFFBQVEsQ0FBQyxFQUFELENBQVIsSUFBZ0IsR0FBcEIsRUFBeUI7QUFDckJBLFFBQUFBLFFBQVEsQ0FBQyxFQUFELENBQVIsSUFBZ0IsR0FBaEI7QUFDSDs7QUFDREEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixHQUFjQSxRQUFRLENBQUMsRUFBRCxDQUFSLEdBQWVBLFFBQVEsQ0FBQyxDQUFELENBQXJDO0FBQ0FBLE1BQUFBLFFBQVEsQ0FBQyxFQUFELENBQVI7O0FBQ0EsVUFBSUEsUUFBUSxDQUFDLEVBQUQsQ0FBUixHQUFlLENBQW5CLEVBQXNCO0FBQ2xCQSxRQUFBQSxRQUFRLENBQUMsRUFBRCxDQUFSLEdBQWUsQ0FBZjtBQUNIO0FBQ0o7O0FBQ0QsUUFBSUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlQSxRQUFRLENBQUMsQ0FBRCxDQUEzQixFQUFnQztBQUM1QkEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixHQUFjQSxRQUFRLENBQUMsQ0FBRCxDQUF0QjtBQUNIO0FBQ0osR0FyNUJJO0FBczVCTDtBQUNBdUosRUFBQUEsV0FBVyxFQUFFLHFCQUFVUCxTQUFWLEVBQXFCO0FBQzlCLFNBQUt4RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQW1KLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGNBQVo7QUFDQW9JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGFBQXpCLEdBQXlDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXBFO0FBQ0gsR0E3NUJJO0FBKzVCTDtBQUNBOEMsRUFBQUEsWUFBWSxFQUFFLHNCQUFVUixTQUFWLEVBQXFCO0FBQy9CLFNBQUt4RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQW1KLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGVBQVo7QUFDQW9JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxTQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLHNCQUF6QixHQUFrRCxLQUFLUyxHQUFMLENBQVM4RixNQUE3RTtBQUNILEdBdDZCSTtBQXc2Qkw7QUFDQStDLEVBQUFBLFdBQVcsRUFBRSxxQkFBVVQsU0FBVixFQUFxQjtBQUM5QixTQUFLeEUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0FtSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FySCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxlQUFaO0FBQ0FvSSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0EsU0FBS3BJLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixvQkFBekIsR0FBZ0QsS0FBS1MsR0FBTCxDQUFTOEYsTUFBM0U7QUFDSCxHQS82Qkk7QUFpN0JMZ0QsRUFBQUEsVUFBVSxFQUFFLG9CQUFVVixTQUFWLEVBQXFCdEcsUUFBckIsRUFBK0JRLEdBQS9CLEVBQW9DO0FBQzVDdkIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksYUFBWjtBQUNBLFFBQUkrSSxXQUFXLEdBQUd6RyxHQUFsQjtBQUNBLFFBQUkwRyxRQUFRLEdBQUcsS0FBS2pHLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBZjtBQUNBLFFBQUltSCxRQUFRLEdBQUcsS0FBS2xHLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBZjtBQUNBLFFBQUlvSCxTQUFTLEdBQUcsS0FBS25HLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBaEI7O0FBQ0EsUUFBSWtILFFBQVEsR0FBRyxDQUFYLElBQWdCQyxRQUFRLEdBQUcsQ0FBM0IsSUFBZ0NDLFNBQVMsR0FBRyxDQUFoRCxFQUFtRDtBQUMvQ2QsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFoQjtBQUNIOztBQUNELFFBQUk5RixHQUFHLEdBQUcwRyxRQUFRLEdBQUdDLFFBQVgsR0FBc0JDLFNBQWhDLEVBQTJDO0FBQ3ZDSCxNQUFBQSxXQUFXLEdBQUdFLFFBQVEsR0FBR0MsU0FBWCxHQUF1QkYsUUFBckM7QUFDSDs7QUFDRCxTQUFLLElBQUlwSCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHbUgsV0FBcEIsRUFBaUNuSCxDQUFDLEVBQWxDLEVBQXNDO0FBQ2xDYixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxnQkFBWjs7QUFDQSxVQUFJZ0osUUFBUSxHQUFHLENBQWYsRUFBa0I7QUFDZCxhQUFLSCxXQUFMLENBQWlCVCxTQUFqQjtBQUNILE9BRkQsTUFFTztBQUNILFlBQUljLFNBQVMsSUFBSSxDQUFqQixFQUFvQjtBQUNoQixlQUFLUCxXQUFMLENBQWlCUCxTQUFqQjtBQUNILFNBRkQsTUFFTyxJQUFJYSxRQUFRLElBQUksQ0FBaEIsRUFBbUI7QUFDdEIsZUFBS0wsWUFBTCxDQUFrQlIsU0FBbEI7QUFDSCxTQUZNLE1BRUE7QUFDSCxjQUFJbkcsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGlCQUFLd0csV0FBTCxDQUFpQlAsU0FBakI7QUFDSCxXQUZELE1BRU87QUFDSCxpQkFBS1EsWUFBTCxDQUFrQlIsU0FBbEI7QUFDSDtBQUNKO0FBQ0o7QUFDSjtBQUNKLEdBLzhCSTtBQWk5QkxlLEVBQUFBLFVBQVUsRUFBRSxvQkFBVWYsU0FBVixFQUFxQjtBQUM3QixTQUFLeEUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0FtSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0FBLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDRCQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGVBQXpCLEdBQTJDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXRFO0FBRUgsR0F4OUJJO0FBMDlCTHNELEVBQUFBLGVBQWUsRUFBRSx5QkFBVWhCLFNBQVYsRUFBcUI7QUFDbEMsU0FBS3hFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRDtBQUNBbUosSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FBLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGtDQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLG9CQUF6QixHQUFnRCxLQUFLUyxHQUFMLENBQVM4RixNQUEzRTtBQUVILEdBbCtCSTtBQW8rQkx1RCxFQUFBQSxXQUFXLEVBQUUscUJBQVVqQixTQUFWLEVBQXFCO0FBQzlCLFNBQUt4RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQW1KLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQUEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBckgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksNkJBQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsZUFBekIsR0FBMkMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBdEU7QUFDSCxHQTErQkk7QUE0K0JMd0QsRUFBQUEsY0FBYyxFQUFFLHdCQUFVbEIsU0FBVixFQUFxQnRHLFFBQXJCLEVBQStCUSxHQUEvQixFQUFvQztBQUNoRHZCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGlCQUFaO0FBQ0EsUUFBSStJLFdBQVcsR0FBR3pHLEdBQWxCO0FBQ0EsUUFBSWlILE9BQU8sR0FBRyxLQUFLeEcsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFkO0FBQ0EsUUFBSTBILFlBQVksR0FBRyxLQUFLekcsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFuQjtBQUNBLFFBQUkySCxRQUFRLEdBQUcsS0FBSzFHLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBZjs7QUFDQSxRQUFJeUgsT0FBTyxHQUFHLENBQVYsSUFBZUMsWUFBWSxHQUFHLENBQTlCLElBQW1DQyxRQUFRLEdBQUcsQ0FBbEQsRUFBcUQsQ0FDcEQ7O0FBQ0QsUUFBSW5ILEdBQUcsR0FBR2lILE9BQU8sR0FBR0UsUUFBVixHQUFxQkQsWUFBL0IsRUFBNkM7QUFDekNULE1BQUFBLFdBQVcsR0FBR1EsT0FBTyxHQUFHRSxRQUFWLEdBQXFCRCxZQUFuQztBQUNIOztBQUNELFNBQUssSUFBSTVILENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdtSCxXQUFwQixFQUFpQ25ILENBQUMsRUFBbEMsRUFBc0M7QUFDbENiLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLG9CQUFaOztBQUNBLFVBQUl5SixRQUFRLEdBQUcsQ0FBZixFQUFrQjtBQUNkLGFBQUtKLFdBQUwsQ0FBaUJqQixTQUFqQjtBQUNILE9BRkQsTUFFTztBQUNILFlBQUltQixPQUFPLElBQUksQ0FBZixFQUFrQjtBQUNkLGVBQUtILGVBQUwsQ0FBcUJoQixTQUFyQjtBQUNILFNBRkQsTUFFTztBQUNILGVBQUtlLFVBQUwsQ0FBZ0JmLFNBQWhCO0FBQ0g7QUFDSjtBQUNKO0FBQ0osR0FuZ0NJO0FBcWdDTHNCLEVBQUFBLFdBQVcsRUFBRSxxQkFBVXRCLFNBQVYsRUFBcUI7QUFDOUIsU0FBS3hFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxFQUFsRCxFQUFzRCxDQUF0RDtBQUNBbUosSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFoQjtBQUNBckgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksY0FBWjtBQUNBb0ksSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFoQjtBQUNBLFNBQUtwSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsaUJBQXpCLEdBQTZDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXhFO0FBQ0gsR0EzZ0NJO0FBNmdDTDZELEVBQUFBLE9BQU8sRUFBRSxpQkFBVXZCLFNBQVYsRUFBcUI7QUFDMUIsU0FBS3hFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxFQUFsRCxFQUFzRCxDQUF0RDtBQUNBbUosSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQSxRQUFJd0IsSUFBSSxHQUFHM0gsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUFYO0FBQ0FpRyxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCd0IsSUFBaEI7QUFDQXhCLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFVBQVo7O0FBQ0EsUUFBSTRKLElBQUksSUFBSSxDQUFaLEVBQWU7QUFDWHhCLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxXQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLEtBQXpCLEdBQWlDLE1BQWpDLEdBQTBDcUssSUFBMUMsR0FBaUQsU0FBakQsR0FBNkQsS0FBSzVKLEdBQUwsQ0FBUzhGLE1BQXhGO0FBQ0gsS0FIRCxNQUdPO0FBQ0hzQyxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0EsV0FBS3BJLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixLQUF6QixHQUFpQyxNQUFqQyxHQUEwQ3FLLElBQTFDLEdBQWlELFNBQWpELEdBQTZELEtBQUs1SixHQUFMLENBQVM4RixNQUF4RjtBQUNIO0FBQ0osR0EzaENJO0FBNmhDTCtELEVBQUFBLE9BQU8sRUFBRSxpQkFBVXpCLFNBQVYsRUFBcUI7QUFDMUIsU0FBS3hFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxFQUFsRCxFQUFzRCxDQUF0RDtBQUNBLFFBQUkySyxJQUFJLEdBQUczSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQVg7QUFDQWlHLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0J3QixJQUFoQjtBQUNBeEIsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFoQjtBQUNBckgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksVUFBWjs7QUFDQSxRQUFJNEosSUFBSSxJQUFJLENBQVosRUFBZTtBQUNYeEIsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFoQjtBQUNBLFdBQUtwSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsS0FBekIsR0FBaUMsTUFBakMsR0FBMENxSyxJQUExQyxHQUFpRCxTQUFqRCxHQUE2RCxLQUFLNUosR0FBTCxDQUFTOEYsTUFBeEY7QUFDSCxLQUhELE1BR087QUFDSHNDLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxXQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLEtBQXpCLEdBQWlDLE1BQWpDLEdBQTBDcUssSUFBMUMsR0FBaUQsU0FBakQsR0FBNkQsS0FBSzVKLEdBQUwsQ0FBUzhGLE1BQXhGO0FBQ0g7O0FBQ0QsU0FBSzlGLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixLQUF6QixHQUFpQyxNQUFqQyxHQUEwQ3FLLElBQTFDLEdBQWlELFNBQWpELEdBQTZELEtBQUs1SixHQUFMLENBQVM4RixNQUF4RjtBQUNILEdBM2lDSTtBQTZpQ0xnRSxFQUFBQSxTQUFTLEVBQUUsbUJBQVUxQixTQUFWLEVBQXFCO0FBQzVCLFNBQUt4RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQW1KLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFlBQVo7QUFDQW9JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGtCQUF6QixHQUE4QyxLQUFLUyxHQUFMLENBQVM4RixNQUF6RTtBQUNILEdBbmpDSTtBQXFqQ0xpRSxFQUFBQSxRQUFRLEVBQUUsa0JBQVUzQixTQUFWLEVBQXFCO0FBQzNCLFNBQUt4RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQW1KLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLEtBQW1CLENBQW5CO0FBQ0EsUUFBSXdCLElBQUksR0FBRzNILElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBWDtBQUNBaUcsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQndCLElBQWhCO0FBQ0F4QixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0FySCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxXQUFaOztBQUNBLFFBQUk0SixJQUFJLElBQUksQ0FBWixFQUFlO0FBQ1h4QixNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0EsV0FBS3BJLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixNQUF6QixHQUFrQyxNQUFsQyxHQUEyQ3FLLElBQTNDLEdBQWtELFdBQWxELEdBQWdFLEtBQUs1SixHQUFMLENBQVM4RixNQUEzRjtBQUNILEtBSEQsTUFHTyxJQUFJOEQsSUFBSSxHQUFHLENBQVgsRUFBYztBQUNqQnhCLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxXQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLFVBQXpCLEdBQXNDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWpFO0FBQ0gsS0FITSxNQUdBO0FBQ0hzQyxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0EsV0FBS3BJLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixZQUF6QixHQUF3Q3FLLElBQXhDLEdBQStDLFFBQS9DLEdBQTBELEtBQUs1SixHQUFMLENBQVM4RixNQUFyRjtBQUNIO0FBRUosR0F2a0NJO0FBeWtDTGtFLEVBQUFBLFVBQVUsRUFBRSxvQkFBVTVCLFNBQVYsRUFBcUJ0RyxRQUFyQixFQUErQlEsR0FBL0IsRUFBb0M7QUFDNUN2QixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxhQUFaO0FBQ0EsUUFBSStJLFdBQVcsR0FBR3pHLEdBQWxCO0FBQ0EsUUFBSWxFLE9BQU8sR0FBRyxLQUFLMkUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQTdDO0FBQ0EsUUFBSTdKLEtBQUssR0FBRyxLQUFLd0UsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQTNDO0FBQ0EsUUFBSTlKLEdBQUcsR0FBRyxLQUFLeUUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQXpDO0FBQ0EsUUFBSTZCLElBQUksR0FBRyxLQUFLbEgsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixDQUFYO0FBQ0EsUUFBSXRELElBQUksR0FBRyxLQUFLdUUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixDQUFYOztBQUNBLFFBQUkxRCxPQUFPLEdBQUcsQ0FBVixJQUFlRyxLQUFLLEdBQUcsQ0FBdkIsSUFBNEJELEdBQUcsR0FBRyxDQUFsQyxJQUF1QzJMLElBQUksR0FBRyxDQUE5QyxJQUFtRHpMLElBQUksR0FBRyxDQUE5RCxFQUFpRTtBQUM3RCxXQUFLd0IsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGlCQUF6QixHQUE2QyxLQUFLUyxHQUFMLENBQVM4RixNQUF4RTtBQUNIOztBQUNELFFBQUl4RCxHQUFHLEdBQUdMLElBQUksQ0FBQ0MsS0FBTCxDQUFXOUQsT0FBTyxHQUFHRyxLQUFLLEdBQUcsQ0FBbEIsR0FBc0JELEdBQUcsR0FBRyxDQUE1QixHQUFnQzJMLElBQUksR0FBRyxDQUF2QyxHQUEyQ3pMLElBQUksR0FBRyxDQUE3RCxDQUFWLEVBQTJFO0FBQ3ZFdUssTUFBQUEsV0FBVyxHQUFHOUcsSUFBSSxDQUFDQyxLQUFMLENBQVc5RCxPQUFPLEdBQUdHLEtBQUssR0FBRyxDQUFsQixHQUFzQkQsR0FBRyxHQUFHLENBQTVCLEdBQWdDMkwsSUFBSSxHQUFHLENBQXZDLEdBQTJDekwsSUFBSSxHQUFHLENBQTdELENBQWQ7QUFDSDs7QUFDRCxTQUFLLElBQUlvRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHbUgsV0FBcEIsRUFBaUNuSCxDQUFDLEVBQWxDLEVBQXNDO0FBQ2xDYixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxnQkFBWjs7QUFDQSxVQUFJNUIsT0FBTyxHQUFHLENBQWQsRUFBaUI7QUFDYixhQUFLc0wsV0FBTCxDQUFpQnRCLFNBQWpCOztBQUNBLFlBQUluRyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBaEIsSUFBdUJpRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixJQUFrQixDQUE3QyxFQUFnRDtBQUM1Q0EsVUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDSDtBQUNKLE9BTEQsTUFLTyxJQUFJN0osS0FBSyxHQUFHLENBQVosRUFBZTtBQUNsQixhQUFLdUwsU0FBTCxDQUFlMUIsU0FBZjs7QUFDQSxZQUFJbkcsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLElBQWhCLElBQXdCaUcsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsSUFBa0IsQ0FBOUMsRUFBaUQ7QUFDN0NBLFVBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLEtBQW1CLENBQW5CO0FBQ0g7QUFDSixPQUxNLE1BS0EsSUFBSTlKLEdBQUcsR0FBRyxDQUFWLEVBQWE7QUFDaEIsYUFBS3VMLE9BQUwsQ0FBYXpCLFNBQWI7O0FBQ0EsWUFBSW5HLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixJQUFoQixJQUF3QmlHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLElBQWtCLENBQTlDLEVBQWlEO0FBQzdDQSxVQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixLQUFtQixDQUFuQjtBQUNIO0FBQ0osT0FMTSxNQUtBLElBQUk2QixJQUFJLEdBQUcsQ0FBWCxFQUFjO0FBQ2pCLGFBQUtOLE9BQUwsQ0FBYXZCLFNBQWI7QUFDSCxPQUZNLE1BRUE7QUFDSCxhQUFLMkIsUUFBTCxDQUFjM0IsU0FBZDtBQUNIO0FBQ0o7QUFDSixHQTltQ0k7QUFnbkNMOEIsRUFBQUEsV0FBVyxFQUFFLHFCQUFVOUIsU0FBVixFQUFxQjtBQUM5QkEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGFBQVo7QUFDQW9JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGlCQUF6QixHQUE2QyxLQUFLUyxHQUFMLENBQVM4RixNQUF4RTtBQUNILEdBcm5DSTtBQXVuQ0xxRSxFQUFBQSxPQUFPLEVBQUUsaUJBQVUvQixTQUFWLEVBQXFCO0FBQzFCQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixLQUFtQixDQUFuQjtBQUNBQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCbkcsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUFoQjtBQUNBcEIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksU0FBWjtBQUNBLFFBQUk0SixJQUFJLEdBQUczSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQVg7O0FBQ0EsUUFBSXlILElBQUksSUFBSSxDQUFaLEVBQWU7QUFDWHhCLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxXQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGdCQUF6QixHQUE0QyxLQUFLUyxHQUFMLENBQVM4RixNQUF2RTtBQUNILEtBSEQsTUFHTztBQUNIc0MsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBLFdBQUtwSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsZ0JBQXpCLEdBQTRDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXZFO0FBQ0g7QUFDSixHQW5vQ0k7QUFxb0NMc0UsRUFBQUEsU0FBUyxFQUFFLG1CQUFVaEMsU0FBVixFQUFxQjtBQUM1QkEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQXJILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFdBQVo7QUFDQW9JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGlCQUF6QixHQUE2QyxLQUFLUyxHQUFMLENBQVM4RixNQUF4RTtBQUNILEdBMW9DSTtBQTRvQ0x1RSxFQUFBQSxTQUFTLEVBQUUsbUJBQVVqQyxTQUFWLEVBQXFCdEcsUUFBckIsRUFBK0JRLEdBQS9CLEVBQW9DO0FBQzNDdkIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksWUFBWjtBQUNBLFFBQUlzSyxPQUFPLEdBQUcsS0FBZCxDQUYyQyxDQUczQztBQUNBO0FBQ0E7O0FBQ0EsU0FBSyxJQUFJMUksQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR1UsR0FBcEIsRUFBeUJWLENBQUMsRUFBMUIsRUFBOEI7QUFDMUIsVUFBSXhELE9BQU8sR0FBRyxLQUFLMkUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQTdDO0FBQ0EsVUFBSTdKLEtBQUssR0FBRyxLQUFLd0UsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQTNDO0FBQ0EsVUFBSTlKLEdBQUcsR0FBRyxLQUFLeUUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQXpDOztBQUNBLFVBQUloSyxPQUFPLEdBQUcsQ0FBVixJQUFlNkQsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQW5DLEVBQXdDO0FBQ3BDLGFBQUsrSCxXQUFMLENBQWlCOUIsU0FBakI7QUFDQWtDLFFBQUFBLE9BQU8sR0FBRyxJQUFWO0FBQ0gsT0FIRCxNQUdPLElBQUkvTCxLQUFLLEdBQUcsQ0FBUixJQUFhMEQsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTdCLElBQW9DLEtBQUsvQyxRQUFMLENBQWMsQ0FBZCxLQUFvQixHQUE1RCxFQUFpRTtBQUNwRSxhQUFLZ0wsU0FBTCxDQUFlaEMsU0FBZjtBQUNBa0MsUUFBQUEsT0FBTyxHQUFHLElBQVY7QUFDSCxPQUhNLE1BR0EsSUFBSWhNLEdBQUcsR0FBRyxDQUFOLElBQVcyRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBM0IsSUFBa0MsS0FBSy9DLFFBQUwsQ0FBYyxDQUFkLEtBQW9CLEdBQTFELEVBQStEO0FBQ2xFLGFBQUsrSyxPQUFMLENBQWEvQixTQUFiO0FBQ0FrQyxRQUFBQSxPQUFPLEdBQUcsSUFBVjtBQUNIO0FBQ0o7QUFDRDs7Ozs7Ozs7QUFRSCxHQXpxQ0k7QUEycUNMO0FBRUFDLEVBQUFBLFVBQVUsRUFBRSxvQkFBVW5MLFFBQVYsRUFBb0I7QUFDNUIsUUFBSUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWYsSUFBc0JBLFFBQVEsQ0FBQyxDQUFELENBQVIsR0FBY0EsUUFBUSxDQUFDLENBQUQsQ0FBUixHQUFjLENBQXRELEVBQXlEO0FBQ3JELFdBQUt3RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQUcsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWY7QUFDQUEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLENBQWY7QUFDQSxXQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsWUFBekIsR0FBd0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBbkU7QUFDSCxLQUxELE1BS08sQ0FFTjtBQUNKLEdBdHJDSTtBQXdyQ0wwRSxFQUFBQSxVQUFVLEVBQUUsb0JBQVVwQyxTQUFWLEVBQXFCdEcsUUFBckIsRUFBK0I7QUFDdkMsUUFBSTJJLFNBQVMsR0FBRyxLQUFLMUgsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFoQjtBQUNBc0csSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQnFDLFNBQVMsR0FBRyxFQUFaLEdBQWlCckMsU0FBUyxDQUFDLENBQUQsQ0FBMUIsR0FBZ0NBLFNBQVMsQ0FBQyxDQUFELENBQXpDLEdBQStDQSxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBOUU7O0FBQ0EsUUFBSUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLENBQW5CLEVBQXNCO0FBQ2xCQSxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBZjtBQUNIOztBQUNEckgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksV0FBV2lDLElBQUksQ0FBQ0MsS0FBTCxDQUFXa0csU0FBUyxDQUFDLENBQUQsQ0FBcEIsQ0FBdkI7QUFDSCxHQS9yQ0k7QUFpc0NMO0FBQ0FzQyxFQUFBQSxRQUFRLEVBQUUsb0JBQVk7QUFDbEIsU0FBSzlHLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRDtBQUNBOEIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksV0FBWjtBQUNBLFNBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixTQUF6QixHQUFxQyxLQUFLUyxHQUFMLENBQVM4RixNQUFoRTtBQUNILEdBdHNDSTtBQXdzQ0w7QUFDQTZFLEVBQUFBLFNBQVMsRUFBRSxxQkFBWTtBQUNuQixTQUFLL0csaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0E4QixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLFVBQXpCLEdBQXNDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWpFO0FBQ0gsR0E3c0NJO0FBK3NDTDhFLEVBQUFBLGVBQWUsRUFBRSx5QkFBVXhDLFNBQVYsRUFBcUJ0RyxRQUFyQixFQUErQjtBQUM1QyxRQUFJMUQsT0FBTyxHQUFHLENBQUMsS0FBSzJFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsSUFBK0JzRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixDQUFoQyxFQUFpRCxFQUFqRCxFQUFxRCxHQUFyRCxDQUFkO0FBQ0EsUUFBSTdKLEtBQUssR0FBRyxDQUFDLEtBQUt3RSxTQUFMLENBQWVqQixRQUFmLEVBQXlCLEVBQXpCLElBQStCc0csU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsQ0FBaEMsRUFBaUQsRUFBakQsRUFBcUQsSUFBckQsQ0FBWjtBQUNBLFFBQUk5SixHQUFHLEdBQUcsQ0FBQyxLQUFLeUUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnNHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQWhDLEVBQWlELEVBQWpELEVBQXFELElBQXJELENBQVY7QUFDQSxRQUFJNkIsSUFBSSxHQUFHLENBQUMsS0FBS2xILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBRCxFQUErQixFQUEvQixFQUFtQyxJQUFuQyxDQUFYO0FBQ0EsUUFBSXRELElBQUksR0FBRyxDQUFDLEtBQUt1RSxTQUFMLENBQWVqQixRQUFmLEVBQXlCLEVBQXpCLENBQUQsRUFBK0IsRUFBL0IsRUFBbUMsR0FBbkMsQ0FBWDtBQUNBLFFBQUkzRCxLQUFLLEdBQUcsQ0FBQyxLQUFLNEUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixDQUFELEVBQStCLEVBQS9CLEVBQW1DLEdBQW5DLENBQVo7QUFDQSxRQUFJckQsTUFBTSxHQUFHLENBQUMsS0FBS3NFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBRCxFQUErQixFQUEvQixFQUFtQyxHQUFuQyxDQUFiO0FBQ0EsUUFBSTdELElBQUksR0FBRyxDQUFDLEtBQUs4RSxTQUFMLENBQWVqQixRQUFmLEVBQXlCLENBQXpCLENBQUQsRUFBOEIsQ0FBOUIsRUFBaUMsSUFBakMsQ0FBWDtBQUNBLFFBQUk1RCxLQUFLLEdBQUcsQ0FBQyxLQUFLNkUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFELEVBQThCLENBQTlCLEVBQWlDLElBQWpDLENBQVo7QUFDQSxRQUFJK0ksUUFBUSxHQUFHLENBQUN6TSxPQUFELEVBQVVHLEtBQVYsRUFBaUJELEdBQWpCLEVBQXNCMkwsSUFBdEIsRUFBNEJ6TCxJQUE1QixFQUFrQ0wsS0FBbEMsRUFBeUNNLE1BQXpDLEVBQWlEUixJQUFqRCxFQUF1REMsS0FBdkQsQ0FBZjs7QUFDQSxTQUFLLElBQUkwRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaUosUUFBUSxDQUFDOUksTUFBN0IsRUFBcUNILENBQUMsRUFBdEMsRUFBMEM7QUFDdEMsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHZ0osUUFBUSxDQUFDakosQ0FBRCxDQUFSLENBQVksQ0FBWixDQUFwQixFQUFvQ0MsQ0FBQyxFQUFyQyxFQUF5QztBQUNyQyxZQUFJSSxJQUFJLENBQUNFLE1BQUwsS0FBZ0IwSSxRQUFRLENBQUNqSixDQUFELENBQVIsQ0FBWSxDQUFaLENBQXBCLEVBQW9DO0FBQ2hDLGVBQUtnQyxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0Q0TCxRQUFRLENBQUNqSixDQUFELENBQVIsQ0FBWSxDQUFaLENBQWxELEVBQWtFLENBQWxFO0FBQ0g7QUFDSjtBQUNKO0FBQ0osR0FqdUNJO0FBbXVDTGtKLEVBQUFBLFVBQVUsRUFBRSxvQkFBVTFDLFNBQVYsRUFBcUJoRyxTQUFyQixFQUFnQ04sUUFBaEMsRUFBMEM7QUFDbEQsU0FBSzhJLGVBQUwsQ0FBcUJ4QyxTQUFyQixFQUFnQ3RHLFFBQWhDOztBQUNBLFNBQUssSUFBSUYsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxLQUFLbUIsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFwQixFQUFpREYsQ0FBQyxFQUFsRCxFQUFzRDtBQUNsRCxXQUFLOEksUUFBTDtBQUNIOztBQUNELFNBQUssSUFBSTlJLEdBQUMsR0FBRyxDQUFiLEVBQWdCQSxHQUFDLEdBQUcsS0FBS21CLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBcEIsRUFBaURGLEdBQUMsRUFBbEQsRUFBc0Q7QUFDbEQsVUFBSUssSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGFBQUt3SSxTQUFMO0FBQ0g7QUFFSjs7QUFDRCxRQUFJRixTQUFTLEdBQUcsS0FBSzFILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBaEI7O0FBQ0EsV0FBTzJJLFNBQVMsR0FBR3JDLFNBQVMsQ0FBQyxDQUFELENBQTVCLEVBQWlDO0FBQzdCLFdBQUt4RSxpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNBMkksTUFBQUEsU0FBUyxJQUFJLENBQWI7QUFDQTFKLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDJCQUFaO0FBQ0g7QUFDSixHQXB2Q0k7QUFzdkNMK0ssRUFBQUEsVUFBVSxFQUFFLG9CQUFVM0MsU0FBVixFQUFxQjtBQUM3QkEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixLQUFoQjtBQUNBckgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksV0FBV2lDLElBQUksQ0FBQytJLEtBQUwsQ0FBVzVDLFNBQVMsQ0FBQyxDQUFELENBQXBCLENBQXZCLEVBRjZCLENBRzdCO0FBQ0gsR0ExdkNJO0FBNHZDTDZDLEVBQUFBLGdCQUFnQixFQUFFLDBCQUFVN0MsU0FBVixFQUFxQjtBQUNuQyxRQUFJNkIsSUFBSSxHQUFHLEtBQUtsSCxTQUFMLENBQWUsS0FBSzlELE1BQXBCLEVBQTRCLEVBQTVCLENBQVg7QUFDQSxRQUFJVCxJQUFJLEdBQUcsS0FBS3VFLFNBQUwsQ0FBZSxLQUFLOUQsTUFBcEIsRUFBNEIsRUFBNUIsQ0FBWDs7QUFDQSxTQUFLLElBQUkyQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHcUksSUFBcEIsRUFBMEJySSxDQUFDLEVBQTNCLEVBQStCO0FBQzNCLFVBQUl3RyxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWVBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUE5QixJQUFtQ25HLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUF2RCxFQUE0RDtBQUN4RGlHLFFBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxhQUFLcEksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLHNCQUF6QixHQUFrRCxLQUFLUyxHQUFMLENBQVM4RixNQUE3RTtBQUNIO0FBQ0o7O0FBQ0QsU0FBSyxJQUFJbEUsR0FBQyxHQUFHLENBQWIsRUFBZ0JBLEdBQUMsR0FBR3BELElBQXBCLEVBQTBCb0QsR0FBQyxFQUEzQixFQUErQjtBQUMzQixVQUFJd0csU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlQSxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBOUIsSUFBbUNuRyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBdkQsRUFBNEQ7QUFDeERpRyxRQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0EsYUFBS3BJLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixzQkFBekIsR0FBa0QsS0FBS1MsR0FBTCxDQUFTOEYsTUFBN0U7QUFDSDtBQUNKOztBQUNELFFBQUlzQyxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQXBCLEVBQXVCO0FBQ25CLFdBQUtwSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsY0FBekIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7O0FBQ0EsVUFBSXNDLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFuQixFQUFzQjtBQUNsQkEsUUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlbkcsSUFBSSxDQUFDcUcsSUFBTCxDQUFVRixTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBZixHQUFtQixDQUE3QixDQUFmLENBRGtCLENBRWxCO0FBQ0gsT0FIRCxNQUdPO0FBQ0hBLFFBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZW5HLElBQUksQ0FBQ0MsS0FBTCxDQUFXa0csU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLENBQWYsR0FBbUIsQ0FBOUIsQ0FBZjtBQUNIOztBQUNELFVBQUlBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBcEIsRUFBdUI7QUFDbkJBLFFBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFmO0FBQ0g7QUFDSjtBQUNKLEdBdnhDSTtBQXl4Q0w4QyxFQUFBQSxhQUFhLEVBQUUsdUJBQVU5QyxTQUFWLEVBQXFCO0FBQ2hDQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQUNBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFoQixJQUFxQixDQUFyQztBQUNBQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEtBQWhCO0FBQ0gsR0E1eENJO0FBOHhDTCtDLEVBQUFBLFNBQVMsRUFBRSxtQkFBVS9DLFNBQVYsRUFBcUJoRyxTQUFyQixFQUFnQ04sUUFBaEMsRUFBMEM7QUFDakQsU0FBS3lJLFVBQUwsQ0FBZ0JuQyxTQUFoQjtBQUNBLFNBQUtnRCxVQUFMLENBQWdCaEQsU0FBaEIsRUFBMkJ0RyxRQUEzQjtBQUNILEdBanlDSTtBQW15Q0x1SixFQUFBQSxRQUFRLEVBQUUsa0JBQVVqRCxTQUFWLEVBQXFCdEcsUUFBckIsRUFBK0I7QUFDckMsUUFBSTJJLFNBQVMsR0FBRyxLQUFLMUgsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFoQjtBQUNBLFFBQUl3SixJQUFJLEdBQUdiLFNBQVMsR0FBRyxFQUFaLEdBQWlCckMsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLENBQWhDLEdBQW9DQSxTQUFTLENBQUMsQ0FBRCxDQUF4RDtBQUNBLFFBQUltRCxNQUFNLEdBQUduRCxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsS0FBS3JGLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBNUI7O0FBQ0EsUUFBSXdKLElBQUksSUFBSWxELFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUEzQixFQUE4QjtBQUMxQixXQUFLVSxVQUFMLENBQWdCVixTQUFoQixFQUEyQnRHLFFBQTNCLEVBQXFDeUosTUFBckM7QUFDQUQsTUFBQUEsSUFBSSxHQUFHYixTQUFTLEdBQUcsRUFBWixHQUFpQnJDLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFoQyxHQUFvQ0EsU0FBUyxDQUFDLENBQUQsQ0FBcEQ7O0FBQ0EsVUFBSWtELElBQUksSUFBSWxELFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUEzQixFQUE4QjtBQUMxQixhQUFLNEIsVUFBTCxDQUFnQjVCLFNBQWhCLEVBQTJCdEcsUUFBM0IsRUFBcUNHLElBQUksQ0FBQ0MsS0FBTCxDQUFXcUosTUFBTSxHQUFHLENBQXBCLENBQXJDO0FBQ0g7QUFDSixLQU5ELE1BTU8sSUFBSUQsSUFBSSxJQUFJbEQsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLEVBQTNCLEVBQStCO0FBQ2xDLFdBQUtVLFVBQUwsQ0FBZ0JWLFNBQWhCLEVBQTJCdEcsUUFBM0IsRUFBcUNHLElBQUksQ0FBQ0MsS0FBTCxDQUFXcUosTUFBTSxHQUFHLENBQXBCLENBQXJDO0FBQ0EsV0FBS2pDLGNBQUwsQ0FBb0JsQixTQUFwQixFQUErQnRHLFFBQS9CLEVBQXlDRyxJQUFJLENBQUNDLEtBQUwsQ0FBV3FKLE1BQU0sR0FBRyxDQUFwQixDQUF6QztBQUNBLFdBQUtsQixTQUFMLENBQWVqQyxTQUFmLEVBQTBCdEcsUUFBMUIsRUFBb0NHLElBQUksQ0FBQ0MsS0FBTCxDQUFXcUosTUFBTSxHQUFHLENBQXBCLENBQXBDO0FBQ0gsS0FKTSxNQUlBO0FBQ0gsV0FBS2pDLGNBQUwsQ0FBb0JsQixTQUFwQixFQUErQnRHLFFBQS9CLEVBQXlDRyxJQUFJLENBQUNDLEtBQUwsQ0FBV3FKLE1BQU0sR0FBRyxDQUFwQixDQUF6QztBQUNBLFdBQUtsQixTQUFMLENBQWVqQyxTQUFmLEVBQTBCdEcsUUFBMUIsRUFBb0NHLElBQUksQ0FBQ0MsS0FBTCxDQUFXcUosTUFBTSxHQUFHLENBQXBCLENBQXBDO0FBQ0g7O0FBQ0QsUUFBSW5ELFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxFQUFuQixFQUF1QjtBQUNuQixXQUFLNEIsVUFBTCxDQUFnQjVCLFNBQWhCLEVBQTJCdEcsUUFBM0IsRUFBcUNHLElBQUksQ0FBQ0MsS0FBTCxDQUFXcUosTUFBTSxHQUFHLEVBQXBCLENBQXJDO0FBQ0g7QUFDSixHQXh6Q0k7QUEwekNMO0FBQ0FDLEVBQUFBLFlBM3pDSyx3QkEyekNRQyxTQTN6Q1IsRUEyekNtQjtBQUNwQixRQUFJQyxLQUFLLEdBQUd6SixJQUFJLENBQUNDLEtBQUwsQ0FBVyxLQUFLakYsU0FBTCxDQUFldUYsQ0FBZixHQUFtQixFQUE5QixDQUFaO0FBQ0EsUUFBSW1KLEtBQUssR0FBRzFKLElBQUksQ0FBQ0MsS0FBTCxDQUFXLEtBQUtqRixTQUFMLENBQWVzRixDQUFmLEdBQW1CLEVBQTlCLENBQVo7O0FBRUEsUUFBSWtKLFNBQVMsSUFBSSxDQUFqQixFQUFvQjtBQUFFO0FBQ2xCRSxNQUFBQSxLQUFLO0FBQ1IsS0FGRCxNQUVPLElBQUlGLFNBQVMsSUFBSSxDQUFqQixFQUFvQjtBQUFFO0FBQ3pCRSxNQUFBQSxLQUFLO0FBQ1IsS0FGTSxNQUVBLElBQUlGLFNBQVMsSUFBSSxDQUFqQixFQUFvQjtBQUFFO0FBQ3pCQyxNQUFBQSxLQUFLO0FBQ1IsS0FGTSxNQUVBO0FBQUU7QUFDTEEsTUFBQUEsS0FBSztBQUNSOztBQUVELFFBQUksS0FBS3pNLE1BQUwsQ0FBWTBNLEtBQVosRUFBbUJELEtBQW5CLEtBQTZCLENBQWpDLEVBQW9DO0FBQUU7QUFDbEMsYUFBTyxLQUFQO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsYUFBTyxJQUFQO0FBQ0g7QUFDSixHQTkwQ0k7QUFnMUNMRSxFQUFBQSxTQUFTLEVBQUUscUJBQVc7QUFDbEIsUUFBSXhLLEtBQUssR0FBRyxFQUFaO0FBQ0EsUUFBSXlLLE1BQU0sR0FBRzVKLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBYjs7QUFDQSxRQUFJLEtBQUtxSixZQUFMLENBQWtCSyxNQUFsQixDQUFKLEVBQStCO0FBQzNCLFVBQUlBLE1BQU0sSUFBSSxDQUFWLElBQWUsS0FBSzVPLFNBQUwsQ0FBZXNGLENBQWYsSUFBb0IsTUFBTSxFQUFOLEdBQVcsRUFBbEQsRUFBc0Q7QUFDbEQ7QUFDQW5CLFFBQUFBLEtBQUssR0FBRyxVQUFSO0FBQ0EsYUFBS0YsRUFBTCxDQUFRc0IsQ0FBUixHQUFZLENBQVo7QUFDQSxhQUFLdEIsRUFBTCxDQUFRcUIsQ0FBUixHQUFZLEVBQVo7QUFDSCxPQUxELE1BS08sSUFBSXNKLE1BQU0sSUFBSSxDQUFWLElBQWUsS0FBSzVPLFNBQUwsQ0FBZXNGLENBQWYsSUFBb0IsS0FBSyxFQUE1QyxFQUFnRDtBQUNuRDtBQUNBbkIsUUFBQUEsS0FBSyxHQUFHLFlBQVI7QUFDQSxhQUFLRixFQUFMLENBQVFzQixDQUFSLEdBQVksQ0FBWjtBQUNBLGFBQUt0QixFQUFMLENBQVFxQixDQUFSLEdBQVksQ0FBQyxFQUFiO0FBQ0gsT0FMTSxNQUtBLElBQUlzSixNQUFNLElBQUksQ0FBVixJQUFlLEtBQUs1TyxTQUFMLENBQWV1RixDQUFmLElBQW9CLEtBQUssRUFBNUMsRUFBZ0Q7QUFDbkQ7QUFDQXBCLFFBQUFBLEtBQUssR0FBRyxZQUFSO0FBQ0EsYUFBS0YsRUFBTCxDQUFRc0IsQ0FBUixHQUFZLENBQUMsRUFBYjtBQUNBLGFBQUt0QixFQUFMLENBQVFxQixDQUFSLEdBQVksQ0FBWjtBQUNILE9BTE0sTUFLQSxJQUFJc0osTUFBTSxJQUFJLENBQVYsSUFBZSxLQUFLNU8sU0FBTCxDQUFldUYsQ0FBZixJQUFvQixNQUFNLEVBQU4sR0FBVyxFQUFsRCxFQUFzRDtBQUN6RDtBQUNBcEIsUUFBQUEsS0FBSyxHQUFHLGFBQVI7QUFDQSxhQUFLRixFQUFMLENBQVFzQixDQUFSLEdBQVksRUFBWjtBQUNBLGFBQUt0QixFQUFMLENBQVFxQixDQUFSLEdBQVksQ0FBWjtBQUNIO0FBQ0osS0F0QkQsTUFzQk87QUFDSCxXQUFLckIsRUFBTCxDQUFRc0IsQ0FBUixHQUFZLENBQVo7QUFDQSxXQUFLdEIsRUFBTCxDQUFRcUIsQ0FBUixHQUFZLENBQVo7QUFDSDs7QUFFRCxRQUFJLEtBQUtyQixFQUFMLENBQVFzQixDQUFaLEVBQWU7QUFDWCxXQUFLdkYsU0FBTCxDQUFldUYsQ0FBZixJQUFvQixLQUFLdEIsRUFBTCxDQUFRc0IsQ0FBNUI7QUFDSCxLQUZELE1BRU8sSUFBSSxLQUFLdEIsRUFBTCxDQUFRcUIsQ0FBWixFQUFlO0FBQ2xCLFdBQUt0RixTQUFMLENBQWVzRixDQUFmLElBQW9CLEtBQUtyQixFQUFMLENBQVFxQixDQUE1QjtBQUNIOztBQUVELFFBQUluQixLQUFKLEVBQVc7QUFDUCxXQUFLSSxRQUFMLENBQWNKLEtBQWQ7QUFDSDtBQUNKLEdBdjNDSTtBQXkzQ0wwSyxFQUFBQSxpQkFBaUIsRUFBRSw2QkFBVztBQUUxQixTQUFLeEwsV0FBTCxDQUFpQnlMLFFBQWpCLEdBQTRCLEtBQUszTSxRQUFMLENBQWMsQ0FBZCxJQUFtQixLQUFLQSxRQUFMLENBQWMsQ0FBZCxDQUEvQztBQUNBOzs7Ozs7O0FBT04sR0FuNENPO0FBcTRDTDBCLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QkMsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksVUFBVXJELEdBQUcsQ0FBQ3VELFFBQTFCLEVBRHNCLENBRXRCOztBQUNBLFFBQUk4TCxLQUFLLEdBQUd6RyxFQUFFLENBQUMwRyxjQUFILENBQWtCLGNBQWxCLENBQVo7QUFDQWxMLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGFBQWFyRCxHQUFHLENBQUN1UCxPQUE3Qjs7QUFDQSxRQUFJRixLQUFLLENBQUNqSyxNQUFOLElBQWdCLENBQWhCLElBQXFCcEYsR0FBRyxDQUFDdVAsT0FBekIsSUFBb0N2UCxHQUFHLENBQUN1RCxRQUE1QyxFQUFzRDtBQUNsRGEsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksVUFBWjtBQUNBckQsTUFBQUEsR0FBRyxDQUFDdUQsUUFBSixHQUFlLEtBQWY7QUFDQXZELE1BQUFBLEdBQUcsQ0FBQ3VQLE9BQUosR0FBYyxLQUFkO0FBQ0gsS0FKRCxNQUlPO0FBQ0g7QUFDQTtBQUNBLFVBQUk7QUFDQSxZQUFJRixLQUFLLEdBQUd6RyxFQUFFLENBQUMwRyxjQUFILENBQWtCLGNBQWxCLENBQVo7O0FBQ0EsWUFBSUQsS0FBSixFQUFXO0FBQ1Q7QUFDQXhQLFVBQUFBLFlBQVksR0FBR3dQLEtBQWY7QUFDRDtBQUNKLE9BTkQsQ0FNRSxPQUFPRyxDQUFQLEVBQVU7QUFDUjtBQUNBcEwsUUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksMkJBQVo7QUFDSDs7QUFDRCxVQUFJO0FBQ0EsWUFBSWdNLEtBQUssR0FBR3pHLEVBQUUsQ0FBQzBHLGNBQUgsQ0FBa0IsZ0JBQWxCLENBQVo7O0FBQ0EsWUFBSUQsS0FBSixFQUFXO0FBQ1Q7QUFDQXZQLFVBQUFBLGNBQWMsR0FBR3VQLEtBQWpCO0FBQ0Q7QUFDSixPQU5ELENBTUUsT0FBT0csQ0FBUCxFQUFVO0FBQ1I7QUFDQXBMLFFBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDZCQUFaO0FBQ0g7O0FBQ0QsVUFBSTtBQUNBLFlBQUlnTSxLQUFLLEdBQUd6RyxFQUFFLENBQUMwRyxjQUFILENBQWtCLFlBQWxCLENBQVo7O0FBQ0EsWUFBSUQsS0FBSixFQUFXO0FBQ1Q7QUFDQXRQLFVBQUFBLFVBQVUsR0FBR3NQLEtBQWI7QUFDRDtBQUNKLE9BTkQsQ0FNRSxPQUFPRyxDQUFQLEVBQVU7QUFDUjtBQUNBcEwsUUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksd0JBQVo7QUFDSDs7QUFFRGUsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksY0FBWjtBQUNBZSxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWXhELFlBQVo7QUFDQXVFLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGdCQUFaO0FBQ0FlLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZdkQsY0FBWjtBQUNBc0UsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksWUFBWjtBQUNBZSxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWXRELFVBQVosRUF2Q0csQ0F5Q0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQUt1QyxNQUFMLEdBQWN6QyxZQUFkLENBL0NHLENBaURIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQUs0QyxRQUFMLEdBQWdCM0MsY0FBaEI7QUFDQSxXQUFLOEMsSUFBTCxHQUFZN0MsVUFBWjtBQUNIO0FBQ0osR0E1OENJO0FBODhDTDBQLEVBQUFBLGNBQWMsRUFBRSwwQkFBWTtBQUN4QixRQUFJLEtBQUtoTixRQUFMLENBQWMsQ0FBZCxLQUFvQixDQUFwQixJQUF5QixLQUFLZSxhQUFMLElBQXNCLEtBQW5ELEVBQTBEO0FBQ3REWSxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxNQUFaO0FBQ0EsV0FBS0UsUUFBTCxDQUFjZSxNQUFkLEdBQXVCLElBQXZCO0FBQ0EsV0FBS2QsYUFBTCxHQUFxQixJQUFyQjtBQUNBLFdBQUt5RSxZQUFMO0FBQ0EsV0FBS3hFLFlBQUwsR0FBb0IsS0FBS2IsSUFBekI7QUFDQSxXQUFLVSxjQUFMLENBQW9CNkYsTUFBcEIsR0FBNkIsb0JBQW9CLFdBQXBCLEdBQWtDLEtBQUsxRixZQUF2QyxHQUFzRCxHQUFuRjtBQUNOO0FBQ0QsR0F2OUNJO0FBeTlDTHdFLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QmpJLElBQUFBLEdBQUcsQ0FBQ3VELFFBQUosR0FBZSxLQUFLQyxhQUFwQjtBQUNBM0QsSUFBQUEsWUFBWSxHQUFHLEtBQUt5QyxNQUFwQixDQUZzQixDQUd0Qjs7QUFDQSxRQUFJO0FBQ0FzRyxNQUFBQSxFQUFFLENBQUM4RyxjQUFILENBQWtCLGNBQWxCLEVBQWtDN1AsWUFBbEM7QUFDSCxLQUZELENBRUUsT0FBTzJQLENBQVAsRUFBVTtBQUNScEwsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksMkJBQVo7QUFDSDs7QUFDRGUsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksNEJBQVo7QUFDQWUsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVl4RCxZQUFaO0FBRUFDLElBQUFBLGNBQWMsR0FBRyxLQUFLMkMsUUFBdEIsQ0Fac0IsQ0FhdEI7O0FBQ0EsUUFBSTtBQUNBbUcsTUFBQUEsRUFBRSxDQUFDOEcsY0FBSCxDQUFrQixnQkFBbEIsRUFBb0M1UCxjQUFwQztBQUNILEtBRkQsQ0FFRSxPQUFPMFAsQ0FBUCxFQUFVO0FBQ1JwTCxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSw2QkFBWjtBQUNIOztBQUNEZSxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSw2QkFBWjtBQUNBZSxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWXZELGNBQVo7QUFFQUMsSUFBQUEsVUFBVSxHQUFHLEtBQUs2QyxJQUFsQjs7QUFDQSxRQUFJO0FBQ0FnRyxNQUFBQSxFQUFFLENBQUM4RyxjQUFILENBQWtCLFlBQWxCLEVBQWdDM1AsVUFBaEM7QUFDSCxLQUZELENBRUUsT0FBT3lQLENBQVAsRUFBVTtBQUNScEwsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksd0JBQVo7QUFDSDtBQUdKLEdBdi9DSTtBQXkvQ0xzTSxFQUFBQSxNQXovQ0ssa0JBeS9DRUMsRUF6L0NGLEVBeS9DTTtBQUNQLFFBQUksS0FBS3ZNLEdBQUwsQ0FBUzhGLE1BQVQsQ0FBZ0IvRCxNQUFoQixJQUEwQixJQUE5QixFQUFvQztBQUNoQyxXQUFLL0IsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixFQUFsQjtBQUNIOztBQUNELFFBQUksS0FBSzNGLGFBQVQsRUFBd0I7QUFDcEI7QUFDSDs7QUFDRCxTQUFLWCxLQUFMO0FBQ0EsU0FBS2EsUUFBTDs7QUFDQSxRQUFJLEtBQUtiLEtBQUwsR0FBYSxFQUFiLElBQW1CLENBQXZCLEVBQTBCO0FBQ3RCLFdBQUtrSixXQUFMLENBQWlCLEtBQUt0SixRQUF0QjtBQUNIOztBQUNELFFBQUksS0FBS0ksS0FBTCxJQUFjLEdBQWxCLEVBQXVCO0FBQ25CLFdBQUs2TCxRQUFMLENBQWMsS0FBS2pNLFFBQW5CLEVBQTZCLEtBQUtILE1BQWxDO0FBQ0gsS0FGRCxNQUVPLElBQUksS0FBS08sS0FBTCxJQUFjLEdBQWxCLEVBQXVCO0FBQzFCLFVBQUksS0FBS3dELGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsYUFBS3NMLFVBQUwsQ0FBZ0IsS0FBS25MLFFBQXJCO0FBQ0g7QUFDSixLQUpNLE1BSUEsSUFBSSxLQUFLSSxLQUFMLElBQWMsR0FBbEIsRUFBdUI7QUFDMUIsV0FBS3lMLGdCQUFMLENBQXNCLEtBQUs3TCxRQUEzQjtBQUNBLFdBQUtvTCxVQUFMLENBQWdCLEtBQUtwTCxRQUFyQixFQUErQixLQUFLSCxNQUFwQztBQUNBLFdBQUs4TCxVQUFMLENBQWdCLEtBQUszTCxRQUFyQjtBQUNILEtBSk0sTUFJQSxJQUFJLEtBQUtJLEtBQUwsSUFBYyxHQUFsQixFQUF1QjtBQUMxQixXQUFLc0wsVUFBTCxDQUFnQixLQUFLMUwsUUFBckIsRUFBK0IsS0FBS0YsT0FBcEMsRUFBNkMsS0FBS0QsTUFBbEQ7QUFDQSxXQUFLaU0sYUFBTCxDQUFtQixLQUFLOUwsUUFBeEI7QUFDQSxXQUFLSSxLQUFMLEdBQWEsQ0FBYjtBQUNBLFdBQUtELElBQUw7QUFDSDs7QUFDRCxTQUFLcEMsVUFBTDs7QUFDQSxRQUFJLEtBQUtBLFVBQUwsR0FBa0IsRUFBdEIsRUFBMEI7QUFDdEIsV0FBS3lPLFNBQUw7QUFDQSxXQUFLek8sVUFBTCxHQUFrQixDQUFsQjtBQUNIOztBQUNELFFBQUksS0FBS2tELFFBQUwsR0FBZ0IsSUFBaEIsSUFBd0IsQ0FBNUIsRUFBK0I7QUFDM0IsV0FBS0wsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixFQUFsQjtBQUNBLFdBQUt6RixRQUFMLEdBQWdCLENBQWhCO0FBQ0g7O0FBRUQsU0FBS3RCLFNBQUwsQ0FBZStHLE1BQWYsR0FBd0IsU0FBUyxLQUFLMUcsUUFBTCxDQUFjLEVBQWQsQ0FBakM7QUFDQSxTQUFLVixjQUFMLENBQW9Cb0gsTUFBcEIsR0FBNkIsU0FBUyxLQUFLMUcsUUFBTCxDQUFjLENBQWQsQ0FBdEM7QUFDQSxTQUFLUixRQUFMLENBQWNrSCxNQUFkLEdBQXVCLFNBQVM3RCxJQUFJLENBQUMrSSxLQUFMLENBQVcsS0FBSzVMLFFBQUwsQ0FBYyxDQUFkLENBQVgsQ0FBaEMsQ0F4Q08sQ0F5Q1A7O0FBQ0EsU0FBS04sUUFBTCxDQUFjZ0gsTUFBZCxHQUF1QixTQUFTN0QsSUFBSSxDQUFDK0ksS0FBTCxDQUFXLEtBQUs1TCxRQUFMLENBQWMsQ0FBZCxJQUFtQixJQUE5QixJQUFzQyxJQUF0RSxDQTFDTyxDQTJDUDs7QUFDQSxTQUFLUCxZQUFMLENBQWtCaUgsTUFBbEIsR0FBMkIsU0FBUyxLQUFLMUcsUUFBTCxDQUFjLENBQWQsQ0FBcEM7QUFDQSxTQUFLSixTQUFMLENBQWU4RyxNQUFmLEdBQXdCLEtBQUsxRyxRQUFMLENBQWMsQ0FBZCxJQUFtQixHQUFuQixHQUF5QixLQUFLQSxRQUFMLENBQWMsQ0FBZCxDQUFqRDtBQUNBLFNBQUswTSxpQkFBTDtBQUNBLFNBQUtNLGNBQUw7QUFDSDtBQXppREksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsi77u/dmFyIGdsb2JhbE1hcEtleSA9IFtdO1xyXG52YXIgZ2xvYmFsR2FtZURhdGEgPSBbXTtcclxudmFyIGdsb2JhbFllYXIgPSAwO1xyXG5cclxudmFyIGNvbSA9IHJlcXVpcmUoJ2RhdGEnKTsgXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgaHVtYW5Ob2RlOiBjYy5Ob2RlLFxyXG4gICAgICAgIGh1bWFuVGltZXI6IDAsXHJcbiAgICAgICAgYXVkaW9CZ206IGNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICBhdWRpb0NsaWNrOiBjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgbWFwTm9kZTogY2MuTm9kZSxcclxuICAgICAgICB3YXRlcjogY2MuUHJlZmFiLCAvL3dhdGVyIDBcclxuICAgICAgICBzYW5kOiBjYy5QcmVmYWIsIC8vc2FuZCAxXHJcbiAgICAgICAgZ3Jhc3M6IGNjLlByZWZhYiwgLy9ncmFzcyAyXHJcbiAgICAgICAgdG93bjogY2MuUHJlZmFiLCAvL3Rvd24gM1xyXG4gICAgICAgIGNyb3A6IGNjLlByZWZhYiwgLy9jcm9wIDRcclxuICAgICAgICB3aGVhdDogY2MuUHJlZmFiLCAvL3doZWF0IDVcclxuICAgICAgICB2b2NhbjogY2MuUHJlZmFiLCAvL3ZvY2FuIDZcclxuICAgICAgICBzdG9uZTogY2MuUHJlZmFiLCAvL3N0b25lIDdcclxuICAgICAgICB0cmVlOiBjYy5QcmVmYWIsIC8vIHRyZWUgOFxyXG4gICAgICAgIGZydWl0OiBjYy5QcmVmYWIsIC8vZnJ1aXQgOVxyXG4gICAgICAgIGJlcnJ5OiBjYy5QcmVmYWIsIC8vYmVycnkgMTBcclxuICAgICAgICBjaGlja2VuOiBjYy5QcmVmYWIsIC8vY2hpY2tlbiAxMVxyXG4gICAgICAgIGRvZzogY2MuUHJlZmFiLCAvL2RvZyAxMlxyXG4gICAgICAgIGNvdzogY2MuUHJlZmFiLCAvL2NvdyAxM1xyXG4gICAgICAgIHNoZWVwOiBjYy5QcmVmYWIsIC8vc2hlZXAgMTRcclxuICAgICAgICBsaW9uOiBjYy5QcmVmYWIsIC8vIGxpb24gMTVcclxuICAgICAgICBwb2lzb246IGNjLlByZWZhYiwgLy9iZXJyeSAxNlxyXG4gICAgICAgIHBvcHVsYXRpb25UZXh0OiBjYy5MYWJlbCxcclxuICAgICAgICBmb29kVGV4dDogY2MuTGFiZWwsXHJcbiAgICAgICAgcmVzb3VyY2VUZXh0OiBjYy5MYWJlbCxcclxuICAgICAgICB0ZWNoVGV4dDogY2MuTGFiZWwsXHJcbiAgICAgICAgTGV2ZWxUZXh0OiBjYy5MYWJlbCxcclxuICAgICAgICBwb3dlclRleHQ6IGNjLkxhYmVsLFxyXG4gICAgICAgIG1hcEtleTogW10sXHJcbiAgICAgICAgbm9kZUtleTogW10sXHJcbiAgICAgICAgcHJlZmFiS2V5OiBbXSxcclxuICAgICAgICBnYW1lRGF0YTogW10sXHJcbiAgICAgICAgc2l6ZVg6IDIwLFxyXG4gICAgICAgIHNpemVZOiAyMCxcclxuICAgICAgICB0aW1lOiAwLCAvLyB5ZWFyIG51bVxyXG4gICAgICAgIGZyYW1lOiAwLFxyXG4gICAgICAgIGJ1dHRvbjE6IGNjLkJ1dHRvbixcclxuICAgICAgICBidXR0b24yOiBjYy5CdXR0b24sXHJcbiAgICAgICAgYnV0dG9uMzogY2MuQnV0dG9uLFxyXG4gICAgICAgIGJ1dHRvbjQ6IGNjLkJ1dHRvbixcclxuICAgICAgICBidXR0b241OiBjYy5CdXR0b24sXHJcbiAgICAgICAgYnV0dG9uNjogY2MuQnV0dG9uLFxyXG4gICAgICAgIGxvZzogY2MuTGFiZWwsXHJcbiAgICAgICAgZ2FtZU92ZXJTdHJpbmc6IGNjLkxhYmVsLFxyXG4gICAgICAgIGdhbWVPdmVyOmNjLk5vZGUsXHJcbiAgICAgICAgZ2FtZU92ZXJPck5vdDogZmFsc2UsXHJcbiAgICAgICAgZ2FtZU92ZXJUaW1lOiAwLFxyXG4gICAgICAgIGxvZ2ZyYW1lOiAwLFxyXG4gICAgICAgIHByb2dyZXNzQmFyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByb2dyZXNzQmFyLFxyXG5cdFx0fSxcclxuICAgIH0sXHJcblxyXG4gICAgb25Mb2FkKCkge1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5hdWRpb0JnbSwgdHJ1ZSwgMSk7XHJcbiAgICAgICAgdGhpcy5wcmVmYWJLZXkgPSBbdGhpcy53YXRlciwgdGhpcy5zYW5kLCB0aGlzLmdyYXNzLCB0aGlzLnRvd24sIHRoaXMuY3JvcCwgdGhpcy53aGVhdCwgdGhpcy52b2NhbiwgdGhpcy5zdG9uZSwgdGhpcy50cmVlLCB0aGlzLmZydWl0LCB0aGlzLmJlcnJ5LCB0aGlzLmNoaWNrZW4sIHRoaXMuZG9nLCB0aGlzLmNvdywgdGhpcy5zaGVlcCwgdGhpcy5saW9uLCB0aGlzLnBvaXNvbl07XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAwICAgICAgICAgIDEgICAgICAgICAgMiAgICAgICAgICAgMyAgICAgICAgICA0ICAgICAgICAgIDUgICAgICAgICAgIDYgICAgICAgICAgIDcgICAgICAgICAgIDggICAgICAgICAgOSAgICAgICAgICAgMTAgICAgICAgICAgMTEgICAgICAgICAgICAxMiAgICAgICAgMTMgICAgICAgICAxNCAgICAgICAgICAxNSAgICAgICAgMTZcclxuICAgICAgICB0aGlzLmdhbWVEYXRhID0gWzEwLCAwLCAzMDAsIDAsIDEsIDEsIFswLCAwLCAwLCAwLCAwXSwgMTAwLCAxMDAsIDAsIDEwMCwgMF07XHJcbiAgICAgICAgLy9nYW1lRGF0YSBbcG9wdWxhdGlvbiwgaG91c2UsIGZvb2QsIHJlc291cmNlLCB0ZWNoLCBtdWx0aXBsaWVyLCBbY2hpY2tlbiwgZG9nLCBjb3csIHNoZWVwLCBsaW9uXSwgcG93ZXIsIHBvd2VyTWF4LCBjdXJyZW50RXhwLCBFeHBOZWVkLCBHb2RMZXZlbF1cclxuICAgICAgICAvLyAgICAgICAgICAgICAwICAgICAgICAgIDEgICAgICAyICAgICAgIDMgICAgICAgNCAgICAgICA1ICAgICAgICAgICAgICAgICAgICAgNiAgICAgICAgICAgICAgICAgICAgIDcgICAgICAgOCAgICAgICAgICAgOSAgICAgICAgMTAgICAgICAgIDExXHJcbiAgICAgICAgdGhpcy5pbml0QXJyYXkodGhpcy5tYXBLZXksIHRoaXMuc2l6ZVgsIHRoaXMuc2l6ZVkpO1xyXG4gICAgICAgIHRoaXMuaW5pdEFycmF5KHRoaXMubm9kZUtleSwgdGhpcy5zaXplWCwgdGhpcy5zaXplWSk7XHJcbiAgICAgICAgdGhpcy53b3JsZEdlbih0aGlzLm1hcEtleSk7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZygncmVzdGFydE9yTm90Jyk7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyhjb20ucmVzdGFydCk7XHJcbiAgICAgICAgdGhpcy5yZWFkVXNlckRhdGEoKTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2FtZU92ZXIgPScgKyB0aGlzLmdhbWVPdmVyT3JOb3QpO1xyXG4gICAgICAgIC8vY29uc29sZS5sb2codGhpcy5tYXBLZXkpO1xyXG4gICAgICAgIC8vY29uc29sZS5sb2codGhpcy5nYW1lRGF0YSk7XHJcbiAgICAgICAgdGhpcy5sb2FkTWFwKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXkpO1xyXG4gICAgICAgIHRoaXMuZ2FtZU92ZXIuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zcCA9IGNjLnYyKDAsIDApOyBcclxuICAgICAgICB0aGlzLnN0YXRlID0gJyc7XHJcbiAgICAgICAgdGhpcy5odW1hbkFuaSA9IHRoaXMuaHVtYW5Ob2RlLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyBzZXQgc3RhdGUgZm9yIGh1bWFuIG1vdmluZ1xyXG4gICAgc2V0U3RhdGUoc3RhdGUpIHtcclxuICAgICAgICBpZiAodGhpcy5zdGF0ZSAhPSBzdGF0ZSkge1xyXG4gICAgICAgICAgICB0aGlzLnN0YXRlID0gc3RhdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuaHVtYW5BbmkucGxheSh0aGlzLnN0YXRlKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy9pbml0aWFsIGFuIGVtcHR5IGFycmF5XHJcbiAgICBpbml0QXJyYXk6IGZ1bmN0aW9uIChhcnJheSwgcm93LCBjb2x1bWUpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJvdzsgaSsrKSB7XHJcbiAgICAgICAgICAgIGFycmF5W2ldID0gW107XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgY29sdW1lOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGFycmF5W2ldW2pdID0gbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9nZW5lcmF0ZSB3b3JsZCBtYXBcclxuICAgIHdvcmxkR2VuOiBmdW5jdGlvbiAoYXJyYXlNYXApIHtcclxuICAgICAgICAvL3NldHRpbmcgYSBzZWEgYmFja2dyb3VuZFxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXlNYXAubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBhcnJheU1hcFtpXS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW0gPSAwO1xyXG4gICAgICAgICAgICAgICAgYXJyYXlNYXBbaV1bal0gPSBpdGVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vYWRkIHNhbmQgYXMgdGhlIGlzbGFuZFxyXG4gICAgICAgIGZvciAobGV0IGkgPSBhcnJheU1hcC5sZW5ndGggLyAyIC0gKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDUpKSAtIDE7IGkgPCBhcnJheU1hcC5sZW5ndGggLyAyICsgKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDUpKSArIDE7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gYXJyYXlNYXBbaV0ubGVuZ3RoIC8gMiAtIChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1KSkgLSAxOyBqIDwgYXJyYXlNYXBbaV0ubGVuZ3RoIC8gMiArIChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1KSkgKyAxOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGFycmF5TWFwW2ldW2pdID0gMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvL2FkZCBhIHNpbmdsZSBncmFzc2xhbmRcclxuICAgICAgICBmb3IgKGxldCBpID0gYXJyYXlNYXAubGVuZ3RoIC8gMiAtIChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyKSkgLSAxOyBpIDwgYXJyYXlNYXAubGVuZ3RoIC8gMiArIChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyKSkgKyAxOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IGFycmF5TWFwW2ldLmxlbmd0aCAvIDIgLSAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMikpIC0gMTsgaiA8IGFycmF5TWFwW2ldLmxlbmd0aCAvIDIgKyAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMikpICsgMTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBhcnJheU1hcFtpXVtqXSA9IDI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXJyYXlNYXBbYXJyYXlNYXAubGVuZ3RoIC8gMl1bYXJyYXlNYXBbMF0ubGVuZ3RoIC8gMl0gPSAyXHJcbiAgICB9LFxyXG5cclxuICAgIC8vbG9hZCBtYXAgZnJvbSBrZXlcclxuICAgIGxvYWRNYXA6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcnJheU1hcC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGFycmF5TWFwW2ldLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBhcnJheU5vZGVbaV1bal0gPSB0aGlzLmluaXROb2RlKGFycmF5TWFwW2ldW2pdLCBpLCBqLCAzMik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vYWRkIG5vZGUgYXMgY2hpbGRcclxuICAgIGluaXROb2RlOiBmdW5jdGlvbiAobnVtLCB5LCB4LCBzaXplKSB7XHJcbiAgICAgICAgbGV0IGl0ZW0gPSBudWxsO1xyXG4gICAgICAgIGl0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnByZWZhYktleVtudW1dKTtcclxuICAgICAgICBsZXQgcG9zaXRpb24gPSBjYy52Mih4ICogc2l6ZSArIHNpemUgLyAyLCB5ICogc2l6ZSArIHNpemUgLyAyKTtcclxuICAgICAgICBpdGVtLnNldFBvc2l0aW9uKHBvc2l0aW9uKTtcclxuICAgICAgICBpdGVtLm5hbWUgPSB5ICsgJzAwJyArIHg7XHJcbiAgICAgICAgdGhpcy5tYXBOb2RlLmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL251bWJlciBvZiBpdGVtXHJcbiAgICBudW1PZkl0ZW06IGZ1bmN0aW9uIChhcnJheSwgbnVtKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QoYXJyYXksIG51bSkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZmluZE5vZGUoYXJyYXksIG51bSkubGVuZ3RoO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH0sXHJcblxyXG4gICAgLy9maW5kIGlmIHRoZSBub2RlIGV4aXN0XHJcbiAgICBjaGVja05vZGVFeGlzdDogZnVuY3Rpb24gKGFycmF5LCBudW1iZXIpIHtcclxuICAgICAgICBsZXQgaWZGaW5kID0gZmFsc2U7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGFycmF5W2ldLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYXJyYXlbaV1bal0gPT0gbnVtYmVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWZGaW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gaWZGaW5kO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL2ZpbmQgdGhlIG5vZGUgd2l0aCB0aGUga2V5IGFuZCByZXR1cm4gYW4gYXJyYXlcclxuICAgIGZpbmROb2RlOiBmdW5jdGlvbiAoYXJyYXksIG51bWJlcikge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KGFycmF5LCBudW1iZXIpKSB7XHJcbiAgICAgICAgICAgIGxldCBhcnJheVRvUmV0dXJuID0gW107XHJcbiAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgYXJyYXlbaV0ubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoYXJyYXlbaV1bal0gPT0gbnVtYmVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFycmF5VG9SZXR1cm5bY291bnRdID0gW2ksIGpdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gYXJyYXlUb1JldHVybjtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vY2hlY2sgaWYgdGhlIGN1cnJlbnQgbG9jYXRpb24gaXMgaW4gYm91bmRcclxuICAgIGluQm91bmQ6IGZ1bmN0aW9uICh5LCB4KSB7XHJcbiAgICAgICAgaWYgKHkgPCAwIHx8IHkgPj0gdGhpcy5zaXplWSB8fCB4IDwgMCB8fCB4ID49IHRoaXMuc2l6ZVgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL3JlcGxhY2Ugd2l0aCBub2RlIGJ5IGNvcnJlZGluYXRlXHJcbiAgICByZXBsYWNlTm9kZUJ5Q29vcmRpbmF0ZTogZnVuY3Rpb24gKGFycmF5Tm9kZSwgYXJyYXlNYXAsIHksIHgsIG5ld051bSkge1xyXG4gICAgICAgIGxldCBub2RlVG9EZXN0b3J5ID0gdGhpcy5tYXBOb2RlLmdldENoaWxkQnlOYW1lKHkgKyAnMDAnICsgeCk7XHJcbiAgICAgICAgbm9kZVRvRGVzdG9yeS5kZXN0cm95KCk7XHJcbiAgICAgICAgYXJyYXlOb2RlW3ldW3hdID0gdGhpcy5pbml0Tm9kZShuZXdOdW0sIHksIHgsIDMyKTtcclxuICAgICAgICBhcnJheU1hcFt5XVt4XSA9IG5ld051bTtcclxuICAgIH0sXHJcblxyXG4gICAgLy9yZXBsYWNldyBhIHNpbmdsZSBibG9jayBvZiBvcmdlbk51bSB0eXBlIHRvIG5ld051bVxyXG4gICAgcmVwbGFjZU5vZGVCeUtpbmQ6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwLCBvcmlnZW5OdW0sIG5ld051bSkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KGFycmF5TWFwLCBvcmlnZW5OdW0pKSB7XHJcbiAgICAgICAgICAgIGxldCBsaXN0T2ZJdGVtID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgb3JpZ2VuTnVtKTtcclxuICAgICAgICAgICAgbGV0IGluZGV4ID0gKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGxpc3RPZkl0ZW0ubGVuZ3RoKSk7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUNvb3JkaW5hdGUoYXJyYXlOb2RlLCBhcnJheU1hcCwgbGlzdE9mSXRlbVtpbmRleF1bMF0sIGxpc3RPZkl0ZW1baW5kZXhdWzFdLCBuZXdOdW0pO1xyXG4gICAgICAgICAgICByZXR1cm4gW2xpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL3JlcGxhY2UgYWxsIG5vZGUgd2l0aCBcclxuICAgIHJlcGxhY2VBbGw6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwLCBvcmlnZW5OdW0sIG5ld051bSkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KGFycmF5TWFwLCBvcmlnZW5OdW0pKSB7XHJcbiAgICAgICAgICAgIGxldCByZXBsYWNlQXJyYXkgPSB0aGlzLmZpbmROb2RlKGFycmF5TWFwLCBvcmlnZW5OdW0pO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlcGxhY2VBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5Q29vcmRpbmF0ZShhcnJheU5vZGUsIGFycmF5TWFwLCByZXBsYWNlQXJyYXlbaV1bMF0sIHJlcGxhY2VBcnJheVtpXVsxXSwgbmV3TnVtKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9jaGVjayBzdXJyb3VuZGluZyBibG9ja3NcclxuICAgIHN1ckNoZWNrOiBmdW5jdGlvbiAoYXJyYXksIHksIHgsIG51bVRvUmVwbGFjZSkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAtMTsgaSA8IDI7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gLTE7IGogPCAyOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmluQm91bmQoeSArIGksIHggKyBqKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhcnJheVt5ICsgaV1beCArIGpdID09IG51bVRvUmVwbGFjZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL3JlcGxhY2UgeCBudW1iZXIgb2YgYmxvY2sgd2l0aCAnb3JpZ2VuTnVtJyB0eXBlIHRoYXQgc3Vycm91bmQgKHgseSkgYmxvY2sgd2l0aCAncmVwbGFjZU51bScgdHlwZVxyXG4gICAgc3VyUmVwbGFjZVNpbmdsZU9mVHlwZTogZnVuY3Rpb24gKGFycmF5Tm9kZSwgYXJyYXlNYXAsIHksIHgsIG9yaWdlbk51bSwgcmVwbGFjZU51bSkge1xyXG4gICAgICAgIC8vZ2l2ZXMgYSBwbGFjZW1lbnQgLTEsIDAsIDFcclxuICAgICAgICBsZXQgbW92ZVggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKSAtIDE7XHJcbiAgICAgICAgbGV0IG1vdmVZID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMykgLSAxO1xyXG4gICAgICAgIGxldCBuZXdYID0geCArIG1vdmVYO1xyXG4gICAgICAgIGxldCBuZXdZID0geSArIG1vdmVZO1xyXG4gICAgICAgIGlmICh0aGlzLnN1ckNoZWNrKHRoaXMubWFwS2V5LCB5LCB4LCBvcmlnZW5OdW0pKSB7XHJcbiAgICAgICAgICAgIC8vd2hpbGUgdGhlIHN1cnJvdW5kaW5nIG5vZGUgaXMgbm90IHRoZSBvcmlnZW5hbCBub2RlIHdlIHdhbnQgdG8gcmVwbGFjZVxyXG4gICAgICAgICAgICB3aGlsZSAoYXJyYXlNYXBbbmV3WV1bbmV3WF0gIT0gb3JpZ2VuTnVtIHx8ICF0aGlzLmluQm91bmQobmV3WSwgbmV3WCkpIHtcclxuICAgICAgICAgICAgICAgIG1vdmVYID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMykgLSAxO1xyXG4gICAgICAgICAgICAgICAgbW92ZVkgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKSAtIDE7XHJcbiAgICAgICAgICAgICAgICBuZXdYID0geCArIG1vdmVYO1xyXG4gICAgICAgICAgICAgICAgbmV3WSA9IHkgKyBtb3ZlWTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlDb29yZGluYXRlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIG5ld1ksIG5ld1gsIHJlcGxhY2VOdW0pO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9yZXBsYWNlIHggbnVtYmVyIG9mIGJsb2NrIHRoYXQgc3Vycm91bmQgKHgseSkgYmxvY2sgd2l0aCAncmVwbGFjZU51bScgdHlwZVxyXG4gICAgc3VyUmVwbGFjZVNpbmdsZTogZnVuY3Rpb24gKGFycmF5Tm9kZSwgYXJyYXlNYXAsIHksIHgsIHJlcGxhY2VOdW0pIHtcclxuICAgICAgICAvL2dpdmVzIGEgcGxhY2VtZW50IC0xLCAwLCAxXHJcbiAgICAgICAgbGV0IG1vdmVYID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMykgLSAxO1xyXG4gICAgICAgIGxldCBtb3ZlWSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpIC0gMTtcclxuICAgICAgICBsZXQgbmV3WCA9IHggKyBtb3ZlWDtcclxuICAgICAgICBsZXQgbmV3WSA9IHkgKyBtb3ZlWTtcclxuICAgICAgICB3aGlsZSAoKG1vdmVYID09IDAgJiYgbW92ZVkgPT0gMCkgfHwgIXRoaXMuaW5Cb3VuZChuZXdZLCBuZXdYKSkge1xyXG4gICAgICAgICAgICBtb3ZlWCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpIC0gMTtcclxuICAgICAgICAgICAgbW92ZVkgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKSAtIDE7XHJcbiAgICAgICAgICAgIG5ld1ggPSB4ICsgbW92ZVg7XHJcbiAgICAgICAgICAgIG5ld1kgPSB5ICsgbW92ZVk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUNvb3JkaW5hdGUoYXJyYXlOb2RlLCBhcnJheU1hcCwgbmV3WSwgbmV3WCwgcmVwbGFjZU51bSk7XHJcbiAgICB9LFxyXG4gXHJcbiAgICBjbGlja0JhY2tIb21lQnV0dG9uOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3JldHVybiB0byBtYWluIHBhZ2UnKTtcclxuICAgICAgICB0aGlzLnNhdmVVc2VyRGF0YSgpO1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnN0b3BBbGwoKTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJ3ZWxjb21lXCIpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgY2xpY2tTaGFyZUJ1dHRvbjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNhbnZhcy50b1RlbXBGaWxlUGF0aCh7XHJcbiAgICAgICAgICAgIGRlc3RXaWR0aDogODAwLFxyXG4gICAgICAgICAgICBkZXN0SGVpZ2h0OiA2NDAsXHJcbiAgICAgICAgICAgIHN1Y2Nlc3MgKHJlcykge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLlj6/ku6Xkv53lrZjor6XmiKrlsY/lm77niYcgIFwiLHJlcyk7XHJcbiAgICAgICAgICAgICAgICB3eC5zaGFyZUFwcE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIuS4gOi1t+adpeeOqeWQp++9nlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGltYWdlVXJsOiByZXMudGVtcEZpbGVQYXRoLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3MocmVzKXt9LFxyXG4gICAgICAgICAgICAgICAgICAgIGZhaWwoKXt9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9LFxyXG5cclxuIFxyXG4gICAgLy9hY3Rpb25zICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHJcbiAgICAvL2NsaWNrIGJ1dHRvbiBcIjFcIlxyXG4gICAgY2xpY2tCdXR0b24xOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmF1ZGlvQ2xpY2ssIGZhbHNlLCAxKTtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVs3XSA8IHRoaXMuZ2FtZURhdGFbOF0pIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+azleWKm+WAvOS4jei2s++8jOeCueWHu+aXoOaViFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5nYW1lRGF0YVs3XSA9IDA7XHJcbiAgICAgICAgdGhpcy5hY3Rpb24xKCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL2NsaWNrIGJ1dHRvbiBcIjJcIlxyXG4gICAgY2xpY2tCdXR0b24yOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmF1ZGlvQ2xpY2ssIGZhbHNlLCAxKTtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVs3XSA8IDYwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfms5XlipvlgLzkuI3otrPvvIzngrnlh7vml6DmlYhcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbN10tPTYwXHJcbiAgICAgICAgdGhpcy5hY3Rpb24yKCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL2NsaWNrIGJ1dHRvbiBcIjNcIlxyXG4gICAgY2xpY2tCdXR0b24zOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmF1ZGlvQ2xpY2ssIGZhbHNlLCAxKTtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVs3XSA8IDQwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfms5XlipvlgLzkuI3otrPvvIzngrnlh7vml6DmlYhcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbN10tPTQwXHJcbiAgICAgICAgdGhpcy5hY3Rpb24zKCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL2NsaWNrIGJ1dHRvbiBcIjRcIlxyXG4gICAgY2xpY2tCdXR0b240OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmF1ZGlvQ2xpY2ssIGZhbHNlLCAxKTtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVs3XSA8IDIwICsgdGhpcy5nYW1lRGF0YVsxMV0pIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+azleWKm+WAvOS4jei2s++8jOeCueWHu+aXoOaViFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5nYW1lRGF0YVs3XS09MjAgKyB0aGlzLmdhbWVEYXRhWzExXTtcclxuICAgICAgICB0aGlzLmFjdGlvbjQoKTtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vY2xpY2sgYnV0dG9uIFwiNVwiXHJcbiAgICBjbGlja0J1dHRvbjU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMuYXVkaW9DbGljaywgZmFsc2UsIDEpO1xyXG4gICAgICAgIGlmICh0aGlzLmdhbWVEYXRhWzddIDwgMzApIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+azleWKm+WAvOS4jei2s++8jOeCueWHu+aXoOaViFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5nYW1lRGF0YVs3XS09MzA7XHJcbiAgICAgICAgdGhpcy5hY3Rpb241KCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL2NsaWNrIGJ1dHRvbiBcIjZcIlxyXG4gICAgY2xpY2tCdXR0b242OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmF1ZGlvQ2xpY2ssIGZhbHNlLCAxKTtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVs3XSA8IDUwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfms5XlipvlgLzkuI3otrPvvIzngrnlh7vml6DmlYhcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbN10tPSA1MDtcclxuICAgICAgICB0aGlzLmFjdGlvbjYoKTtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vbGFuZFxyXG4gICAgYWN0aW9uMTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vaWYgKG1hbmEgPCAxMjApIHtcclxuICAgICAgICAvLyAgICByZXR1cm47XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9tYW5hIC09IDEyMDtcclxuICAgICAgICB0aGlzLmdlbkdyb3VuZCgpOyAvL+WinuWKoOmZhuWcsO+8jOa2iOiAl+WFqOmDqOazleWKm1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvL3N0b25lXHJcbiAgICBhY3Rpb24yOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy9pZiAobWFuYSA8IDYwKSB7XHJcbiAgICAgICAgLy8gICAgLy9ub3RpZmljYXRpb25cclxuICAgICAgICAvLyAgICByZXR1cm47XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9tYW5hIC09IDYwO1xyXG4gICAgICAgIC8vIOWlveS6i+WVilxyXG4gICAgICAgIGxldCByYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjcsIHRoaXMuZ2FtZURhdGFbNF0pKSB7XHJcbiAgICAgICAgICAgIGxldCByYW5kb21OdW0gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyKTtcclxuICAgICAgICAgICAgc3dpdGNoIChyYW5kb21OdW0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogdGhpcy5nZW5Hcm91bmQoKTsgLy/lop7liqDpmYblnLBcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTogdGhpcy5nZW5TdG9uZSh0aGlzLmdhbWVEYXRhKTsgLy/liLfmlrDpk4Hnn7/vvIzlj5HnjrDliqDnp5HmioBcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAocmFuZG9tIDwgTWF0aC5wb3coMC45LCB0aGlzLmdhbWVEYXRhWzRdKSkgeyAvLyDlsLHpgqPkuYjlm57kuovlkKdcclxuICAgICAgICAgICAgbGV0IG51bWJlcnNPZkFjdGlvbiA9IDI7XHJcbiAgICAgICAgICAgIGxldCByYW5kb21OdW0gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBudW1iZXJzT2ZBY3Rpb24pO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHJhbmRvbU51bSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiB0aGlzLmdlblZvY2FubygpOyAvL+eUn+aIkOeBq+WxsVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOiB0aGlzLnZvY2Fub0V4KHRoaXMubWFwS2V5KTsgLy/ngavlsbHllrflj5HvvIzkuqfnlJ/nn7PlpLRcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7IC8vIOS4jeimgei/meS4qu+8ge+8gVxyXG4gICAgICAgICAgICBsZXQgbnVtYmVyc09mQWN0aW9uID0gMjtcclxuICAgICAgICAgICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZkFjdGlvbik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHRoaXMuZGVzZXJ0aWZpY2F0aW9uKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXkpOyAvL+aymea8oOWMllxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOiB0aGlzLmVhcnRocXVha2UodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSk7IC8v5Zyw6ZyHXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vc2t5XHJcbiAgICBhY3Rpb24zOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy8g5aW95LqL5ZWKXHJcbiAgICAgICAgLy9pZiAobWFuYSA8IDQwKSB7XHJcbiAgICAgICAgLy8gICAgLy9ub3RpZmljYXRpb25cclxuICAgICAgICAvLyAgICByZXR1cm47XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9tYW5hIC09IDQwO1xyXG4gICAgICAgIGxldCByYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjEsIHRoaXMuZ2FtZURhdGFbNF0pKSB7XHJcbiAgICAgICAgICAgIGxldCBudW1iZXJzT2ZBY3Rpb24gPSAyO1xyXG4gICAgICAgICAgICBsZXQgcmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbnVtYmVyc09mQWN0aW9uKTtcclxuICAgICAgICAgICAgc3dpdGNoIChyYW5kb21OdW0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogdGhpcy5zdG9ybSh0aGlzLmdhbWVEYXRhKTsgLy/pm7cg5aKe5Yqg56eR5oqAXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHRoaXMuZm9vZERvdWJsZSh0aGlzLmdhbWVEYXRhKTsgLy/kuLDmlLZcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAocmFuZG9tIDwgTWF0aC5wb3coMC44LCB0aGlzLmdhbWVEYXRhWzRdKSkgeyAvLyDlsLHpgqPkuYjlm57kuovlkKdcclxuICAgICAgICAgICAgbGV0IG51bWJlcnNPZkFjdGlvbiA9IDI7XHJcbiAgICAgICAgICAgIGxldCByYW5kb21OdW0gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBudW1iZXJzT2ZBY3Rpb24pO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHJhbmRvbU51bSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiB0aGlzLnJhaW4odGhpcy5nYW1lRGF0YSk7IC8v6ZmN5rC0XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHRoaXMud2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5KTsgLy/po47vvIwg5ZC56LWw5Lu75L2V54mp5ZOBXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgeyAvLyDkuI3opoHov5nkuKrvvIHvvIFcclxuICAgICAgICAgICAgbGV0IG51bWJlcnNPZkFjdGlvbiA9IDE7IC8vbmVlZCBjaGFuZ2VcclxuICAgICAgICAgICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZkFjdGlvbik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHRoaXMuZHJvdWdodCh0aGlzLmdhbWVEYXRhKTsgLy/lubLml7HvvIzmpoLnjofngavngb7vvIznsq7po5/lh4/kuqdcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTogdGhpcy5mbG9vZCgpOy8v5rC054G+77yM5Zyf5Zyw5Y+Y5oiQ5rC0XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6IC8vdGhpcy5vbkZpcmUoKTsgLy/ngavngb5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9wbGFudFxyXG4gICAgYWN0aW9uNDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vaWYgKG1hbmEgPCAxMCkge1xyXG4gICAgICAgIC8vbm90aWZpY2F0aW9uXHJcbiAgICAgICAgLy8gICAgcmV0dXJuO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vbWFuYSAtPSAxMDtcclxuICAgICAgICAvLyDlpb3kuovllYpcclxuICAgICAgICBsZXQgcmFuZG9tID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBpZiAocmFuZG9tIDwgTWF0aC5wb3coMC43LCB0aGlzLmdhbWVEYXRhWzRdKSkge1xyXG4gICAgICAgICAgICBsZXQgbnVtYmVyc09mQWN0aW9uID0gMztcclxuICAgICAgICAgICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZkFjdGlvbik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHRoaXMuZ2VuQmVycnkoKTsgLy/mnpzmoJEg5YmN5pyf54mp6LWE77yM5Yqg6aOf54mpXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHRoaXMuZ2VuVHJlZSgpOyAvL+agkVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOiB0aGlzLmdlbkdyYXNzKCk7IC8v6I2JXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHJhbmRvbSA8IE1hdGgucG93KDAuOSwgdGhpcy5nYW1lRGF0YVs0XSkpIHsgLy8g5bCx6YKj5LmI5Zue5LqL5ZCnXHJcbiAgICAgICAgICAgIHRoaXMuZ2VuUG9pc29uKCk7ICAvL+avkuaenOWtkO+8jOWQg+S6huS8muatu+OAglxyXG4gICAgICAgIH0gZWxzZSB7IC8vIOS4jeimgei/meS4qu+8ge+8gVxyXG4gICAgICAgICAgICB0aGlzLmdlbkNyb3AoKTsgLy/ogJXlnLBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vYW5pbWFsXHJcbiAgICBhY3Rpb241OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy9pZiAobWFuYSA8IDMwKSB7XHJcbiAgICAgICAgLy8gICAgLy9ub3RpZmljYXRpb25cclxuICAgICAgICAvLyAgICByZXR1cm47XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9tYW5hIC09IDMwO1xyXG4gICAgICAgIC8vIOWwj+Wei+WKqOeJqVxyXG4gICAgICAgIGxldCByYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjUsIHRoaXMuZ2FtZURhdGFbNF0pKSB7XHJcbiAgICAgICAgICAgIGxldCBudW1iZXJzT2ZBY3Rpb24gPSAyO1xyXG4gICAgICAgICAgICBsZXQgcmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbnVtYmVyc09mQWN0aW9uKTtcclxuICAgICAgICAgICAgc3dpdGNoIChyYW5kb21OdW0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogdGhpcy5nZW5Eb2codGhpcy5nYW1lRGF0YSk7IC8vIPCfkJXvvIznp5HmioDlgLzlpKfkuo4xLjLpqa/mnI3vvIzlh4/lsJHlpKflnovliqjnianmlLvlh7vmpoLnjodcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTogdGhpcy5nZW5DaGlja2VuKCk7IC8vIPCfkJPvvIznp5HmioDkuYvlpKfkuo4gMS4x6amv5pyN77yM5q+P5bm05bCR6YeP8J+Nl1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjc1LCB0aGlzLmdhbWVEYXRhWzRdKSkgeyAvLyDkuK3lnovliqjnialcclxuICAgICAgICAgICAgdGhpcy5nZW5TaGVlcCgpOyAvL/CfkI/vvIwg5q+P5bm05Lit6YeP8J+Nlu+8jOenkeaKgOWAvOWkp+S6jjIg5Y+v6amv5pyNXHJcbiAgICAgICAgfSBlbHNlIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjksIHRoaXMuZ2FtZURhdGFbNF0pKSB7IC8vIOWwsemCo+S5iOWbnuS6i+WQp1xyXG4gICAgICAgICAgICB0aGlzLmdlbkNvdygpOyAvL/CfkILvvIwg5Lya5pS75Ye75Lq677yM5q+P5bm05aSn6YeP8J+lqe+8jOenkeaKgOWAvOWkp+S6jjPlj6/pqa/mnI3vvIzpqa/mnI3lkI7mlLvlh7tcclxuICAgICAgICB9IGVsc2UgeyAvLyDkuI3opoHov5nkuKrvvIHvvIFcclxuICAgICAgICAgICAgdGhpcy5nZW5MaW9uKHRoaXMuZ2FtZURhdGEpOyAvL/CfpoHvvIzkvJrmlLvlh7vkurrvvIzml6Dms5Xpqa/mnI1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vcG9wdWxhdGlvblxyXG4gICAgYWN0aW9uNjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuZ2VuUGVvcGxlKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgIC8vdGhpcy5nYW1lRGF0YVswXSA9IDA7Ly90ZXN0XHJcbiAgICB9LFxyXG5cclxuICAgIC8vc3Bhd24gaXNsYW5kLCBzcGF3biB2b2Nhbiwgc3Bhd24gc3RvbmUsIGRlc2VydGlmaWNhdGlvbiAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5cclxuICAgIGdlblBlb3BsZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGlmIChhcnJheURhdGFbMl0gPiA1MCkge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbMF0gKz0gNTtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzJdIC09IDUwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfkurrlj6MrNVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZURhdGFbOV0gKz0gNTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6aOf54mp5LiN6Laz77yM6ZyA6KaBNTDpo5/nialcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy9leHRlbmQgZ3JvdW5kXHJcbiAgICBnZW5Hcm91bmQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBsZXQgcG9zaXRpb24gPSB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDEsIDIpO1xyXG4gICAgICAgIGlmIChwb3NpdGlvbiAhPSAwICYmIHRoaXMuc3VyQ2hlY2sodGhpcy5tYXBLZXksIHBvc2l0aW9uWzBdLCBwb3NpdGlvblsxXSwgMCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgcG9zaXRpb24gPSB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDEsIDIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDEgKyAyICogTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNCk7IGkrKykge1xyXG4gICAgICAgICAgICB0aGlzLnN1clJlcGxhY2VTaW5nbGVPZlR5cGUodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgcG9zaXRpb25bMF0sIHBvc2l0aW9uWzFdLCAwLCAxKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAxKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDAsIDEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmdhbWVEYXRhWzldICs9IDIwO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCfpmYblnLDmianlvKAnKTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJysgJyDpmYblnLDmianlvKBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICBnZW5TdG9uZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAxKSkgeyAgICAgICAgIFxyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDEsIDcpO1xyXG4gICAgICAgICAgICBhcnJheURhdGFbNF0gKz0gMC4wMTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+aJvuWIsOefv+eJqe+8jOenkeaKgCswLjAxJyk7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzNdICs9IDEwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5Lq65Lus5Y+R546w5Y+R546w5LqG5LiA5Liq5paw55+z55+/77yMXFxu6LWE5rqQKzEw77yM56eR5oqAKzAuMDFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMikpIHtcclxuICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAyLCA3KTtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzRdICs9IDAuMDE7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfmib7liLDnn7/nianvvIznp5HmioArMC4wMScpO1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVszXSArPSAxMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOS6uuS7rOWPkeeOsOWPkeeOsOS6huS4gOS4quaWsOefs+efv++8jFxcbui1hOa6kCsxMO+8jOenkeaKgCswLjAxXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56m65Zyw5LiN6Laz77yM5peg5rOV5Lqn55Sf55+z55+/XFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL2dlbmVyYXRlIGEgdm9jYW5vXHJcbiAgICBnZW5Wb2Nhbm86IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMSkpIHtcclxuICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxLCA2KTtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOadv+Wdl+i/kOWKqO+8jOW9ouaIkOeBq+WxsVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDYpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5p2/5Z2X6L+Q5Yqo77yM5b2i5oiQ54Gr5bGxXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnqbrlnLDkuI3otrPvvIzml6Dms5XlvaLmiJDngavlsbFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAwLCA2KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDmnb/lnZfov5DliqjvvIzlvaLmiJDngavlsbFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB2b2Nhbm8gZXhwbG9kZVxyXG4gICAgdm9jYW5vRXg6IGZ1bmN0aW9uIChhcnJheU1hcCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCA2KSkge1xyXG4gICAgICAgICAgICBsZXQgbGlzdE9mSXRlbSA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDYpO1xyXG4gICAgICAgICAgICBsZXQgaW5kZXggPSAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbGlzdE9mSXRlbS5sZW5ndGgpKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KSArIDE7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdXJSZXBsYWNlU2luZ2xlKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIGxpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXSwgNyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOeBq+WxseWWt+WPkVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7ICAgICAgICAgIFxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ2VuVm9jYW5vKCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCA2KSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOeBq+WxseWWt+WPkVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vZWFydGhxdWFrZVxyXG4gICAgZWFydGhxdWFrZTogZnVuY3Rpb24gKGFycmF5Tm9kZSwgYXJyYXlNYXApIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwKSArIDU7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgeSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5TWFwLmxlbmd0aCk7XHJcbiAgICAgICAgICAgIGxldCB4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXlNYXBbMF0ubGVuZ3RoKTtcclxuICAgICAgICAgICAgbGV0IG9yaUhvdXNlID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsMyk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogb3JpSG91c2UgLyAzKTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDMpID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3VyUmVwbGFjZVNpbmdsZU9mVHlwZShhcnJheU5vZGUsIGFycmF5TWFwLCB5LCB4LCAzLCA3KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdhbWVEYXRhWzBdLT0gTWF0aC5jZWlsKE1hdGgucmFuZG9tKCkgKiAzKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVswXSA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2FtZURhdGFbMF0gPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKCflnLDpnIfllaYnKTtcclxuICAgICAgICB0aGlzLmdhbWVEYXRhWzldIC09IDEwO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDlj5HnlJ/kuoblnLDpnIfvvIzkurrlj6Plh4/lsJFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL0Rlc2VydGlmaWNhdGlvblxyXG4gICAgZGVzZXJ0aWZpY2F0aW9uOiBmdW5jdGlvbiAoYXJyYXlOb2RlLCBhcnJheU1hcCkge1xyXG4gICAgICAgIGxldCByYW5kTnVtID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMikpIHtcclxuICAgICAgICAgICAgbGV0IGdyYXNzID0gdGhpcy5maW5kTm9kZSh0aGlzLm1hcEtleSwgMik7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcihncmFzcy5sZW5ndGggLyAxMCk7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgcmFuZE51bSA9IE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmFuZE51bSA8IDAuNikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQoYXJyYXlOb2RlLCBhcnJheU1hcCwgMiwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDUpKSB7XHJcbiAgICAgICAgICAgIGxldCBjcm9wID0gdGhpcy5maW5kTm9kZSh0aGlzLm1hcEtleSwgNSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcihjcm9wLmxlbmd0aCAvIDEwKTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICByYW5kTnVtID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICAgICAgICAgIGlmIChyYW5kTnVtIDwgMC40KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZChhcnJheU5vZGUsIGFycmF5Tm9kZSwgNCwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+aymea8oOWMlicpO1xyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbOV0gLT0gMjA7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOWcn+WcsOaymea8oOWMlu+8jOWGnOeUsOaUtuaIkOWPl+aNn1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vcmFpbiwgZHJ5LCBoYXJ2ZXN0LCBzdG9ybSAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHJcbiAgICAvL2hhcnZlc3RcclxuICAgIGZvb2REb3VibGU6IGZ1bmN0aW9uIChnYW1lRGF0YSkge1xyXG4gICAgICAgIGdhbWVEYXRhWzJdICo9IDEuNTtcclxuICAgICAgICBjb25zb2xlLmxvZygn6aOf54mp5Liw5pS2Jyk7XHJcbiAgICAgICAgZ2FtZURhdGFbOV0gKz0gMjBcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg6aOO6LCD6Zuo6aG677yM6aOf54mp5aSn5Liw5pS2XFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgLy9zdG9ybVxyXG4gICAgc3Rvcm06IGZ1bmN0aW9uIChnYW1lRGF0YSkge1xyXG4gICAgICAgIGxldCB3b3JkID0gJyc7XHJcbiAgICAgICAgZ2FtZURhdGFbNF0gKz0gMC4wMTtcclxuICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA+IDAuNSkge1xyXG4gICAgICAgICAgICBnYW1lRGF0YVs1XSArPSAwLjI7XHJcbiAgICAgICAgICAgIHdvcmQgPSAn6Zuo5rC054GM5rqJ5LqG5bqE56i8JztcclxuICAgICAgICAgICAgZ2FtZURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZ2FtZURhdGFbNV0gLT0gMC4yO1xyXG4gICAgICAgICAgICBnYW1lRGF0YVs5XSAtPSAxMDtcclxuICAgICAgICAgICAgd29yZCA9ICfpgKDmiJDmsLTngb4nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZygn6Zu36Zi16ZuoJyk7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOmbt+mYtembqCAnICsgd29yZCArICdcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL3JhaW46IGZvb2QgYm9vc3RcclxuICAgIHJhaW46IGZ1bmN0aW9uIChnYW1lRGF0YSkge1xyXG4gICAgICAgIGdhbWVEYXRhWzVdICs9IE1hdGgucmFuZG9tKCkgLyAyO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCfkuIvpm6jllaYnKTtcclxuICAgICAgICBnYW1lRGF0YVs5XSArPSAxMDtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5LiL6Zuo5ZWmXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgLy9kcm91Z2h0OiBmb29kIGRlY2F5XHJcbiAgICBkcm91Z2h0OiBmdW5jdGlvbiAoZ2FtZURhdGEpIHtcclxuICAgICAgICBnYW1lRGF0YVs1XSAtPSBNYXRoLnJhbmRvbSgpIC8gMjtcclxuICAgICAgICBjb25zb2xlLmxvZygn5bmy5pexJyk7XHJcbiAgICAgICAgZ2FtZURhdGFbOV0gLT0gMjA7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOmbqOawtOWwke+8jOWPkeeUn+S6huW5suaXsVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vd2luZDogcmVvbXZlIHNvbWUgbm9kZVxyXG4gICAgd2luZDogZnVuY3Rpb24gKGFycmF5Tm9kZSwgYXJyYXlNYXApIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgOCkpIHtcclxuICAgICAgICAgICAgbGV0IHRyZWUgPSB0aGlzLmZpbmROb2RlKGFycmF5TWFwLCA4KTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKHRyZWUubGVuZ3RoIC8gMTApOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgMC4yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZChhcnJheU5vZGUsIGFycmF5TWFwLCA4LCAyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgNSkpIHtcclxuICAgICAgICAgICAgbGV0IHdoZWF0ID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgNSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcih3aGVhdC5sZW5ndGggLyAxMCk7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjEpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKGFycmF5Tm9kZSwgYXJyYXlNYXAsIDUsIDIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAzKSkge1xyXG4gICAgICAgICAgICBsZXQgaG91c2UgPSB0aGlzLmZpbmROb2RlKGFycmF5TWFwLCAzKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKGhvdXNlLmxlbmd0aCAvIDEwKTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQoYXJyYXlOb2RlLCBhcnJheU1hcCwgMywgMik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDcpKSB7XHJcbiAgICAgICAgICAgIGxldCBzdG9uZSA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDcpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IE1hdGguZmxvb3Ioc3RvbmUubGVuZ3RoIC8gMTApOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgMC4yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZChhcnJheU5vZGUsIGFycmF5TWFwLCA3LCAyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZygn5Yiu5aSn6aOOJyk7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOWkp+mjjuadpeiirVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGZsb29kOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDEpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMSwgMCk7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDniIblj5HmtKrmsLTvvIzmt7nmsqHkuobmspnlnLBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMikpIHtcclxuICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAyLCAwKTtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOeIhuWPkea0quawtO+8jOa3ueayoeS6huiNieWcsFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAzKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDMsIDApO1xyXG4gICAgICAgICAgICB0aGlzLmdhbWVEYXRhWzBdIC09IE1hdGguY2VpbChNYXRoLnJhbmRvbSgpICogMyk7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCcgKyAnIOeIhuWPkea0quawtO+8jOa3ueayoeS6huadkeW6hFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCA1KSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDUsIDApO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQnICsgJyDniIblj5HmtKrmsLTvvIzmt7nmsqHkuobnlLDlnLBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvLy8vZmlyZSBldmVudFxyXG4gICAgLy9vbkZpcmU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAvLyAgICBsZXQgbGlzdE9mSXRlbUZvcmVzdCA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDQpO1xyXG4gICAgLy8gICAgbGV0IGxpc3RPZkl0ZW1Ib3VzZSA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDYpO1xyXG4gICAgLy8gICAgbGV0IGxpc3RPZkl0ZW1GcmFtID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgNyk7XHJcbiAgICAvLyAgICBsZXQgbnVtYmVyc09mUGxhY2UgPSAzO1xyXG4gICAgLy8gICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZlBsYWNlKTtcclxuICAgIC8vICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAvLyAgICAgICAgY2FzZSAwOiBpZiAobGlzdE9mSXRlbUZvcmVzdCAhPSBudWxsKSB7XHJcbiAgICAvLyAgICAgICAgICAgIGxldCBpbmRleCA9IChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBsaXN0T2ZJdGVtLmxlbmd0aCkpO1xyXG4gICAgLy8gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIGxpc3RPZkl0ZW1Gb3Jlc3RbaW5kZXhdWzBdLCBsaXN0T2ZJdGVtRm9yZXN0W2luZGV4XVsxXSwgOSk7XHJcbiAgICAvLyAgICAgICAgICAgIHJldHVybiBbbGlzdE9mSXRlbVtpbmRleF1bMF0sIGxpc3RPZkl0ZW1baW5kZXhdWzFdXTtcclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgLy8gICAgICAgIGNhc2UgMTogaWYgKGxpc3RPZkl0ZW1Ib3VzZSAhPSBudWxsKSB7XHJcbiAgICAvLyAgICAgICAgICAgIGxldCBpbmRleCA9IChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBsaXN0T2ZJdGVtLmxlbmd0aCkpO1xyXG4gICAgLy8gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIGxpc3RPZkl0ZW1Ib3VzZVtpbmRleF1bMF0sIGxpc3RPZkl0ZW1Ib3VzZVtpbmRleF1bMV0sIDkpO1xyXG4gICAgLy8gICAgICAgICAgICByZXR1cm4gW2xpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXV07XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICAgICBicmVhaztcclxuICAgIC8vICAgICAgICBjYXNlIDI6IGlmIChsaXN0T2ZJdGVtSG91c2VGcmFtICE9IG51bGwpIHtcclxuICAgIC8vICAgICAgICAgICAgbGV0IGluZGV4ID0gKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGxpc3RPZkl0ZW0ubGVuZ3RoKSk7XHJcbiAgICAvLyAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGUoYXJyYXlOb2RlLCBhcnJheU1hcCwgbGlzdE9mSXRlbUZyYW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtRnJhbVtpbmRleF1bMV0sIDkpO1xyXG4gICAgLy8gICAgICAgICAgICByZXR1cm4gW2xpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXV07XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICAgICBicmVhaztcclxuICAgIC8vICAgIH1cclxuICAgIC8vICAgIHRoaXMubG9nLnN0cmluZyA9ICdZZWFyICcgKyB0aGlzLnRpbWUgKyAnIG9uRmlyZVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAvL30sXHJcblxyXG4gICAgLy8vL29mZiBmaXJlIGV2ZW50XHJcbiAgICAvL09mZkZpcmU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAvLyAgICB0aGlzLnJlcGxhY2VBbGwoYXJyYXlOb2RlLCBhcnJheU1hcCwgOSwgMSk7XHJcbiAgICAvLyAgICB0aGlzLmxvZy5zdHJpbmcgPSAnWWVhciAnICsgdGhpcy50aW1lICsgJyBvZmYgZmlyZVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAvL30sXHJcblxyXG4gICAgLy9iZXJyeSwgdHJlZSwgZnJ1aXQsIHBvaXNvbiAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHJcbiAgICAvL2dyb3cgYmVycnlidXNoXHJcbiAgICBnZW5CZXJyeTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDEwKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOaenOS4mycpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfnlJ/miJDmtYbmnpzkuJtcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIznp43mpI3mtYbmnpzkuJvlpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9ncm93IHBvaXNvblxyXG4gICAgZ2VuUG9pc29uOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgMTYpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ5q+S5p6c5LibJyk7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDnlJ/miJDmr5LmnpzkuJtcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIznp43mpI3mtYbmnpzkuJvlpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9wbGFudCBjcm9wXHJcbiAgICBnZW5Dcm9wOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgNCk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlJ/miJDogJXlnLAnKTtcclxuICAgICAgICAgICAgdGhpcy5nYW1lRGF0YVs5XSArPSAxMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOW8gOaLk+iAleWcsFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+iNieWcsOS4jei2s++8jOW8gOWepuiAleWcsOWksei0pVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvL2dyYXNzIGdyb3cgdXAgdG8gdHJlZXNcclxuICAgIGdlblRyZWU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMikgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+iNieWcsOS4jei2s++8jOakjeagkemAoOael+Wksei0pVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDgpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCfnlJ/miJDmoJEnKTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyAgKyAnIOakjeagkemAoOael1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGdlbkdyYXNzOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxLCAyKTtcclxuICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ6I2JJyk7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgICsgJyDojYnvvIzmjIfkuIDnp43mpI3nialcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL2NoaWNrZW4sIGRvZywgY293LCBzaGVlcCwgbGlvbiAgICAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHJcbiAgICBnZW5DaGlja2VuOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgMTEpOyAgXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlJ/miJDpuKEnKTtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgICsgJyDlj5HnjrDkuIDlj6rph47puKFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIzop6blj5Hliqjniankuovku7blpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgZ2VuRG9nOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgMTIpO1xyXG4gICAgICAgICAgICBhcnJheURhdGFbNl1bMV0gKz0gMTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOeLvCcpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5Y+R546w5LiA5Y+q6YeO54u8XFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6I2J5Zyw5LiN6Laz77yM6Kem5Y+R5Yqo54mp5LqL5Lu25aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgIFxyXG4gICAgZ2VuQ293OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgMTMpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ54mbJyk7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDlj5HnjrDkuIDlpLTph47niZtcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIzop6blj5Hliqjniankuovku7blpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgZ2VuU2hlZXA6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMikpIHtcclxuICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAyLCAxNCk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlJ/miJDnvoonKTtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOWPkeeOsOS4gOWPque+ilxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+iNieWcsOS4jei2s++8jOinpuWPkeWKqOeJqeS6i+S7tuWksei0pVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBnZW5MaW9uOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgMTUpO1xyXG4gICAgICAgICAgICBhcnJheURhdGFbNl1bNF0gKz0gMTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOeLruWtkCcpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5Y+R546w5LiA5aS05Ye254yb55qE54uu5a2QXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6I2J5Zyw5LiN6Laz77yM6Kem5Y+R5Yqo54mp5LqL5Lu25aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vdXBkYXRlIGZ1bmN0aW9uICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiAgICAvL3Bvd2VyIHJlc3RvcmVcclxuICAgIHBvd2VyVXBkYXRlOiBmdW5jdGlvbiAoZ2FtZURhdGEpIHtcclxuICAgICAgICBnYW1lRGF0YVs3XSs9IDEwICsgZ2FtZURhdGFbOF0gKiAwLjA1O1xyXG4gICAgICAgIGlmIChnYW1lRGF0YVs5XSA+PSBnYW1lRGF0YVsxMF0pIHtcclxuICAgICAgICAgICAgLy9sZXZlbCB1cFxyXG4gICAgICAgICAgICBnYW1lRGF0YVs4XSArPSAyMDtcclxuICAgICAgICAgICAgZ2FtZURhdGFbOV0gLT0gZ2FtZURhdGFbMTBdXHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzEwXSA9IGdhbWVEYXRhWzEwXSAqIDEuMjtcclxuICAgICAgICAgICAgZ2FtZURhdGFbMTFdKys7XHJcbiAgICAgICAgfSBlbHNlIGlmIChnYW1lRGF0YVs5XSA8IDApIHtcclxuICAgICAgICAgICAgZ2FtZURhdGFbOF0gLT0gMjA7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzEwXSA9IGdhbWVEYXRhWzEwXSAvIDEuMjtcclxuICAgICAgICAgICAgaWYgKGdhbWVEYXRhWzEwXSA8PSAxMDApIHtcclxuICAgICAgICAgICAgICAgIGdhbWVEYXRhWzEwXSA9PSAxMDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZ2FtZURhdGFbOV0gPSBnYW1lRGF0YVsxMF0gKyBnYW1lRGF0YVs5XTsgICBcclxuICAgICAgICAgICAgZ2FtZURhdGFbMTFdLS07XHJcbiAgICAgICAgICAgIGlmIChnYW1lRGF0YVsxMV0gPCAwKSB7XHJcbiAgICAgICAgICAgICAgICBnYW1lRGF0YVsxMV0gPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChnYW1lRGF0YVs3XSA+PSBnYW1lRGF0YVs4XSkge1xyXG4gICAgICAgICAgICBnYW1lRGF0YVs3XSA9IGdhbWVEYXRhWzhdO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvL2dhdGhlciBiZXJyeWJ1c2hcclxuICAgIGdhdGhlckJlcnJ5OiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxMCwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzJdICs9IDM7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlciBiZXJyeScpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSA1O1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+aUtumbhua1huaenO+8jOmjn+eJqSszXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgLy9nYXRoZXIgcG9pc29uXHJcbiAgICBnYXRoZXJQb2lzb246IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDE2LCAyKTtcclxuICAgICAgICBhcnJheURhdGFbMF0gLT0gMTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyIHBvaXNvbicpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSAtPSAxMDtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfkuIDkuKrkuI3lubjnmoTkurrlkIPkuobliafmr5LnmoTmnpzlrZDvvIzkurrlj6MtMVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vdGhlIGZydWl0IHRyZWVzIGFyb3VuZCB0b3duIGhhcnZlc3RcclxuICAgIGdhdGhlckZydWl0OiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCA5LCA4KTtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gNTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZnJ1aXQgaGFydmVzdCcpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfkurrku6zlpJblh7rmuLjnjqnvvIzph4fmkZjmnpzlrZDvvIzpo5/niakrNVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGdhdGhlckNyb3A6IGZ1bmN0aW9uIChhcnJheURhdGEsIGFycmF5TWFwLCBudW0pIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyIGZvb2QnKTtcclxuICAgICAgICBsZXQgZ2F0aGVyY291bnQgPSBudW07XHJcbiAgICAgICAgbGV0IG51bUZydWl0ID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDkpO1xyXG4gICAgICAgIGxldCBudW1CZXJyeSA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMCk7XHJcbiAgICAgICAgbGV0IG51bVBvaXNvbiA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxNik7XHJcbiAgICAgICAgaWYgKG51bUZydWl0ID4gMCB8fCBudW1CZXJyeSA+IDAgfHwgbnVtUG9pc29uID4gMCkge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gNTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG51bSA+IG51bUZydWl0ICsgbnVtQmVycnkgKyBudW1Qb2lzb24pIHtcclxuICAgICAgICAgICAgZ2F0aGVyY291bnQgPSBudW1CZXJyeSArIG51bVBvaXNvbiArIG51bUZydWl0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGdhdGhlcmNvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlcmluZyBmb29kJylcclxuICAgICAgICAgICAgaWYgKG51bUZydWl0ID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJGcnVpdChhcnJheURhdGEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKG51bVBvaXNvbiA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJCZXJyeShhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChudW1CZXJyeSA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJQb2lzb24oYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPiAwLjUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJCZXJyeShhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyUG9pc29uKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBnYXRoZXJUcmVlOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCA4LCAyKTtcclxuICAgICAgICBhcnJheURhdGFbM10gKz0gMTA7XHJcbiAgICAgICAgYXJyYXlEYXRhWzldICs9IDEwO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXIgdHJlZSwgcmVzb3VyY2UgKyAyMCcpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+mHh+mbhuWIsOagkeacqO+8jOi1hOa6kCsxMFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBnYXRoZXJGcnVpdFRyZWU6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDgsIDIpO1xyXG4gICAgICAgIGFycmF5RGF0YVszXSArPSAxMDtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gNDtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlciBmcnVpdCB0cmVlLCByZXNvdXJjZSArIDIwJyk7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAn6YeH6ZuG5Yiw5p6c5qCR77yM6LWE5rqQKzEw77yM6aOf54mpKzRcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgZ2F0aGVyU3RvbmU6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDcsIDEpO1xyXG4gICAgICAgIGFycmF5RGF0YVszXSArPSAzMDtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlciBzdG9uZSwgcmVzb3VyY2UgKyAyMCcpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+WPkeeOsOS6huefv+efs++8jOi1hOa6kCszMFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGdhdGhlclJlc291cmNlOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU1hcCwgbnVtKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlciByZXNvdXJjZScpO1xyXG4gICAgICAgIGxldCBnYXRoZXJjb3VudCA9IG51bTtcclxuICAgICAgICBsZXQgbnVtVHJlZSA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA4KTtcclxuICAgICAgICBsZXQgbnVtRnJ1aXRUcmVlID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDkpO1xyXG4gICAgICAgIGxldCBudW1TdG9uZSA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA3KTtcclxuICAgICAgICBpZiAobnVtVHJlZSA+IDAgfHwgbnVtRnJ1aXRUcmVlID4gMCB8fCBudW1TdG9uZSA+IDApIHtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG51bSA+IG51bVRyZWUgKyBudW1TdG9uZSArIG51bUZydWl0VHJlZSkge1xyXG4gICAgICAgICAgICBnYXRoZXJjb3VudCA9IG51bVRyZWUgKyBudW1TdG9uZSArIG51bUZydWl0VHJlZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBnYXRoZXJjb3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXJpbmcgcmVzb3VyY2UnKVxyXG4gICAgICAgICAgICBpZiAobnVtU3RvbmUgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdhdGhlclN0b25lKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAobnVtVHJlZSA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJGcnVpdFRyZWUoYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJUcmVlKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGtpbGxDaGlja2VuOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxMSwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzJdICs9IDU7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2tpbGwgY2hpY2tlbicpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSAxO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+S4gOWPqum4oeiiq+adgOadpeWQg+S6hu+8jOmjn+eJqSs1XFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAga2lsbERvZzogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMTIsIDIpO1xyXG4gICAgICAgIGFycmF5RGF0YVs1XVsxXSAtPSAxO1xyXG4gICAgICAgIGxldCBkZWFkID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzBdIC09IGRlYWQ7XHJcbiAgICAgICAgYXJyYXlEYXRhWzJdICs9IDQ7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2tpbGwgZG9nJyk7XHJcbiAgICAgICAgaWYgKGRlYWQgPT0gMSkge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAn5p2A5q2754u8JyArICfvvIzkuI3ov4fmnIknICsgZGVhZCArICfmrbvkuo7ni7zniKrkuItcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSA1O1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfmnYDmrbvni7wnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+atu+S6jueLvOeIquS4i1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBraWxsQ293OiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxMywgMik7XHJcbiAgICAgICAgbGV0IGRlYWQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKTtcclxuICAgICAgICBhcnJheURhdGFbMF0gLT0gZGVhZDtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gODtcclxuICAgICAgICBjb25zb2xlLmxvZygna2lsbCBjb3cnKTtcclxuICAgICAgICBpZiAoZGVhZCA+PSAyKSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSAwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfmnYDmrbvniZsnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+atu+S6jueJm+inkuS4i1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDEwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfmnYDmrbvniZsnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+atu+S6jueJm+inkuS4i1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+adgOatu+eJmycgKyAn77yM5LiN6L+H5pyJJyArIGRlYWQgKyAn5q275LqO54mb6KeS5LiLXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAga2lsbFNoZWVwOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxNCwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzJdICs9IDQ7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2tpbGwgc2hlZXAnKTtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gNTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfkuIDlj6rnvorooqvmnYDlgZrng6TlhajnvorvvIzpo5/niakrNFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGtpbGxMaW9uOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxNSwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzVdWzRdIC09IDE7XHJcbiAgICAgICAgbGV0IGRlYWQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KTtcclxuICAgICAgICBhcnJheURhdGFbMF0gLT0gZGVhZDtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gMTY7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2tpbGwgbGlvbicpO1xyXG4gICAgICAgIGlmIChkZWFkID49IDIpIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+adgOatu+eLruWtkCcgKyAn77yM5LiN6L+H5pyJJyArIGRlYWQgKyAn5Lq66KKr54uu5a2Q5ZKs5q275LqGXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2UgaWYgKGRlYWQgPSAwKSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSAyMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAn5o2V6I635LiA5aS054uu5a2QXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+aNleadgOeLruWtkOeahOi/h+eoi+S4re+8jOaciScgKyBkZWFkICsgJ+S6uueJuueJsuS6hlxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgZ2F0aGVyTWVhdDogZnVuY3Rpb24gKGFycmF5RGF0YSwgYXJyYXlNYXAsIG51bSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXIgbWVhdCcpO1xyXG4gICAgICAgIGxldCBnYXRoZXJjb3VudCA9IG51bTtcclxuICAgICAgICBsZXQgY2hpY2tlbiA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMSkgLSBhcnJheURhdGFbNl1bMF07XHJcbiAgICAgICAgbGV0IHNoZWVwID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDE0KSAtIGFycmF5RGF0YVs2XVszXTtcclxuICAgICAgICBsZXQgY293ID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDEzKSAtIGFycmF5RGF0YVs2XVsyXTtcclxuICAgICAgICBsZXQgd29sZiA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMik7XHJcbiAgICAgICAgbGV0IGxpb24gPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTUpO1xyXG4gICAgICAgIGlmIChjaGlja2VuID4gMCB8fCBzaGVlcCA+IDAgfHwgY293ID4gMCB8fCB3b2xmID4gMCB8fCBsaW9uID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfku47liqjnianouqvkuIrojrflj5bogonvvIzpo5/nianlop7liqBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAobnVtID4gTWF0aC5mbG9vcihjaGlja2VuICsgc2hlZXAgLyAyICsgY293IC8gMyArIHdvbGYgLyAyICsgbGlvbiAvIDQpKSB7XHJcbiAgICAgICAgICAgIGdhdGhlcmNvdW50ID0gTWF0aC5mbG9vcihjaGlja2VuICsgc2hlZXAgLyAyICsgY293IC8gMyArIHdvbGYgLyAyICsgbGlvbiAvIDQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGdhdGhlcmNvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlcmluZyBtZWF0JylcclxuICAgICAgICAgICAgaWYgKGNoaWNrZW4gPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmtpbGxDaGlja2VuKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMSAmJiBhcnJheURhdGFbNl1bMF0gPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXJyYXlEYXRhWzZdWzBdIC09IDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc2hlZXAgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmtpbGxTaGVlcChhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjA5ICYmIGFycmF5RGF0YVs2XVszXSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBhcnJheURhdGFbNl1bM10gLT0gMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIGlmIChjb3cgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmtpbGxDb3coYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgMC4wOCAmJiBhcnJheURhdGFbNl1bMl0gPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXJyYXlEYXRhWzZdWzJdIC09IDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAod29sZiA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMua2lsbERvZyhhcnJheURhdGEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5raWxsTGlvbihhcnJheURhdGEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICB0YW1lQ2hpY2tlbjogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGFycmF5RGF0YVs2XVswXSArPSAxO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd0YW0gY2hpY2tlbicpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSA1O1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDmiJDlip/pqa/mnI3lubbmsLjov5zmi6XmnInkuIDnvqTpuKFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICB0YW1lQ293OiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgYXJyYXlEYXRhWzZdWzJdICs9IDE7XHJcbiAgICAgICAgYXJyYXlEYXRhWzBdIC09IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDIpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd0YW0gY293Jyk7XHJcbiAgICAgICAgbGV0IGRlYWQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KTtcclxuICAgICAgICBpZiAoZGVhZCA+PSAyKSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSAwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfmiJDlip/pqa/mnI3lubbmsLjov5zmi6XmnInkuIDlpLTniZtcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAn5oiQ5Yqf6amv5pyN5bm25rC46L+c5oul5pyJ5LiA5aS054mbXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHRhbWVTaGVlcDogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGFycmF5RGF0YVs2XVszXSArPSAxO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd0YW0gc2hlZXAnKTtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gNTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5oiQ5Yqf6amv5pyN5bm25rC46L+c5oul5pyJ5LiA5Y+q576KXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgZ2F0aGVyVGFtOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU1hcCwgbnVtKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RyeSB0YW1pbmcnKTtcclxuICAgICAgICBsZXQgaWZUYW1lZCA9IGZhbHNlO1xyXG4gICAgICAgIC8vbGV0IGNoaWNrZW4gPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTEpIC0gYXJyYXlEYXRhWzZdWzBdO1xyXG4gICAgICAgIC8vbGV0IHNoZWVwID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDE0KSAtIGFycmF5RGF0YVs2XVszXTtcclxuICAgICAgICAvL2xldCBjb3cgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTMpIC0gYXJyYXlEYXRhWzZdWzJdO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbnVtOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGNoaWNrZW4gPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTEpIC0gYXJyYXlEYXRhWzZdWzBdO1xyXG4gICAgICAgICAgICBsZXQgc2hlZXAgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTQpIC0gYXJyYXlEYXRhWzZdWzNdO1xyXG4gICAgICAgICAgICBsZXQgY293ID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDEzKSAtIGFycmF5RGF0YVs2XVsyXTtcclxuICAgICAgICAgICAgaWYgKGNoaWNrZW4gPiAwICYmIE1hdGgucmFuZG9tKCkgPCAwLjUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudGFtZUNoaWNrZW4oYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIGlmVGFtZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHNoZWVwID4gMCAmJiBNYXRoLnJhbmRvbSgpIDwgMC40ICYmIHRoaXMuZ2FtZURhdGFbNF0gPj0gMS4yKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRhbWVTaGVlcChhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgaWZUYW1lZCA9IHRydWU7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoY293ID4gMCAmJiBNYXRoLnJhbmRvbSgpIDwgMC4zICYmIHRoaXMuZ2FtZURhdGFbNF0gPj0gMS40KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRhbWVDb3coYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIGlmVGFtZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8qaWYgKGNoaWNrZW4gKyBzaGVlcCArIGNvdyA+IDApIHtcclxuICAgICAgICAgICAgaWYgKCFpZlRhbWVkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6amv5pyN5aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfml6Dliqjnianpqa/mnI1cXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0qL1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgQUkgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcblxyXG4gICAgYnVpbGRIb3VzZTogZnVuY3Rpb24gKGdhbWVEYXRhKSB7XHJcbiAgICAgICAgaWYgKGdhbWVEYXRhWzNdID49IDEwMCAmJiBnYW1lRGF0YVsxXSA8IGdhbWVEYXRhWzBdIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDMpO1xyXG4gICAgICAgICAgICBnYW1lRGF0YVszXSAtPSAxMDA7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzFdICs9IDE7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+aIkOWKn+W7uumAoOS4gOagi+aIv+WtkFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBmb29kVXBkYXRlOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU1hcCkge1xyXG4gICAgICAgIGxldCBudW1PZlBsb3QgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgNSk7XHJcbiAgICAgICAgYXJyYXlEYXRhWzJdICs9IG51bU9mUGxvdCAqIDE2ICogYXJyYXlEYXRhWzRdICogYXJyYXlEYXRhWzVdIC0gYXJyYXlEYXRhWzBdICogNDtcclxuICAgICAgICBpZiAoYXJyYXlEYXRhWzJdIDwgMCkge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbMl0gPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZygnZm9vZDogJyArIE1hdGguZmxvb3IoYXJyYXlEYXRhWzJdKSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vY3JvcCBncm93XHJcbiAgICBncm93Q3JvcDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgNCwgNSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2Nyb3AgZ3JvdycpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+W6hOeovOaIkOeGn+S6hlxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vdHJlZXMgYXJvdW5kIHRoZSB0b3duIGNoYW5nZSB0byBmcnVpdCB0cmVlc1xyXG4gICAgZ3Jvd0ZydWl0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCA4LCA5KTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZnJ1aXQnKTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfmoJHkuIrnu5PmnpzlrZDkuoZcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICByZXNvdXJjZURlc3Rvcnk6IGZ1bmN0aW9uIChhcnJheURhdGEsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgbGV0IGNoaWNrZW4gPSBbdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDExKSAtIGFycmF5RGF0YVs2XVswXSwgMTEsIDAuMV07XHJcbiAgICAgICAgbGV0IHNoZWVwID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxNCkgLSBhcnJheURhdGFbNl1bM10sIDE0LCAwLjA1XTtcclxuICAgICAgICBsZXQgY293ID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMykgLSBhcnJheURhdGFbNl1bMl0sIDEzLCAwLjA1XTtcclxuICAgICAgICBsZXQgd29sZiA9IFt0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTIpLCAxMiwgMC4wNV07XHJcbiAgICAgICAgbGV0IGxpb24gPSBbdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDE1KSwgMTUsIDAuMV07XHJcbiAgICAgICAgbGV0IGJlcnJ5ID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMCksIDEwLCAwLjRdO1xyXG4gICAgICAgIGxldCBwb2lzb24gPSBbdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDE2KSwgMTYsIDAuNF07XHJcbiAgICAgICAgbGV0IHRyZWUgPSBbdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDgpLCA4LCAwLjA1XTtcclxuICAgICAgICBsZXQgZnJ1aXQgPSBbdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDkpLCA5LCAwLjA1XTtcclxuICAgICAgICBsZXQgaXRlbUxpc3QgPSBbY2hpY2tlbiwgc2hlZXAsIGNvdywgd29sZiwgbGlvbiwgYmVycnksIHBvaXNvbiwgdHJlZSwgZnJ1aXRdO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbUxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBpdGVtTGlzdFtpXVswXTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IGl0ZW1MaXN0W2ldWzJdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCBpdGVtTGlzdFtpXVsxXSwgMik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGxhbmR1cGRhdGU6IGZ1bmN0aW9uIChhcnJheURhdGEsIGFycmF5Tm9kZSwgYXJyYXlNYXApIHtcclxuICAgICAgICB0aGlzLnJlc291cmNlRGVzdG9yeShhcnJheURhdGEsIGFycmF5TWFwKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA0KTsgaSsrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3Jvd0Nyb3AoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgOCk7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncm93RnJ1aXQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IG51bU9mUGxvdCA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA1KTtcclxuICAgICAgICB3aGlsZSAobnVtT2ZQbG90ID4gYXJyYXlEYXRhWzBdKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQoYXJyYXlOb2RlLCBhcnJheU1hcCwgNSwgMik7XHJcbiAgICAgICAgICAgIG51bU9mUGxvdCAtPSAxO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnbm90IGVub3VnaCBwZW9wbGUgZmFybWluZycpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgdGVjaFVwZGF0ZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGFycmF5RGF0YVs0XSArPSAwLjAwNTtcclxuICAgICAgICBjb25zb2xlLmxvZygndGVjaDogJyArIE1hdGgucm91bmQoYXJyYXlEYXRhWzRdKSk7XHJcbiAgICAgICAgLy90aGlzLmxvZy5zdHJpbmcgPSAn56eR5oqA5YC8KzAuMDAxXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgcG9wdWxhdGlvblVwZGF0ZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGxldCB3b2xmID0gdGhpcy5udW1PZkl0ZW0odGhpcy5tYXBLZXksIDEyKTtcclxuICAgICAgICBsZXQgbGlvbiA9IHRoaXMubnVtT2ZJdGVtKHRoaXMubWFwS2V5LCAxNSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3b2xmOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGFycmF5RGF0YVswXSA+IGFycmF5RGF0YVsxXSAqIDMgJiYgTWF0aC5yYW5kb20oKSA8IDAuMSkge1xyXG4gICAgICAgICAgICAgICAgYXJyYXlEYXRhWzBdIC09IDE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICfnvLrlsJHmiL/lsYvvvIzkuIDkuKrkuI3lubjnmoTmtYHmtarmsYnooqvph47ni7zmnYDlrrNcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGlvbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChhcnJheURhdGFbMF0gPiBhcnJheURhdGFbMV0gKiAzICYmIE1hdGgucmFuZG9tKCkgPCAwLjMpIHtcclxuICAgICAgICAgICAgICAgIGFycmF5RGF0YVswXSAtPSAxO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAn57y65bCR5oi/5bGL77yM5LiA5Liq5LiN5bm455qE5rWB5rWq5rGJ6KKr54uu5a2Q5p2A5a6zXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoYXJyYXlEYXRhWzJdID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOmlpeiNku+8jOS6uuWPo+aNn+WkseaDqOmHjVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIGlmIChhcnJheURhdGFbMF0gPiAzKSB7XHJcbiAgICAgICAgICAgICAgICBhcnJheURhdGFbMF0gPSBNYXRoLmNlaWwoYXJyYXlEYXRhWzBdICogMyAvIDQpO1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLmxvZy5zdHJpbmcgPSBNYXRoLmNlaWwoYXJyYXlEYXRhWzBdICogMSAvIDQpOyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFycmF5RGF0YVswXSA9IE1hdGguZmxvb3IoYXJyYXlEYXRhWzBdICogMyAvIDQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChhcnJheURhdGFbMF0gPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgYXJyYXlEYXRhWzBdID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICBjaGFuZ2VXZWF0aGVyOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgYXJyYXlEYXRhWzVdIC09IChhcnJheURhdGFbNV0gLSAxKSAvIDU7XHJcbiAgICAgICAgYXJyYXlEYXRhWzVdIC09IDAuMDA1O1xyXG4gICAgfSxcclxuXHJcbiAgICB5ZWFyQ2hlY2s6IGZ1bmN0aW9uIChhcnJheURhdGEsIGFycmF5Tm9kZSwgYXJyYXlNYXApIHtcclxuICAgICAgICB0aGlzLmJ1aWxkSG91c2UoYXJyYXlEYXRhKTtcclxuICAgICAgICB0aGlzLmdhdGhlckZvb2QoYXJyYXlEYXRhLCBhcnJheU1hcCk7XHJcbiAgICB9LFxyXG5cclxuICAgIGdhdGhlckFJOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU1hcCkge1xyXG4gICAgICAgIGxldCBudW1PZlBsb3QgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgNSk7XHJcbiAgICAgICAgbGV0IGZvb2QgPSBudW1PZlBsb3QgKiAyMCAtIGFycmF5RGF0YVswXSAqIDQgKyBhcnJheURhdGFbMl07XHJcbiAgICAgICAgbGV0IHJlbWFpbiA9IGFycmF5RGF0YVswXSAtIHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA1KTtcclxuICAgICAgICBpZiAoZm9vZCA8PSBhcnJheURhdGFbMF0gKiA4KSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ2F0aGVyQ3JvcChhcnJheURhdGEsIGFycmF5TWFwLCByZW1haW4pO1xyXG4gICAgICAgICAgICBmb29kID0gbnVtT2ZQbG90ICogMjAgLSBhcnJheURhdGFbMF0gKiA0ICsgYXJyYXlEYXRhWzJdO1xyXG4gICAgICAgICAgICBpZiAoZm9vZCA8PSBhcnJheURhdGFbMF0gKiA0KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdhdGhlck1lYXQoYXJyYXlEYXRhLCBhcnJheU1hcCwgTWF0aC5mbG9vcihyZW1haW4gLyAyKSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKGZvb2QgPD0gYXJyYXlEYXRhWzBdICogMTYpIHtcclxuICAgICAgICAgICAgdGhpcy5nYXRoZXJDcm9wKGFycmF5RGF0YSwgYXJyYXlNYXAsIE1hdGguZmxvb3IocmVtYWluIC8gNikpO1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlclJlc291cmNlKGFycmF5RGF0YSwgYXJyYXlNYXAsIE1hdGguZmxvb3IocmVtYWluIC8gMikpO1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlclRhbShhcnJheURhdGEsIGFycmF5TWFwLCBNYXRoLmZsb29yKHJlbWFpbiAvIDMpKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlclJlc291cmNlKGFycmF5RGF0YSwgYXJyYXlNYXAsIE1hdGguZmxvb3IocmVtYWluIC8gMikpO1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlclRhbShhcnJheURhdGEsIGFycmF5TWFwLCBNYXRoLmZsb29yKHJlbWFpbiAvIDIpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGFycmF5RGF0YVswXSA+IDUwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ2F0aGVyTWVhdChhcnJheURhdGEsIGFycmF5TWFwLCBNYXRoLmZsb29yKHJlbWFpbiAvIDEwKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBjaGVjayBpZiB0aGUgbmV4dCB0aWxlIGh1bWFuIGhlYWRpbmcgdG8gaXMgd2F0ZXIgb3Igc29tZXdoZXJlIGl0IHNob3VsZCBub3QgYmVcclxuICAgIGNhbkh1bWFuTW92ZShhY3Rpb25OdW0pIHtcclxuICAgICAgICBsZXQgY3VyclggPSBNYXRoLmZsb29yKHRoaXMuaHVtYW5Ob2RlLnggLyAzMik7XHJcbiAgICAgICAgbGV0IGN1cnJZID0gTWF0aC5mbG9vcih0aGlzLmh1bWFuTm9kZS55IC8gMzIpO1xyXG5cclxuICAgICAgICBpZiAoYWN0aW9uTnVtID09IDApIHsgLy8gdXBcclxuICAgICAgICAgICAgY3VyclkrKztcclxuICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbk51bSA9PSAxKSB7IC8vZG93blxyXG4gICAgICAgICAgICBjdXJyWS0tO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uTnVtID09IDIpIHsgLy9sZWZ0XHJcbiAgICAgICAgICAgIGN1cnJYLS07XHJcbiAgICAgICAgfSBlbHNlIHsgLy9yaWdodFxyXG4gICAgICAgICAgICBjdXJyWCsrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZiAodGhpcy5tYXBLZXlbY3VyclldW2N1cnJYXSA9PSAwKSB7IC8vIGFkZCBvdGhlciBrZXlzIGlmIG5lY2Vzc2FyeVxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBodW1hbk1vdmU6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGxldCBzdGF0ZSA9ICcnO1xyXG4gICAgICAgIGxldCBhY3Rpb24gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KTtcclxuICAgICAgICBpZiAodGhpcy5jYW5IdW1hbk1vdmUoYWN0aW9uKSkge1xyXG4gICAgICAgICAgICBpZiAoYWN0aW9uID09IDAgJiYgdGhpcy5odW1hbk5vZGUueSA8PSA2NDAgLSAxNiAtIDMyKSB7XHJcbiAgICAgICAgICAgICAgICAvLyB1cFxyXG4gICAgICAgICAgICAgICAgc3RhdGUgPSAnaHVtYW5fdXAnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcC54ID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3AueSA9IDMyO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PSAxICYmIHRoaXMuaHVtYW5Ob2RlLnkgPj0gMTYgKyAzMikge1xyXG4gICAgICAgICAgICAgICAgLy8gZG93blxyXG4gICAgICAgICAgICAgICAgc3RhdGUgPSAnaHVtYW5fZG93bic7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnggPSAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcC55ID0gLTMyO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PSAyICYmIHRoaXMuaHVtYW5Ob2RlLnggPj0gMTYgKyAzMikge1xyXG4gICAgICAgICAgICAgICAgLy8gbGVmdFxyXG4gICAgICAgICAgICAgICAgc3RhdGUgPSAnaHVtYW5fbGVmdCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnggPSAtMzI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnkgPSAwO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PSAzICYmIHRoaXMuaHVtYW5Ob2RlLnggPD0gNjQwIC0gMTYgLSAzMikge1xyXG4gICAgICAgICAgICAgICAgLy8gcmlnaHRcclxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX3JpZ2h0JztcclxuICAgICAgICAgICAgICAgIHRoaXMuc3AueCA9IDMyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcC55ID0gMDtcclxuICAgICAgICAgICAgfSBcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNwLnggPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnNwLnkgPSAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuc3AueCkge1xyXG4gICAgICAgICAgICB0aGlzLmh1bWFuTm9kZS54ICs9IHRoaXMuc3AueDtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuc3AueSkge1xyXG4gICAgICAgICAgICB0aGlzLmh1bWFuTm9kZS55ICs9IHRoaXMuc3AueTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChzdGF0ZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHByb2dyZXNzQmFyVXBkYXRlOiBmdW5jdGlvbigpIHtcclxuXHJcbiAgICAgICAgdGhpcy5wcm9ncmVzc0Jhci5wcm9ncmVzcyA9IHRoaXMuZ2FtZURhdGFbN10gLyB0aGlzLmdhbWVEYXRhWzhdO1xyXG4gICAgICAgIC8qaWYgKHByb2dyZXNzIDwgMSkge1xyXG4gICAgICAgICAgICBwcm9ncmVzcyArPSAwLjAwNTtcclxuICAgICAgICAgICAgdGhpcy5wcm9ncmVzc0Jhci5wcm9ncmVzcyA9IHByb2dyZXNzO1xyXG4gICAgICAgIFxyXG5cdFx0fSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5wcm9ncmVzc0Jhci5wcm9ncmVzcyA9IDE7ICAgICAgIFxyXG5cdFx0fSovXHJcblx0fSxcclxuXHJcbiAgICByZWFkVXNlckRhdGE6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2FtZT0nICsgY29tLmdhbWVPdmVyKTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKCdmaXJzdFRpbWUgJyArIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZ2xvYmFsTWFwS2V5JykgPT0gbnVsbCk7Ly9tYXkgbmV2ZXIgYmUgdHJ1ZVxyXG4gICAgICAgIHZhciB2YWx1ZSA9IHd4LmdldFN0b3JhZ2VTeW5jKCdnbG9iYWxNYXBLZXknKTtcclxuICAgICAgICBjb25zb2xlLmxvZygncmVzdGFydCAnICsgY29tLnJlc3RhcnQpO1xyXG4gICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPT0gMCB8fCBjb20ucmVzdGFydCB8fCBjb20uZ2FtZU92ZXIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ25ldyBnYW1lJyk7XHJcbiAgICAgICAgICAgIGNvbS5nYW1lT3ZlciA9IGZhbHNlO1xyXG4gICAgICAgICAgICBjb20ucmVzdGFydCA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vZ2xvYmFsTWFwS2V5ID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdnbG9iYWxNYXBLZXknKTtcclxuICAgICAgICAgICAgLy9nbG9iYWxHYW1lRGF0YSA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZ2xvYmFsR2FtZURhdGEnKTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IHd4LmdldFN0b3JhZ2VTeW5jKCdnbG9iYWxNYXBLZXknKTtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAvLyBEbyBzb21ldGhpbmcgd2l0aCByZXR1cm4gdmFsdWVcclxuICAgICAgICAgICAgICAgICAgZ2xvYmFsTWFwS2V5ID0gdmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIC8vIERvIHNvbWV0aGluZyB3aGVuIGNhdGNoIGVycm9yXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZ2V0IG1hcCBrZXkgc3RvcmFnZSBlcnJvcicpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSB3eC5nZXRTdG9yYWdlU3luYygnZ2xvYmFsR2FtZURhdGEnKTtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAvLyBEbyBzb21ldGhpbmcgd2l0aCByZXR1cm4gdmFsdWVcclxuICAgICAgICAgICAgICAgICAgZ2xvYmFsR2FtZURhdGEgPSB2YWx1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgLy8gRG8gc29tZXRoaW5nIHdoZW4gY2F0Y2ggZXJyb3JcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnZXQgZ2FtZSBkYXRhIHN0b3JhZ2UgZXJyb3InKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHZhbHVlID0gd3guZ2V0U3RvcmFnZVN5bmMoJ2dsb2JhbFllYXInKTtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAvLyBEbyBzb21ldGhpbmcgd2l0aCByZXR1cm4gdmFsdWVcclxuICAgICAgICAgICAgICAgICAgZ2xvYmFsWWVhciA9IHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBEbyBzb21ldGhpbmcgd2hlbiBjYXRjaCBlcnJvclxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2dldCB5ZWFyIHN0b3JhZ2UgZXJyb3InKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2dsb2JhbE1hcEtleScpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhnbG9iYWxNYXBLZXkpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZ2xvYmFsR2FtZURhdGEnKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZ2xvYmFsR2FtZURhdGEpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZ2xvYmFsWWVhcicpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhnbG9iYWxZZWFyKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHZhciBrZXlBcnJheSA9IGdsb2JhbE1hcEtleS5zcGxpdChcIixcIik7XHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5zaXplWTsgaSsrKSB7XHJcbiAgICAgICAgICAgIC8vICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHRoaXMuc2l6ZVg7IGorKykge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIHRoaXMubWFwS2V5W2ldW2pdID0gcGFyc2VJbnQoa2V5QXJyYXlbaSAqIHRoaXMuc2l6ZVggKyBqXSk7XHJcbiAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgdGhpcy5tYXBLZXkgPSBnbG9iYWxNYXBLZXk7XHJcblxyXG4gICAgICAgICAgICAvLyB2YXIgc3BsaXRBcnJheSA9IGdsb2JhbEdhbWVEYXRhLnNwbGl0KFwiLFwiKTtcclxuICAgICAgICAgICAgLy8gZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmdhbWVEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIC8vICAgICBpZiAoaSA9PSA2IHx8IGkgPT0gNyB8fCBpID09IDggfHwgaSA9PSA5IHx8IGkgPT0gMTApIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICBmb3IgKGogPSAwOyBqIDwgdGhpcy5nYW1lRGF0YVtpXS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB0aGlzLmdhbWVEYXRhW2ldW2pdID0gcGFyc2VGbG9hdChzcGxpdEFycmF5W2kgKyBqXSk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICB0aGlzLmdhbWVEYXRhW2ldID0gcGFyc2VGbG9hdChzcGxpdEFycmF5W2ldKTtcclxuICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICB0aGlzLmdhbWVEYXRhID0gZ2xvYmFsR2FtZURhdGE7XHJcbiAgICAgICAgICAgIHRoaXMudGltZSA9IGdsb2JhbFllYXI7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBnYW1lT3ZlclVwZGF0ZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmdhbWVEYXRhWzBdIDw9IDAgJiYgdGhpcy5nYW1lT3Zlck9yTm90ID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdkZWFkJyk7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZU92ZXIuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5nYW1lT3Zlck9yTm90ID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5zYXZlVXNlckRhdGEoKTtcclxuICAgICAgICAgICAgdGhpcy5nYW1lT3ZlclRpbWUgPSB0aGlzLnRpbWU7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZU92ZXJTdHJpbmcuc3RyaW5nID0gJ+a4uOaIj+e7k+adn1xcbuaCqOeahOWtkOawkeeBree7neS6hlxcbicgKyAn5oKo55qE5paH5piO5oyB57ut5LqGXFxuJyArIHRoaXMuZ2FtZU92ZXJUaW1lICsgJ+W5tCc7XHJcblx0ICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgc2F2ZVVzZXJEYXRhOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY29tLmdhbWVPdmVyID0gdGhpcy5nYW1lT3Zlck9yTm90O1xyXG4gICAgICAgIGdsb2JhbE1hcEtleSA9IHRoaXMubWFwS2V5O1xyXG4gICAgICAgIC8vY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdnbG9iYWxNYXBLZXknLCBnbG9iYWxNYXBLZXkpO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHd4LnNldFN0b3JhZ2VTeW5jKCdnbG9iYWxNYXBLZXknLCBnbG9iYWxNYXBLZXkpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3NldCBtYXAga2V5IHN0b3JhZ2UgZXJyb3InKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3NhdmVVc2VyRGF0YSBnbG9iYWxNYXBLZXk6Jyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coZ2xvYmFsTWFwS2V5KTtcclxuXHJcbiAgICAgICAgZ2xvYmFsR2FtZURhdGEgPSB0aGlzLmdhbWVEYXRhO1xyXG4gICAgICAgIC8vY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdnbG9iYWxHYW1lRGF0YScsIGdsb2JhbEdhbWVEYXRhKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICB3eC5zZXRTdG9yYWdlU3luYygnZ2xvYmFsR2FtZURhdGEnLCBnbG9iYWxHYW1lRGF0YSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnc2V0IGdhbWUgZGF0YSBzdG9yYWdlIGVycm9yJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdzYXZlVXNlckRhdGEgZ2xvYmFsR2FtZURhdGEnKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhnbG9iYWxHYW1lRGF0YSk7XHJcblxyXG4gICAgICAgIGdsb2JhbFllYXIgPSB0aGlzLnRpbWU7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgd3guc2V0U3RvcmFnZVN5bmMoJ2dsb2JhbFllYXInLCBnbG9iYWxZZWFyKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdzZXQgeWVhciBzdG9yYWdlIGVycm9yJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlKGR0KSB7XHJcbiAgICAgICAgaWYgKHRoaXMubG9nLnN0cmluZy5sZW5ndGggPj0gMTAwMCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAnJztcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuZ2FtZU92ZXJPck5vdCkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZnJhbWUrKztcclxuICAgICAgICB0aGlzLmxvZ2ZyYW1lKys7XHJcbiAgICAgICAgaWYgKHRoaXMuZnJhbWUgJSA2MCA9PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMucG93ZXJVcGRhdGUodGhpcy5nYW1lRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmZyYW1lID09IDI3MCkge1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlckFJKHRoaXMuZ2FtZURhdGEsIHRoaXMubWFwS2V5KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuZnJhbWUgPT0gMzAwKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5idWlsZEhvdXNlKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmZyYW1lID09IDMzMCkge1xyXG4gICAgICAgICAgICB0aGlzLnBvcHVsYXRpb25VcGRhdGUodGhpcy5nYW1lRGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuZm9vZFVwZGF0ZSh0aGlzLmdhbWVEYXRhLCB0aGlzLm1hcEtleSk7XHJcbiAgICAgICAgICAgIHRoaXMudGVjaFVwZGF0ZSh0aGlzLmdhbWVEYXRhKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuZnJhbWUgPj0gMzYwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubGFuZHVwZGF0ZSh0aGlzLmdhbWVEYXRhLCB0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5KTtcclxuICAgICAgICAgICAgdGhpcy5jaGFuZ2VXZWF0aGVyKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLmZyYW1lID0gMDtcclxuICAgICAgICAgICAgdGhpcy50aW1lKys7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuaHVtYW5UaW1lcisrO1xyXG4gICAgICAgIGlmICh0aGlzLmh1bWFuVGltZXIgPiA2MCkge1xyXG4gICAgICAgICAgICB0aGlzLmh1bWFuTW92ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLmh1bWFuVGltZXIgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5sb2dmcmFtZSAlIDI3MDAgPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAnJztcclxuICAgICAgICAgICAgdGhpcy5sb2dmcmFtZSA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuTGV2ZWxUZXh0LnN0cmluZyA9ICfnrYnnuqc6ICcgKyB0aGlzLmdhbWVEYXRhWzExXTtcclxuICAgICAgICB0aGlzLnBvcHVsYXRpb25UZXh0LnN0cmluZyA9ICfkurrlj6M6ICcgKyB0aGlzLmdhbWVEYXRhWzBdO1xyXG4gICAgICAgIHRoaXMuZm9vZFRleHQuc3RyaW5nID0gJ+mjn+eJqTogJyArIE1hdGgucm91bmQodGhpcy5nYW1lRGF0YVsyXSk7IFxyXG4gICAgICAgIC8vdGhpcy50ZWNoVGV4dC5zdHJpbmcgPSAn56eR5oqAOiAnICsgdGhpcy5nYW1lRGF0YVs0XS50b0ZpeGVkKDMpO1xyXG4gICAgICAgIHRoaXMudGVjaFRleHQuc3RyaW5nID0gJ+enkeaKgDogJyArIE1hdGgucm91bmQodGhpcy5nYW1lRGF0YVs0XSAqIDEwMDApIC8gMTAwMDtcclxuICAgICAgICAvL3RoaXMud2VhdGhlclRleHQuc3RyaW5nID0gJ+WkqeawlDogJyArIHRoaXMuZ2FtZURhdGFbNV0udG9GaXhlZCgxKTtcclxuICAgICAgICB0aGlzLnJlc291cmNlVGV4dC5zdHJpbmcgPSAn6LWE5rqQOiAnICsgdGhpcy5nYW1lRGF0YVszXTsgXHJcbiAgICAgICAgdGhpcy5wb3dlclRleHQuc3RyaW5nID0gdGhpcy5nYW1lRGF0YVs3XSArICcvJyArIHRoaXMuZ2FtZURhdGFbOF07IFxyXG4gICAgICAgIHRoaXMucHJvZ3Jlc3NCYXJVcGRhdGUoKTtcclxuICAgICAgICB0aGlzLmdhbWVPdmVyVXBkYXRlKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19